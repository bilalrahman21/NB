package app.nb

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    const val HANDLE = "handle"
    const val HANDLE_LEFT = "handle_left"
    const val LOCK_DOUBLE_TAP = "lock_double_tap"
    const val SHAKE_TORCH = "shake_torch"
    const val OTP = "otp"
    const val BATTERY = "battery"
    const val BATTERY_85 = "battery_85"
    const val LANG = "lang"
    const val BACK_TAP = "back_tap"
    const val TAP_SENS = "tap_sens"
    const val REAR_NIGHT = "rear_night"
    const val NIGHT_START = "night_start"
    const val NIGHT_END = "night_end"
    const val REAR_STATUS = "rear_status"

    fun sp(c: Context): SharedPreferences = c.getSharedPreferences("nb", Context.MODE_PRIVATE)

    private fun default(key: String): Boolean = when (key) {
        HANDLE, LOCK_DOUBLE_TAP, OTP, BATTERY, BATTERY_85, BACK_TAP -> true
        else -> false
    }

    fun on(c: Context, key: String): Boolean = sp(c).getBoolean(key, default(key))
    fun set(c: Context, key: String, value: Boolean) = sp(c).edit().putBoolean(key, value).apply()

    /** "low", "medium" or "high" */
    fun tapSens(c: Context): String = sp(c).getString(TAP_SENS, "medium") ?: "medium"
    fun setTapSens(c: Context, v: String) = sp(c).edit().putString(TAP_SENS, v).apply()

    /** How hard the back tap must be (m/s²). Higher sensitivity = lighter taps count. */
    fun tapThreshold(c: Context): Float = when (tapSens(c)) {
        "low" -> 4.5f
        "high" -> 2.0f
        else -> 3.0f
    }

    fun int(c: Context, key: String, def: Int): Int = sp(c).getInt(key, def)
    fun setInt(c: Context, key: String, v: Int) = sp(c).edit().putInt(key, v).apply()

    fun lang(c: Context): String = sp(c).getString(LANG, "en") ?: "en"
    fun setLang(c: Context, tag: String) = sp(c).edit().putString(LANG, tag).apply()
}
