package app.nb

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import kotlin.math.abs
import kotlin.math.sqrt

/** Shake the phone (a quick back-and-forth, twice) to toggle the torch. */
class ShakeTorch(private val ctx: Context) : SensorEventListener {
    private val sm = ctx.getSystemService(SensorManager::class.java)
    private val accel: Sensor? = sm?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    private val cam = ctx.getSystemService(CameraManager::class.java)
    private var torchId: String? = null
    private var torchOn = false
    private var listening = false

    private var windowStart = 0L
    private var lastPeak = 0L
    private var peaks = 0
    private var lastToggle = 0L

    private val torchCallback = object : CameraManager.TorchCallback() {
        override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
            if (cameraId == torchId) torchOn = enabled
        }
    }

    init {
        val c = cam
        if (c != null) {
            try {
                torchId = c.cameraIdList.firstOrNull { id ->
                    c.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                }
                c.registerTorchCallback(torchCallback, Handler(Looper.getMainLooper()))
            } catch (e: Exception) {
            }
        }
    }

    fun listen(on: Boolean) {
        if (on && !listening && accel != null) {
            sm?.registerListener(this, accel, SensorManager.SENSOR_DELAY_UI)
            listening = true
        } else if (!on && listening) {
            sm?.unregisterListener(this)
            listening = false
        }
    }

    fun release() {
        listen(false)
        try { cam?.unregisterTorchCallback(torchCallback) } catch (e: Exception) {}
    }

    override fun onSensorChanged(e: SensorEvent) {
        val x = e.values[0]; val y = e.values[1]; val z = e.values[2]
        val g = sqrt(x * x + y * y + z * z) / SensorManager.GRAVITY_EARTH
        if (g < 2.6f) return
        val now = SystemClock.elapsedRealtime()
        if (now - lastPeak < 150) return
        if (now - windowStart > 1200) { windowStart = now; peaks = 0 }
        peaks++
        lastPeak = now
        if (peaks >= 3 && now - lastToggle > 1500) {
            peaks = 0
            lastToggle = now
            toggle()
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    private fun toggle() {
        val id = torchId ?: return
        try {
            cam?.setTorchMode(id, !torchOn)
            buzz(ctx)
        } catch (e: Exception) {
        }
    }
}

/**
 * Detects two quick taps on the back of the phone using the accelerometer.
 * A tap on the back is a short, sharp jolt mostly along the axis through the screen (Z).
 * Exactly two jolts 100–500 ms apart, then a short pause, count as a double tap.
 */
class BackTap(ctx: Context, private val onDoubleTap: () -> Unit) : SensorEventListener {
    private val sm = ctx.getSystemService(SensorManager::class.java)
    private val accel: Sensor? = sm?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    private val main = Handler(Looper.getMainLooper())
    private var listening = false

    /** Minimum jolt in m/s² (set from the sensitivity setting). */
    var threshold = 3.0f

    private val gravity = FloatArray(3)
    private var samples = 0
    private val peaks = ArrayList<Long>()
    private var lastPeak = 0L
    private var lastFire = 0L
    private var pending = false

    private val confirm = Runnable {
        pending = false
        val now = SystemClock.elapsedRealtime()
        val recent = peaks.count { now - it < 900 }
        peaks.clear()
        if (recent == 2) {
            lastFire = now
            onDoubleTap()
        }
    }

    fun listen(on: Boolean) {
        if (on && !listening && accel != null) {
            samples = 0
            peaks.clear()
            // ~200 samples a second so short taps aren't missed.
            sm?.registerListener(this, accel, 5000)
            listening = true
        } else if (!on && listening) {
            sm?.unregisterListener(this)
            main.removeCallbacks(confirm)
            pending = false
            listening = false
        }
    }

    fun release() = listen(false)

    override fun onSensorChanged(e: SensorEvent) {
        val v = e.values
        if (samples < 25) {
            // Settle the gravity estimate first.
            for (i in 0..2) gravity[i] = if (samples == 0) v[i] else gravity[i] * 0.8f + v[i] * 0.2f
            samples++
            return
        }
        for (i in 0..2) gravity[i] = gravity[i] * 0.92f + v[i] * 0.08f
        val lx = v[0] - gravity[0]
        val ly = v[1] - gravity[1]
        val lz = v[2] - gravity[2]
        val z = abs(lz)
        val side = sqrt(lx * lx + ly * ly)
        if (z < threshold || z < side * 1.3f) return

        val now = SystemClock.elapsedRealtime()
        if (now - lastPeak < 90) return // same tap still ringing
        lastPeak = now
        peaks.add(now)
        while (peaks.isNotEmpty() && now - peaks[0] > 1000) peaks.removeAt(0)
        if (now - lastFire < 1500) return

        if (peaks.size > 3) {
            // Shaking or bumping around, not a double tap.
            main.removeCallbacks(confirm)
            pending = false
            return
        }
        if (peaks.size >= 2 && !pending) {
            val gap = now - peaks[peaks.size - 2]
            if (gap in 100..500) {
                pending = true
                main.postDelayed(confirm, 350)
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}

fun buzz(c: Context, ms: Long = 40) {
    try {
        val v: Vibrator? = if (Build.VERSION.SDK_INT >= 31) {
            c.getSystemService(VibratorManager::class.java)?.defaultVibrator
        } else {
            c.getSystemService(Vibrator::class.java)
        }
        v?.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
    } catch (e: Exception) {
    }
}

/** Alerts once per charge when the battery reaches 85% (or 100%). */
object BatteryWatcher {
    private var owner: Context? = null
    private var alerted = false

    private val rx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) = handle(c, i)
    }

    fun start(c: Context) {
        if (owner != null) return
        owner = c
        val f = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        try {
            if (Build.VERSION.SDK_INT >= 33) c.registerReceiver(rx, f, Context.RECEIVER_NOT_EXPORTED)
            else c.registerReceiver(rx, f)
        } catch (e: Exception) {
            owner = null
        }
    }

    fun stop(c: Context) {
        if (owner !== c) return
        try { c.unregisterReceiver(rx) } catch (e: Exception) {}
        owner = null
    }

    private fun handle(c: Context, i: Intent) {
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
        if (level < 0) return
        val pct = level * 100 / scale
        val plugged = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
        if (!plugged) { alerted = false; return }
        if (!Prefs.on(c, Prefs.BATTERY)) return
        val threshold = if (Prefs.on(c, Prefs.BATTERY_85)) 85 else 100
        if (pct >= threshold && !alerted) {
            alerted = true
            Notifier.battery(c, pct)
        }
    }
}
