package app.nb

import android.accessibilityservice.AccessibilityButtonController
import android.accessibilityservice.AccessibilityService
import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.view.Display
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.min

/**
 * The heart of NB. Takes the screenshot when you open NB, draws the edge handle,
 * pinned images and the OTP chip, and runs shake-for-torch and the battery alert.
 */
class NBAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: NBAccessibilityService? = null
            private set
    }

    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())
    private var handle: View? = null
    private val pins = ArrayList<View>()
    private var otpChip: View? = null
    private var capturing = false
    private var torch: ShakeTorch? = null
    private var backTap: BackTap? = null
    private var preview: View? = null

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        when (key) {
            Prefs.HANDLE, Prefs.HANDLE_LEFT -> refreshHandle()
            Prefs.SHAKE_TORCH, Prefs.BACK_TAP, Prefs.TAP_SENS -> updateSensors()
        }
    }

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) { safe("screen on/off") { updateSensors() } }
    }

    private val buttonCallback = object : AccessibilityButtonController.AccessibilityButtonCallback() {
        override fun onClicked(controller: AccessibilityButtonController) = capture(250)
    }

    /** Runs one part of NB; if it fails, NB keeps running and the error is saved for the report. */
    private inline fun safe(where: String, block: () -> Unit): Boolean {
        return try {
            block()
            true
        } catch (e: Throwable) {
            CrashLog.note(this, where, e)
            false
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(WindowManager::class.java)
        safe("settings listener") { Prefs.sp(this).registerOnSharedPreferenceChangeListener(prefListener) }
        safe("edge handle") { refreshHandle() }
        safe("accessibility button") { accessibilityButtonController.registerAccessibilityButtonCallback(buttonCallback) }
        safe("screen receiver") {
            val f = IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_ON)
                addAction(Intent.ACTION_SCREEN_OFF)
            }
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(screenReceiver, f, Context.RECEIVER_NOT_EXPORTED)
            else registerReceiver(screenReceiver, f)
        }
        safe("sensors") { updateSensors() }
        safe("battery alert") { BatteryWatcher.start(this) }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        instance = null
        Prefs.sp(this).unregisterOnSharedPreferenceChangeListener(prefListener)
        try { unregisterReceiver(screenReceiver) } catch (e: Exception) {}
        try { accessibilityButtonController.unregisterAccessibilityButtonCallback(buttonCallback) } catch (e: Exception) {}
        torch?.release(); torch = null
        backTap?.release(); backTap = null
        removeView(preview); preview = null
        BatteryWatcher.stop(this)
        removeView(handle); handle = null
        pins.forEach { removeView(it) }; pins.clear()
        removeView(otpChip); otpChip = null
        super.onDestroy()
    }

    private fun removeView(v: View?) {
        if (v == null) return
        try { wm.removeView(v) } catch (e: Exception) {}
    }

    // ---------- screenshot ----------

    /** Takes a screenshot (after [delayMs]) and opens the NB capture screen. */
    fun capture(delayMs: Long = 0) {
        shootAfter(delayMs) { bmp ->
            ShotHolder.bitmap = bmp
            startActivity(
                Intent(this, CaptureActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
            )
        }
    }

    /** Back tap: a normal screenshot, saved to the gallery, with a share preview. */
    fun quickShot() {
        removePreview()
        shootAfter(0) { bmp ->
            flash()
            buzz(this, 30)
            Thread {
                val uri = try { Share.saveScreenshot(this, bmp) } catch (e: Throwable) { CrashLog.note(this, "save screenshot", e); null }
                main.post {
                    if (uri == null) toast("Couldn't save the screenshot")
                    else safe("screenshot preview") { showPreview(bmp, uri) }
                }
            }.start()
        }
    }

    private fun shootAfter(delayMs: Long, onBitmap: (Bitmap) -> Unit) {
        if (capturing) return
        capturing = true
        handle?.visibility = View.INVISIBLE
        otpChip?.visibility = View.INVISIBLE
        main.postDelayed({ if (!safe("capture") { takeShot(onBitmap) }) afterShot() }, delayMs + 60)
    }

    private fun takeShot(onBitmap: (Bitmap) -> Unit) {
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : AccessibilityService.TakeScreenshotCallback {
            override fun onSuccess(result: AccessibilityService.ScreenshotResult) {
                var bmp: Bitmap? = null
                val ok = safe("screenshot") {
                    val buffer = result.hardwareBuffer
                    try {
                        val hw = Bitmap.wrapHardwareBuffer(buffer, result.colorSpace)
                        bmp = hw?.copy(Bitmap.Config.ARGB_8888, false)
                        hw?.recycle()
                    } finally {
                        buffer.close()
                    }
                }
                afterShot()
                val b = bmp
                if (!ok || b == null) { toast("Couldn't capture the screen"); return }
                safe("after screenshot") { onBitmap(b) }
            }

            override fun onFailure(errorCode: Int) {
                afterShot()
                // Asked too quickly after the last one: one quick retry.
                if (errorCode == AccessibilityService.ERROR_TAKE_SCREENSHOT_INTERVAL_TIME_SHORT) {
                    capturing = true
                    handle?.visibility = View.INVISIBLE
                    main.postDelayed({ if (!safe("capture retry") { takeShot(onBitmap) }) afterShot() }, 400)
                } else {
                    toast("This screen can't be captured")
                }
            }
        })
    }

    private fun afterShot() {
        capturing = false
        handle?.visibility = View.VISIBLE
        otpChip?.visibility = View.VISIBLE
    }

    // ---------- screenshot preview (back tap) ----------

    private fun flash() {
        val v = View(this).apply { setBackgroundColor(0xFFFFFFFF.toInt()); alpha = 0.7f }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        try {
            wm.addView(v, lp)
            v.animate().alpha(0f).setDuration(220).withEndAction { removeView(v) }.start()
        } catch (e: Exception) {}
    }

    private fun removePreview() {
        removeView(preview)
        preview = null
    }

    private fun showPreview(bmp: Bitmap, uri: android.net.Uri) {
        removePreview()
        val dm = resources.displayMetrics
        val thumbW = (dm.widthPixels * 0.28f).toInt()
        val thumbH = min((thumbW.toFloat() * bmp.height / bmp.width).toInt(), (dm.heightPixels * 0.4f).toInt())
        val thumb = Bitmap.createScaledBitmap(bmp, thumbW, thumbH, true)

        val card = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.HORIZONTAL
            background = roundBg(Ui.CARD, 18f, 0x55FFFFFF, 1)
            setPadding(dp(8), dp(8), dp(8), dp(8))
            elevation = dpf(10f)
        }
        val iv = ImageView(this).apply {
            setImageBitmap(thumb)
            scaleType = ImageView.ScaleType.FIT_XY
            background = roundBg(0xFF000000.toInt(), 10f)
            clipToOutline = true
            setOnClickListener { openImage(uri); removePreview() }
        }
        card.addView(iv, android.widget.LinearLayout.LayoutParams(thumbW, thumbH))

        val col = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(dp(8), 0, 0, 0)
        }
        fun btn(text: String, filled: Boolean, onClick: () -> Unit) {
            val b = label(text, 13f, if (filled) 0xFF10131A.toInt() else Ui.TEXT, true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(14), dp(9), dp(14), dp(9))
                background = if (filled) roundBg(Ui.ACCENT, 16f) else roundBg(Ui.CARD2, 16f)
                setOnClickListener { safe("preview button") { onClick() } }
            }
            col.addView(b, android.widget.LinearLayout.LayoutParams(dp(96), android.widget.LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(6)
            })
        }
        btn("Share", true) { shareImage(uri); removePreview() }
        btn("Search", false) {
            removePreview()
            ShotHolder.bitmap = bmp
            startActivity(Intent(this, CaptureActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
        }
        btn("Delete", false) {
            try { contentResolver.delete(uri, null, null); toast("Screenshot deleted") } catch (e: Exception) { toast("Couldn't delete") }
            removePreview()
        }
        btn("Close", false) { removePreview() }
        card.addView(col)

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.START
            x = dp(16)
            y = dp(90)
        }
        try {
            wm.addView(card, lp)
            preview = card
            main.postDelayed({ if (preview === card) removePreview() }, 8000)
        } catch (e: Exception) {
            toast("Screenshot saved")
        }
    }

    private fun shareImage(uri: android.net.Uri) {
        val send = Intent(Intent.ACTION_SEND)
            .setType("image/png")
            .putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        send.clipData = android.content.ClipData.newRawUri("screenshot", uri)
        startActivity(
            Intent.createChooser(send, "Share screenshot")
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        )
    }

    private fun openImage(uri: android.net.Uri) {
        try {
            startActivity(
                Intent(Intent.ACTION_VIEW).setDataAndType(uri, "image/png")
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        } catch (e: Exception) {
            toast("No gallery app found")
        }
    }

    // ---------- edge handle ----------

    private fun refreshHandle() {
        removeView(handle)
        handle = null
        if (!Prefs.on(this, Prefs.HANDLE)) return
        val left = Prefs.on(this, Prefs.HANDLE_LEFT)
        val v = buildHandle(left)
        val lp = WindowManager.LayoutParams(
            dp(22), dp(110),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = (if (left) Gravity.START else Gravity.END) or Gravity.TOP
            y = (resources.displayMetrics.heightPixels * 0.36f).toInt()
        }
        try {
            wm.addView(v, lp)
            handle = v
        } catch (e: Exception) {}
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun buildHandle(left: Boolean): View {
        val frame = FrameLayout(this)
        val bar = View(this).apply { background = roundBg(0x8CFFFFFF.toInt(), 3f) }
        frame.addView(bar, FrameLayout.LayoutParams(
            dp(5), dp(84),
            (if (left) Gravity.START else Gravity.END) or Gravity.CENTER_VERTICAL
        ).apply { if (left) leftMargin = dp(3) else rightMargin = dp(3) })

        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean { capture(80); return true }
            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (Prefs.on(this@NBAccessibilityService, Prefs.LOCK_DOUBLE_TAP)) performGlobalAction(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)
                return true
            }
            override fun onLongPress(e: MotionEvent) {
                startActivity(Intent(this@NBAccessibilityService, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, velocityX: Float, velocityY: Float): Boolean {
                val inward = if (left) velocityX > 500 else velocityX < -500
                if (inward && abs(velocityX) > abs(velocityY)) { capture(120); return true }
                return false
            }
        })
        frame.setOnTouchListener { _, ev -> safe("edge handle touch") { gd.onTouchEvent(ev) }; true }
        return frame
    }

    // ---------- pin to screen ----------

    @SuppressLint("ClickableViewAccessibility", "SetTextI18n")
    fun pin(bmp: Bitmap) {
        val dm = resources.displayMetrics
        val scale = min(1f, min(dm.widthPixels * 0.6f / bmp.width, dm.heightPixels * 0.45f / bmp.height))
        val w = (bmp.width * scale).toInt().coerceAtLeast(dp(48))
        val h = (bmp.height * scale).toInt().coerceAtLeast(dp(48))

        val card = FrameLayout(this).apply {
            background = roundBg(Ui.CARD, 14f, Ui.ACCENT, 2)
            setPadding(dp(3), dp(3), dp(3), dp(3))
            elevation = dpf(8f)
            clipToOutline = true
        }
        val iv = ImageView(this).apply {
            setImageBitmap(bmp)
            scaleType = ImageView.ScaleType.FIT_XY
        }
        card.addView(iv, FrameLayout.LayoutParams(w, h))
        val close = TextView(this).apply {
            text = "✕"
            textSize = 13f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            background = roundBg(0xCC000000.toInt(), 14f)
        }
        card.addView(close, FrameLayout.LayoutParams(dp(28), dp(28), Gravity.TOP or Gravity.END).apply {
            topMargin = dp(4); rightMargin = dp(4)
        })

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(24) + pins.size * dp(16)
            y = dp(140) + pins.size * dp(16)
        }

        var startX = 0; var startY = 0; var downRawX = 0f; var downRawY = 0f; var dragged = false
        iv.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y; downRawX = ev.rawX; downRawY = ev.rawY; dragged = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = ev.rawX - downRawX
                    val dy = ev.rawY - downRawY
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) dragged = true
                    if (dragged) {
                        lp.x = startX + dx.toInt()
                        lp.y = startY + dy.toInt()
                        try { wm.updateViewLayout(card, lp) } catch (e: Exception) {}
                    }
                }
                MotionEvent.ACTION_UP -> {
                    // Tap toggles see-through so you can read what's underneath.
                    if (!dragged) card.alpha = if (card.alpha > 0.9f) 0.45f else 1f
                }
            }
            true
        }
        close.setOnClickListener {
            removeView(card)
            pins.remove(card)
        }

        try {
            wm.addView(card, lp)
            pins.add(card)
        } catch (e: Exception) {
            toast("Couldn't pin")
        }
    }

    // ---------- OTP chip ----------

    @SuppressLint("SetTextI18n")
    fun showOtpChip(code: String) {
        main.post {
            removeView(otpChip)
            val chip = label("Copy code  $code", 15f, 0xFF10131A.toInt(), true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(18), dp(12), dp(18), dp(12))
                background = roundBg(Ui.ACCENT, 24f)
                elevation = dpf(8f)
            }
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                y = dp(56)
            }
            chip.setOnClickListener {
                Clip.copy(this, code, "Code copied")
                removeView(chip)
                if (otpChip === chip) otpChip = null
            }
            try {
                wm.addView(chip, lp)
                otpChip = chip
                main.postDelayed({
                    removeView(chip)
                    if (otpChip === chip) otpChip = null
                }, 12000)
            } catch (e: Exception) {
                Notifier.otp(this, code)
            }
        }
    }

    // ---------- motion sensors: shake for torch, back tap ----------

    private fun updateSensors() {
        val screenOn = getSystemService(PowerManager::class.java)?.isInteractive ?: true

        val wantShake = Prefs.on(this, Prefs.SHAKE_TORCH)
        if (wantShake && torch == null) torch = ShakeTorch(this)
        torch?.listen(wantShake && screenOn)
        if (!wantShake) { torch?.release(); torch = null }

        val wantTap = Prefs.on(this, Prefs.BACK_TAP)
        if (wantTap && backTap == null) backTap = BackTap(this) { onBackTap() }
        backTap?.threshold = Prefs.tapThreshold(this)
        backTap?.listen(wantTap && screenOn)
        if (!wantTap) { backTap?.release(); backTap = null }
    }

    private fun onBackTap() {
        if (capturing) return
        safe("back tap") { quickShot() }
    }
}
