package app.nb

import android.app.Activity
import android.app.AlarmManager
import android.app.PendingIntent
import android.app.Presentation
import android.app.TimePickerDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.hardware.display.DisplayManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import java.util.Calendar

/** Schedule helpers for rear-screen night mode. */
object Rear {
    fun nightStart(c: Context) = Prefs.int(c, Prefs.NIGHT_START, 23 * 60)
    fun nightEnd(c: Context) = Prefs.int(c, Prefs.NIGHT_END, 7 * 60)

    fun fmt(minutes: Int): String {
        val h = minutes / 60
        val m = minutes % 60
        val ampm = if (h < 12) "AM" else "PM"
        val h12 = if (h % 12 == 0) 12 else h % 12
        return "%d:%02d %s".format(h12, m, ampm)
    }

    fun isNightNow(c: Context): Boolean {
        val cal = Calendar.getInstance()
        val now = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        val s = nightStart(c)
        val e = nightEnd(c)
        return if (s == e) false else if (s < e) now in s until e else now >= s || now < e
    }

    /** Wakes NB at the next start/end time, even if the phone is asleep. */
    fun schedule(c: Context) {
        val am = c.getSystemService(AlarmManager::class.java) ?: return
        val pi = PendingIntent.getBroadcast(
            c, 11, Intent(c, RearNightReceiver::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        am.cancel(pi)
        if (!Prefs.on(c, Prefs.REAR_NIGHT)) return
        val next = minOf(nextAt(nightStart(c)), nextAt(nightEnd(c))) + 3000
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, pi)
    }

    private fun nextAt(minutes: Int): Long {
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, minutes / 60)
            set(Calendar.MINUTE, minutes % 60)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        if (cal.timeInMillis <= System.currentTimeMillis()) cal.add(Calendar.DAY_OF_YEAR, 1)
        return cal.timeInMillis
    }

    fun otherDisplays(c: Context): List<Display> =
        c.getSystemService(DisplayManager::class.java)?.displays
            ?.filter { it.displayId != Display.DEFAULT_DISPLAY } ?: emptyList()

    fun describe(d: Display): String {
        val mode = d.mode
        val flags = ArrayList<String>()
        if ((d.flags and Display.FLAG_PRIVATE) != 0) flags.add("private")
        if ((d.flags and Display.FLAG_PRESENTATION) != 0) flags.add("presentation")
        if ((d.flags and Display.FLAG_SECURE) != 0) flags.add("secure")
        if ((d.flags and Display.FLAG_ROUND) != 0) flags.add("round")
        val state = when (d.state) {
            Display.STATE_ON -> "on"
            Display.STATE_OFF -> "off"
            Display.STATE_DOZE -> "doze"
            Display.STATE_DOZE_SUSPEND -> "doze-suspend"
            else -> "state ${d.state}"
        }
        return "#${d.displayId} \"${d.name}\" ${mode.physicalWidth}×${mode.physicalHeight} $state flags=${d.flags} ${flags.joinToString(",")}"
    }
}

class RearNightReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        try {
            NBAccessibilityService.instance?.applyNight()
        } catch (e: Throwable) {
            CrashLog.note(context, "rear night", e)
        }
        Rear.schedule(context)
    }
}

/** Rear display page: test what NB can do on the second screen, and night mode. */
class RearActivity : Activity() {

    private lateinit var report: TextView
    private lateinit var status: TextView
    private lateinit var startValue: TextView
    private lateinit var endValue: TextView
    private val main = Handler(Looper.getMainLooper())
    private val lines = ArrayList<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setDecorFitsSystemWindows(false)

        val scroll = ScrollView(this).apply { setBackgroundColor(Ui.BG); isFillViewport = true }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(col)
        scroll.padForSystemBars(16)

        col.addView(label("Rear display", 26f, Ui.TEXT, true).apply { setPadding(dp(4), dp(8), 0, dp(4)) })
        col.addView(label("Find out what NB can show on the small screen on the back.", 14f, Ui.SUB).apply {
            setPadding(dp(4), 0, 0, dp(16))
        })

        // Test card
        val test = card(col, "Step 1 · Test")
        test.addView(label(
            "Tap Run test, then turn the phone over within 6 seconds and look for a blue \"NB\" on the rear screen.",
            14f, Ui.SUB
        ).apply { setPadding(0, 0, 0, dp(12)) })
        test.addView(bigButton("Run test") { runTest() })
        report = label("", 12f, Ui.TEXT).apply {
            typeface = android.graphics.Typeface.MONOSPACE
            setTextIsSelectable(true)
            setPadding(0, dp(12), 0, dp(8))
        }
        test.addView(report)
        test.addView(smallButton("Copy report") {
            if (lines.isEmpty()) toast("Run the test first") else Clip.copy(this, report.text.toString(), "Report copied")
        })

        // Night mode card
        val night = card(col, "Step 2 · Night mode")
        night.addView(label(
            "Covers the rear screen in black at minimum brightness during these hours. Android doesn't let apps switch the screen itself off, so this only works if the test shows NB can draw there.",
            13f, Ui.SUB
        ).apply { setPadding(0, 0, 0, dp(8)) })

        val swRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, dp(8))
        }
        swRow.addView(label("Black out rear screen at night", 15f), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val sw = Switch(this).apply {
            isChecked = Prefs.on(this@RearActivity, Prefs.REAR_NIGHT)
            setOnCheckedChangeListener { _, checked ->
                Prefs.set(this@RearActivity, Prefs.REAR_NIGHT, checked)
                if (checked && NBAccessibilityService.instance == null) toast("Turn on NB in Accessibility for this to work")
                main.postDelayed({ refreshStatus() }, 600)
            }
        }
        swRow.addView(sw)
        night.addView(swRow)

        startValue = timeRow(night, "From") { pickTime(Prefs.NIGHT_START, Rear.nightStart(this)) }
        endValue = timeRow(night, "Until") { pickTime(Prefs.NIGHT_END, Rear.nightEnd(this)) }
        status = label("", 13f, Ui.SUB).apply { setPadding(0, dp(10), 0, 0) }
        night.addView(status)

        setContentView(scroll)
        refreshTimes()
        refreshStatus()
    }

    // ---------- test ----------

    private fun runTest() {
        lines.clear()
        lines.add("NB 1.4 · Android ${android.os.Build.VERSION.SDK_INT} · ${android.os.Build.MODEL}")

        val dm = getSystemService(DisplayManager::class.java)
        val all = dm?.displays ?: emptyArray()
        lines.add("Displays found: ${all.size}")
        all.forEach { lines.add("  " + Rear.describe(it)) }
        val pres = dm?.getDisplays(DisplayManager.DISPLAY_CATEGORY_PRESENTATION) ?: emptyArray()
        lines.add("Presentation displays: ${pres.size}")

        val others = Rear.otherDisplays(this)
        if (others.isEmpty()) {
            lines.add("Result: Android does not share the rear screen with apps.")
        } else {
            // Method A: accessibility overlay on that display
            val svc = NBAccessibilityService.instance
            if (svc == null) lines.add("Method A (overlay): skipped, Accessibility is off")
            else others.forEach { lines.add("Method A (overlay) on #${it.displayId}: " + svc.testOnDisplay(it)) }

            // Method B: a normal Presentation window
            others.forEach { d ->
                lines.add("Method B (presentation) on #${d.displayId}: " + tryPresentation(d))
            }
        }

        lines.add("Settings keys that may control it:")
        lines.add(scanSettings())
        report.text = lines.joinToString("\n")
    }

    private fun tryPresentation(d: Display): String = try {
        val p = Presentation(this, d)
        p.setContentView(label("NB ✓", 40f, 0xFF10131A.toInt(), true).apply {
            gravity = Gravity.CENTER
            setBackgroundColor(Ui.ACCENT)
        })
        p.show()
        main.postDelayed({ try { p.dismiss() } catch (e: Exception) {} }, 6000)
        "shown"
    } catch (e: Throwable) {
        "failed (${e.javaClass.simpleName}: ${e.message?.take(80)})"
    }

    private fun scanSettings(): String {
        val sb = StringBuilder()
        val match = Regex(
            "(rear|sub[_-]?screen|sub[_-]?display|second|cover|aux|back[_-]?screen|minor|small[_-]?screen|external|outer|dual[_-]?screen)",
            RegexOption.IGNORE_CASE
        )
        for (table in listOf("system", "secure", "global")) {
            try {
                var total = 0
                var found = 0
                contentResolver.query(Uri.parse("content://settings/$table"), arrayOf("name", "value"), null, null, null)?.use { c ->
                    while (c.moveToNext()) {
                        total++
                        val n = c.getString(0) ?: continue
                        if (match.containsMatchIn(n) && found < 25) {
                            found++
                            sb.append("  $table: $n = ${c.getString(1)?.take(40)}\n")
                        }
                    }
                }
                sb.append("  $table: $total keys readable\n")
            } catch (e: Throwable) {
                sb.append("  $table: not readable (${e.javaClass.simpleName})\n")
            }
        }
        return sb.toString().trimEnd()
    }

    // ---------- night mode ----------

    private fun pickTime(key: String, current: Int) {
        TimePickerDialog(this, { _, h, m ->
            Prefs.setInt(this, key, h * 60 + m)
            refreshTimes()
            main.postDelayed({ refreshStatus() }, 600)
        }, current / 60, current % 60, false).show()
    }

    private fun refreshTimes() {
        startValue.text = Rear.fmt(Rear.nightStart(this)) + "  ›"
        endValue.text = Rear.fmt(Rear.nightEnd(this)) + "  ›"
    }

    private fun refreshStatus() {
        status.text = when {
            !Prefs.on(this, Prefs.REAR_NIGHT) -> "Night mode is off."
            NBAccessibilityService.instance == null -> "Waiting for NB Accessibility to be turned on."
            else -> "Status: " + (Prefs.sp(this).getString(Prefs.REAR_STATUS, null) ?: "waiting for the schedule")
        }
    }

    // ---------- view helpers ----------

    private fun card(parent: LinearLayout, title: String): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundBg(Ui.CARD, 20f)
            setPadding(dp(16), dp(14), dp(16), dp(16))
        }
        c.addView(label(title, 13f, Ui.ACCENT, true).apply { setPadding(0, 0, 0, dp(8)) })
        parent.addView(c, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = dp(12)
        })
        return c
    }

    private fun timeRow(parent: LinearLayout, title: String, onClick: () -> Unit): TextView {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), 0, dp(10))
            isClickable = true
            setOnClickListener { onClick() }
        }
        r.addView(label(title, 15f), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val v = label("", 15f, Ui.ACCENT, true)
        r.addView(v)
        parent.addView(r)
        return v
    }

    private fun smallButton(text: String, onClick: () -> Unit): TextView =
        label(text, 13f, Ui.TEXT, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(8), dp(14), dp(8))
            background = roundBg(Ui.CARD2, 16f)
            setOnClickListener { onClick() }
        }

    private fun bigButton(text: String, onClick: () -> Unit): TextView =
        label(text, 15f, 0xFF10131A.toInt(), true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = roundBg(Ui.ACCENT, 16f)
            setOnClickListener { onClick() }
        }
}
