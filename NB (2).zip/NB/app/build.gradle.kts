plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "app.nb"
    compileSdk = 35

    defaultConfig {
        applicationId = "app.nb"
        minSdk = 30
        targetSdk = 35
        versionCode = 3
        versionName = "1.2"

        // Honor Play 20a is 64-bit ARM; one ABI keeps the APK small.
        ndk { abiFilters += listOf("arm64-v8a") }
    }

    // A fixed key, so every new build installs as an update over the old one.
    signingConfigs {
        create("nb") {
            storeFile = file("nb-release.jks")
            storePassword = "nbapp2026"
            keyAlias = "nb"
            keyPassword = "nbapp2026"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("nb")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")

    // On-device ML Kit, bundled so it works offline and without Play services.
    implementation("com.google.mlkit:text-recognition:16.0.1")
    implementation("com.google.mlkit:barcode-scanning:17.3.0")
    implementation("com.google.mlkit:translate:17.0.3")
    implementation("com.google.mlkit:language-id:17.0.6")
}
