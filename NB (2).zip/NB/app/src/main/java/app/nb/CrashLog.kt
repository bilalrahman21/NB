package app.nb

import android.app.Application
import android.content.Context
import android.os.Build
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.util.Date

/** Saves error details on the phone so they can be shown (and copied) inside NB. */
object CrashLog {
    private fun file(c: Context) = File(c.filesDir, "crash.txt")

    fun install(app: Application) {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            write(app, "CRASH", e)
            previous?.uncaughtException(t, e)
        }
    }

    /** Records an error that NB caught and survived. */
    fun note(c: Context, where: String, e: Throwable) = write(c, "Error in $where", e)

    private fun write(c: Context, title: String, e: Throwable) {
        try {
            val sw = StringWriter()
            e.printStackTrace(PrintWriter(sw))
            val entry = "$title · ${Date()}\nNB 1.2 · Android ${Build.VERSION.SDK_INT} · ${Build.MODEL}\n${sw.toString().take(4000)}\n\n"
            val f = file(c)
            val old = if (f.exists()) f.readText().take(12000) else ""
            f.writeText(entry + old)
        } catch (x: Throwable) {
        }
    }

    fun read(c: Context): String? = try {
        file(c).takeIf { it.exists() }?.readText()?.takeIf { it.isNotBlank() }
    } catch (e: Throwable) {
        null
    }

    fun clear(c: Context) {
        try { file(c).delete() } catch (e: Throwable) {}
    }
}

class NBApp : Application() {
    override fun onCreate() {
        super.onCreate()
        CrashLog.install(this)
    }
}
