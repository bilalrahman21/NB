# NB

Circle to search and copy text from anywhere, for Android 11+ (built for Honor Play 20a, Android 16).

## Features
- **Circle to search**: circle anything, then Search (Google Lens), Copy text, Scan QR, Pin, Share or Save
- **Copy text anywhere**: tap a word, or hold and drag, then adjust with the handles (offline OCR)
- **Translate** selected text (English, Arabic, Hindi, Tamil, Urdu, French)
- **Scan QR codes** shown on screen
- **Pin to screen**: keep a cropped part floating over other apps (drag to move, tap for see-through)
- **Gestures**: double-tap the edge handle to lock, shake twice for the torch
- **Notification history**: keeps messages even if the sender deletes them
- **Clipboard history**: searchable, with pinning
- **One-tap OTP copy**
- **Battery full alert** at 85% or 100%

## Ways to open NB
- Tap or swipe inward on the thin edge handle
- Hold the gesture bar / home button (set NB as Digital assistant app)
- Quick Settings tile "NB search"
- The accessibility shortcut button

## Build
GitHub Actions builds `NB.apk` on every push (see the Releases page).
Locally: open in Android Studio, or run `./gradlew assembleRelease`.

## Install on the phone
1. Download `NB.apk` from Releases and install it (allow your browser/Files app to install unknown apps).
2. Open NB → Setup → **Accessibility** → turn on NB.
   If the switch is greyed out: App info → ⋮ → **Allow restricted settings**, then try again.
3. Turn on **Notification access** the same way.
4. Optional: set NB as **Digital assistant app** so holding the gesture bar opens it.
5. Allow alerts so the battery and OTP notifications can show.
