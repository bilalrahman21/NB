package app.nb

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Build
import android.widget.Toast

/** Copies text and keeps it in NB's clipboard history. */
object Clip {
    fun copy(c: Context, text: String, toast: String? = "Copied") {
        val cm = c.getSystemService(ClipboardManager::class.java) ?: return
        cm.setPrimaryClip(ClipData.newPlainText("NB", text))
        NBDb.get(c).addClip(text)
        // Android 13+ already shows its own "Copied" confirmation.
        if (toast != null && Build.VERSION.SDK_INT < 33) Toast.makeText(c, toast, Toast.LENGTH_SHORT).show()
    }

    /** Saves whatever is on the clipboard now. Only works while an NB screen has focus. */
    fun grabCurrent(c: Context): Boolean {
        val cm = c.getSystemService(ClipboardManager::class.java) ?: return false
        val item = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0) ?: return false
        val text = item.coerceToText(c)?.toString()?.trim().orEmpty()
        if (text.isEmpty()) return false
        val db = NBDb.get(c)
        if (db.latestClip() == text) return false
        db.addClip(text)
        return true
    }
}
