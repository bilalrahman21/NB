package app.nb

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Shows the frozen screenshot and handles:
 *  - drawing a circle/scribble around something (area select)
 *  - tapping a word, or holding and dragging, to select text
 *  - dragging the selection handles
 */
@SuppressLint("ViewConstructor")
class CaptureView(ctx: Context, private val shot: Bitmap) : View(ctx) {

    interface Listener {
        fun onArea(bitmapRect: Rect)
        fun onSelection(text: String)
        fun onCleared()
        fun onSelectionChanging()
        fun onTextNotReady()
    }

    data class Word(val text: String, val box: RectF, val line: Int)

    private enum class Mode { IDLE, DRAWING, AREA, TEXT }

    var listener: Listener? = null
    var ocrReady = false
        private set

    private var words: List<Word> = emptyList()
    private var mode = Mode.IDLE

    private var sx = 1f
    private var sy = 1f
    private val dst = Rect()

    private val path = Path()
    private var area: RectF? = null
    private var selStart = -1
    private var selEnd = -1
    private var dragging = 0 // 0 none, 1 start handle, 2 end handle

    private var downX = 0f
    private var downY = 0f
    private var moved = false
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop.toFloat()

    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val glowStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
        strokeWidth = ctx.dpf(16f); color = Ui.ACCENT; alpha = 90
    }
    private val lineStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
        strokeWidth = ctx.dpf(4f); color = 0xFFFFFFFF.toInt()
    }
    private val areaBorder = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = ctx.dpf(3f); color = Ui.ACCENT
    }
    private val selFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x668FA8FF }
    private val handlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Ui.ACCENT }
    private val handleStem = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Ui.ACCENT; strokeWidth = ctx.dpf(2f) }
    private val edgeGlow = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = ctx.dpf(7f) }
    private var glow = 0f
    private val tmp = RectF()

    private val longPress = Runnable { onLongPress() }

    init {
        ValueAnimator.ofFloat(0f, 1f, 0.35f, 0f).apply {
            duration = 1100
            addUpdateListener { glow = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    fun setWords(list: List<Word>) {
        words = list
        ocrReady = true
        invalidate()
    }

    fun hasText(): Boolean = words.isNotEmpty()

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        sx = shot.width / w.toFloat().coerceAtLeast(1f)
        sy = shot.height / h.toFloat().coerceAtLeast(1f)
        dst.set(0, 0, w, h)
        edgeGlow.shader = LinearGradient(
            0f, 0f, w.toFloat(), h.toFloat(),
            intArrayOf(Ui.ACCENT, Ui.ACCENT2, Ui.TEAL), null, Shader.TileMode.CLAMP
        )
    }

    // ---------- geometry ----------

    private fun toView(r: RectF, out: RectF = RectF()): RectF {
        out.set(r.left / sx, r.top / sy, r.right / sx, r.bottom / sy)
        return out
    }

    private fun wordAt(x: Float, y: Float): Int {
        val pad = context.dpf(10f)
        for (i in words.indices) {
            val v = toView(words[i].box, tmp)
            if (x >= v.left - pad && x <= v.right + pad && y >= v.top - pad && y <= v.bottom + pad) return i
        }
        return -1
    }

    private fun nearestWord(x: Float, y: Float): Int {
        var best = -1
        var bestD = Float.MAX_VALUE
        for (i in words.indices) {
            val v = toView(words[i].box, tmp)
            val dx = max(max(v.left - x, 0f), x - v.right)
            val dy = max(max(v.top - y, 0f), y - v.bottom)
            val d = dx + dy * 3f
            if (d < bestD) { bestD = d; best = i }
        }
        return best
    }

    private fun startHandle(): Pair<Float, Float>? {
        if (selStart < 0) return null
        val v = toView(words[selStart].box)
        return Pair(v.left, v.bottom + context.dpf(10f))
    }

    private fun endHandle(): Pair<Float, Float>? {
        if (selEnd < 0) return null
        val v = toView(words[selEnd].box)
        return Pair(v.right, v.bottom + context.dpf(10f))
    }

    // ---------- public actions ----------

    fun selectAll(): Boolean {
        if (words.isEmpty()) return false
        selStart = 0
        selEnd = words.size - 1
        mode = Mode.TEXT
        area = null
        path.reset()
        invalidate()
        listener?.onSelection(selectedText())
        return true
    }

    /** Selects the words that sit inside the circled area. */
    fun selectTextInArea(): Boolean {
        val a = area ?: return false
        var first = -1
        var last = -1
        for (i in words.indices) {
            val v = toView(words[i].box, tmp)
            if (a.contains(v.centerX(), v.centerY())) {
                if (first < 0) first = i
                last = i
            }
        }
        if (first < 0) return false
        selStart = first
        selEnd = last
        mode = Mode.TEXT
        area = null
        path.reset()
        invalidate()
        listener?.onSelection(selectedText())
        return true
    }

    /** Where the selected text is on screen, or null if nothing is selected. */
    fun selectionBounds(): RectF? {
        if (selStart < 0 || selEnd < 0) return null
        val r = toView(words[selStart].box)
        for (i in selStart + 1..selEnd) r.union(toView(words[i].box))
        return r
    }

    fun selectedText(): String {
        if (selStart < 0 || selEnd < 0) return ""
        val sb = StringBuilder()
        var prevLine = -1
        for (i in selStart..selEnd) {
            val w = words[i]
            if (sb.isNotEmpty()) sb.append(if (w.line != prevLine) "\n" else " ")
            sb.append(w.text)
            prevLine = w.line
        }
        return sb.toString()
    }

    fun areaBitmapRect(): Rect? {
        val a = area ?: return null
        val l = (a.left * sx).toInt().coerceIn(0, shot.width - 1)
        val t = (a.top * sy).toInt().coerceIn(0, shot.height - 1)
        val r = (a.right * sx).toInt().coerceIn(l + 1, shot.width)
        val b = (a.bottom * sy).toInt().coerceIn(t + 1, shot.height)
        return Rect(l, t, r, b)
    }

    fun clear() {
        mode = Mode.IDLE
        area = null
        selStart = -1
        selEnd = -1
        path.reset()
        invalidate()
    }

    // ---------- touch ----------

    private fun onLongPress() {
        if (moved) return
        if (!ocrReady) { listener?.onTextNotReady(); return }
        val i = wordAt(downX, downY)
        if (i < 0) return
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        selStart = i
        selEnd = i
        mode = Mode.TEXT
        area = null
        path.reset()
        dragging = 2
        listener?.onSelectionChanging()
        invalidate()
    }

    private fun dragTo(x: Float, y: Float) {
        // Look slightly above the finger so it doesn't hide the text.
        val i = nearestWord(x, y - context.dpf(28f))
        if (i < 0) return
        if (dragging == 1) {
            selStart = i
            if (selStart > selEnd) { val t = selStart; selStart = selEnd; selEnd = t; dragging = 2 }
        } else {
            selEnd = i
            if (selEnd < selStart) { val t = selStart; selStart = selEnd; selEnd = t; dragging = 1 }
        }
        invalidate()
    }

    private fun tapAt(x: Float, y: Float) {
        val i = if (ocrReady) wordAt(x, y) else -1
        if (i >= 0) {
            selStart = i
            selEnd = i
            mode = Mode.TEXT
            area = null
            path.reset()
            invalidate()
            listener?.onSelection(selectedText())
        } else {
            clear()
            if (!ocrReady) listener?.onTextNotReady() else listener?.onCleared()
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        val x = e.x
        val y = e.y
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                removeCallbacks(longPress)
                downX = x; downY = y; moved = false; dragging = 0
                if (mode == Mode.TEXT) {
                    val grab = context.dpf(32f)
                    val s = startHandle()
                    val en = endHandle()
                    if (en != null && hypot(x - en.first, y - en.second) < grab) { dragging = 2; listener?.onSelectionChanging(); return true }
                    if (s != null && hypot(x - s.first, y - s.second) < grab) { dragging = 1; listener?.onSelectionChanging(); return true }
                }
                path.reset()
                path.moveTo(x, y)
                postDelayed(longPress, 380)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (dragging != 0) { dragTo(x, y); return true }
                if (!moved && hypot(x - downX, y - downY) > slop) {
                    moved = true
                    removeCallbacks(longPress)
                    mode = Mode.DRAWING
                    area = null
                    selStart = -1; selEnd = -1
                }
                if (moved) {
                    for (h in 0 until e.historySize) path.lineTo(e.getHistoricalX(h), e.getHistoricalY(h))
                    path.lineTo(x, y)
                    invalidate()
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                removeCallbacks(longPress)
                if (dragging != 0) {
                    dragging = 0
                    listener?.onSelection(selectedText())
                    invalidate()
                    return true
                }
                if (e.actionMasked == MotionEvent.ACTION_CANCEL) { clear(); return true }
                if (!moved) {
                    tapAt(x, y)
                    return true
                }
                val b = RectF()
                path.computeBounds(b, true)
                val minSize = context.dpf(28f)
                if (b.width() < minSize && b.height() < minSize) {
                    tapAt(b.centerX(), b.centerY())
                    return true
                }
                val pad = context.dpf(8f)
                b.inset(-pad, -pad)
                b.left = max(0f, b.left); b.top = max(0f, b.top)
                b.right = min(width.toFloat(), b.right); b.bottom = min(height.toFloat(), b.bottom)
                area = b
                mode = Mode.AREA
                invalidate()
                areaBitmapRect()?.let { listener?.onArea(it) }
                return true
            }
        }
        return super.onTouchEvent(e)
    }

    // ---------- drawing ----------

    override fun onDraw(canvas: Canvas) {
        canvas.drawBitmap(shot, null, dst, bmpPaint)

        when (mode) {
            Mode.DRAWING -> {
                canvas.drawPath(path, glowStroke)
                canvas.drawPath(path, lineStroke)
            }
            Mode.AREA -> {
                val a = area
                if (a != null) {
                    canvas.save()
                    canvas.clipOutRect(a)
                    canvas.drawColor(0x99000000.toInt())
                    canvas.restore()
                    val r = context.dpf(16f)
                    canvas.drawRoundRect(a, r, r, areaBorder)
                }
            }
            Mode.TEXT -> {
                if (selStart >= 0 && selEnd >= 0) {
                    val grow = context.dpf(2f)
                    for (i in selStart..selEnd) {
                        val v = toView(words[i].box, tmp)
                        v.inset(-grow * 2, -grow)
                        canvas.drawRoundRect(v, grow * 2, grow * 2, selFill)
                    }
                    val radius = context.dpf(9f)
                    startHandle()?.let { (hx, hy) ->
                        canvas.drawLine(hx, hy - radius * 2.2f, hx, hy, handleStem)
                        canvas.drawCircle(hx, hy, radius, handlePaint)
                    }
                    endHandle()?.let { (hx, hy) ->
                        canvas.drawLine(hx, hy - radius * 2.2f, hx, hy, handleStem)
                        canvas.drawCircle(hx, hy, radius, handlePaint)
                    }
                }
            }
            Mode.IDLE -> {}
        }

        if (glow > 0f) {
            edgeGlow.alpha = (glow * 255).toInt().coerceIn(0, 255)
            val inset = edgeGlow.strokeWidth / 2
            val r = context.dpf(30f)
            canvas.drawRoundRect(inset, inset, width - inset, height - inset, r, r, edgeGlow)
        }
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(longPress)
        super.onDetachedFromWindow()
    }

    @Suppress("unused")
    private fun near(a: Float, b: Float) = abs(a - b) < 1f
}
