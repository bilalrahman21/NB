package app.nb

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject

/** Reminders set by voice. Kept on the phone and shown as notifications. */
object Reminders {
    data class Item(val id: Int, val text: String, val at: Long)

    private fun load(c: Context): MutableList<Item> {
        val raw = Prefs.sp(c).getString(Prefs.REMINDERS, "[]") ?: "[]"
        val out = ArrayList<Item>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                out.add(Item(o.optInt("id"), o.optString("text"), o.optLong("at")))
            }
        } catch (e: Exception) {
        }
        return out
    }

    private fun save(c: Context, list: List<Item>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("id", it.id).put("text", it.text).put("at", it.at)) }
        Prefs.sp(c).edit().putString(Prefs.REMINDERS, arr.toString()).apply()
    }

    fun list(c: Context): List<Item> {
        val now = System.currentTimeMillis()
        return load(c).filter { it.at > now }.sortedBy { it.at }
    }

    fun add(c: Context, text: String, at: Long): Item {
        val list = load(c).filter { it.at > System.currentTimeMillis() - 60_000 }.toMutableList()
        val id = ((at / 1000).toInt() xor text.hashCode()) and 0x7FFFFFFF
        val item = Item(id, text, at)
        list.removeAll { it.id == id }
        list.add(item)
        save(c, list)
        schedule(c, item)
        return item
    }

    fun cancel(c: Context, id: Int) {
        save(c, load(c).filter { it.id != id })
        alarmManager(c)?.cancel(pending(c, Item(id, "", 0)))
    }

    fun remove(c: Context, id: Int) = save(c, load(c).filter { it.id != id })

    fun rescheduleAll(c: Context) = list(c).forEach { schedule(c, it) }

    private fun alarmManager(c: Context) = c.getSystemService(AlarmManager::class.java)

    private fun pending(c: Context, r: Item): PendingIntent = PendingIntent.getBroadcast(
        c, r.id,
        Intent(c, ReminderReceiver::class.java).putExtra("id", r.id).putExtra("text", r.text),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun schedule(c: Context, r: Item) {
        val am = alarmManager(c) ?: return
        val pi = pending(c, r)
        try {
            if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, r.at, pi)
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, r.at, pi)
            }
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, r.at, pi)
        }
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getIntExtra("id", 0)
        val text = intent.getStringExtra("text") ?: return
        Notifier.reminder(context, id, text)
        Reminders.remove(context, id)
    }
}

/** After a restart, set reminders and the rear screen schedule again. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        try {
            Reminders.rescheduleAll(context)
            Rear.schedule(context)
        } catch (e: Throwable) {
            CrashLog.note(context, "after restart", e)
        }
    }
}
