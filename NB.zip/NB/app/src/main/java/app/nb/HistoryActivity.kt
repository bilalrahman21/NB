package app.nb

import android.app.Activity
import android.app.AlertDialog
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.text.format.DateUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView

/** Notification history and clipboard history, both searchable. */
class HistoryActivity : Activity() {

    companion object {
        const val MODE = "mode"
        const val NOTIF = "notif"
        const val CLIP = "clip"
    }

    private lateinit var mode: String
    private lateinit var adapter: Adapter
    private lateinit var empty: TextView
    private var query = ""
    private var notifs: List<NBDb.Notif> = emptyList()
    private var clips: List<NBDb.ClipItem> = emptyList()
    private val icons = HashMap<String, Drawable?>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setDecorFitsSystemWindows(false)
        mode = intent.getStringExtra(MODE) ?: NOTIF
        val isNotif = mode == NOTIF

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.BG)
        }
        root.padForSystemBars(12)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(4), dp(4), dp(12))
        }
        header.addView(
            label(if (isNotif) "Notification history" else "Clipboard history", 22f, Ui.TEXT, true),
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        header.addView(label("Clear", 14f, Ui.ACCENT, true).apply {
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setOnClickListener { confirmClear() }
        })
        root.addView(header)

        val search = EditText(this).apply {
            hint = "Search"
            setHintTextColor(Ui.SUB)
            setTextColor(Ui.TEXT)
            textSize = 15f
            setSingleLine(true)
            background = roundBg(Ui.CARD, 14f)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    query = s?.toString().orEmpty()
                    reload()
                }
            })
        }
        root.addView(search, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        root.addView(label(
            if (isNotif) "Tap to copy · hold for more" else "Tap to copy · hold to pin, share or delete",
            12f, Ui.SUB
        ).apply { setPadding(dp(4), dp(10), 0, dp(6)) })

        empty = label(
            if (isNotif) "Nothing yet. Turn on Notification access in NB, and new notifications will appear here."
            else "Nothing yet. Text you copy with NB, OTP codes, and anything on your clipboard when you open this screen will appear here.",
            14f, Ui.SUB
        ).apply { setPadding(dp(8), dp(24), dp(8), dp(8)); gravity = Gravity.CENTER }
        root.addView(empty)

        val list = ListView(this).apply {
            divider = null
            dividerHeight = 0
            setSelector(android.R.color.transparent)
        }
        adapter = Adapter()
        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ -> onTap(pos) }
        list.setOnItemLongClickListener { _, _, pos, _ -> onHold(pos); true }
        root.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        setContentView(root)
        reload()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        // Android only lets an app read the clipboard while it is on screen.
        if (hasFocus && mode == CLIP && Clip.grabCurrent(this)) reload()
    }

    private fun reload() {
        val db = NBDb.get(this)
        if (mode == NOTIF) notifs = db.notifs(query) else clips = db.clips(query)
        adapter.notifyDataSetChanged()
        empty.visibility = if (adapter.count == 0) View.VISIBLE else View.GONE
    }

    private fun onTap(pos: Int) {
        val text = if (mode == NOTIF) notifs[pos].body else clips[pos].body
        Clip.copy(this, text)
        if (mode == CLIP) reload()
    }

    private fun onHold(pos: Int) {
        if (mode == NOTIF) {
            val n = notifs[pos]
            AlertDialog.Builder(this)
                .setTitle(n.title.ifBlank { n.app })
                .setItems(arrayOf("Copy", "Open ${n.app}", "Delete")) { _, which ->
                    when (which) {
                        0 -> Clip.copy(this, n.body)
                        1 -> packageManager.getLaunchIntentForPackage(n.pkg)?.let { startActivity(it) } ?: toast("Can't open")
                        2 -> { NBDb.get(this).deleteNotif(n.id); reload() }
                        else -> {}
                    }
                }
                .show()
        } else {
            val c = clips[pos]
            AlertDialog.Builder(this)
                .setItems(arrayOf(if (c.pinned) "Unpin" else "Pin", "Share", "Delete")) { _, which ->
                    when (which) {
                        0 -> { NBDb.get(this).setPinned(c.id, !c.pinned); reload() }
                        1 -> Share.shareText(this, c.body)
                        2 -> { NBDb.get(this).deleteClip(c.id); reload() }
                        else -> {}
                    }
                }
                .show()
        }
    }

    private fun confirmClear() {
        val isNotif = mode == NOTIF
        AlertDialog.Builder(this)
            .setTitle(if (isNotif) "Clear notification history?" else "Clear clipboard history?")
            .setMessage(if (isNotif) "This can't be undone." else "Pinned items are kept.")
            .setPositiveButton("Clear") { _, _ ->
                if (isNotif) NBDb.get(this).clearNotifs() else NBDb.get(this).clearClips()
                reload()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun iconFor(pkg: String): Drawable? = icons.getOrPut(pkg) {
        try { packageManager.getApplicationIcon(pkg) } catch (e: Exception) { null }
    }

    private fun ago(t: Long): String =
        DateUtils.getRelativeTimeSpanString(t, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS).toString()

    private inner class Adapter : BaseAdapter() {
        override fun getCount(): Int = if (mode == NOTIF) notifs.size else clips.size
        override fun getItem(position: Int): Any = if (mode == NOTIF) notifs[position] else clips[position]
        override fun getItemId(position: Int): Long = if (mode == NOTIF) notifs[position].id else clips[position].id

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val holder = (convertView?.tag as? Holder) ?: makeHolder()
            if (mode == NOTIF) {
                val n = notifs[position]
                holder.icon.visibility = View.VISIBLE
                holder.icon.setImageDrawable(iconFor(n.pkg))
                holder.meta.text = "${n.app} · ${ago(n.time)}"
                holder.title.visibility = if (n.title.isBlank()) View.GONE else View.VISIBLE
                holder.title.text = n.title
                holder.body.text = n.body
            } else {
                val c = clips[position]
                holder.icon.visibility = View.GONE
                holder.meta.text = (if (c.pinned) "Pinned · " else "") + ago(c.time)
                holder.title.visibility = View.GONE
                holder.body.text = c.body
            }
            return holder.root
        }
    }

    private class Holder(val root: View, val icon: ImageView, val meta: TextView, val title: TextView, val body: TextView)

    private fun makeHolder(): Holder {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = roundBg(Ui.CARD, 16f)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            layoutParams = ViewGroup.MarginLayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        val icon = ImageView(this)
        root.addView(icon, LinearLayout.LayoutParams(dp(28), dp(28)).apply { marginEnd = dp(12); topMargin = dp(2) })
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val meta = label("", 12f, Ui.SUB)
        val title = label("", 15f, Ui.TEXT, true)
        val body = label("", 14f, Ui.TEXT).apply { maxLines = 6 }
        texts.addView(meta)
        texts.addView(title)
        texts.addView(body)
        root.addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        // Wrap in a frame so each card has a gap below it inside the ListView.
        val frame = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, dp(8))
        }
        frame.addView(root, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val h = Holder(frame, icon, meta, title, body)
        frame.tag = h
        return h
    }
}
