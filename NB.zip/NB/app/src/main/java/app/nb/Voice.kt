package app.nb

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognitionService
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.text.method.ScrollingMovementMethod
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.math.min
import kotlin.math.sin

/** The voice assistant sheet: listen → think (Gemini) → act → speak. */
class VoiceActivity : Activity(), AssistantUi {

    private enum class St { IDLE, LISTENING, THINKING, SPEAKING, CONFIRM }

    companion object {
        private const val REQ_MIC = 21
        private const val REQ_TOOL = 22
        const val EXTRA_SETUP = "setup_key"

        /** Picks a real speech recognizer (not NB's own placeholder). */
        fun createRecognizer(c: Context): SpeechRecognizer? {
            val services = try {
                c.packageManager.queryIntentServices(Intent(RecognitionService.SERVICE_INTERFACE), 0)
            } catch (e: Exception) { emptyList() }
            val others = services.map { ComponentName(it.serviceInfo.packageName, it.serviceInfo.name) }
                .filter { it.packageName != c.packageName }
            val pick = others.firstOrNull { it.packageName == "com.google.android.googlequicksearchbox" }
                ?: others.firstOrNull { it.packageName.startsWith("com.google") }
                ?: others.firstOrNull()
            if (pick != null) return SpeechRecognizer.createSpeechRecognizer(c, pick)
            if (Build.VERSION.SDK_INT >= 33 && SpeechRecognizer.isOnDeviceRecognitionAvailable(c)) {
                return SpeechRecognizer.createOnDeviceSpeechRecognizer(c)
            }
            return null
        }
    }

    private var st = St.IDLE
    private lateinit var orb: Orb
    private lateinit var status: TextView
    private lateinit var heard: TextView
    private lateinit var reply: TextView
    private lateinit var confirmBox: LinearLayout
    private lateinit var confirmText: TextView
    private lateinit var setupBtn: TextView
    private lateinit var typeRow: LinearLayout
    private lateinit var input: EditText

    private val main = Handler(Looper.getMainLooper())
    private val later = Handler(Looper.getMainLooper()) // survives the activity closing
    private var recognizer: SpeechRecognizer? = null
    private var brain: Brain? = null
    private var confirmMode = false
    private var askSeq = 0
    private var busyRetry = 0

    @Volatile private var leaving = false
    private val afterCloseActions = ArrayList<() -> Unit>()

    @Volatile private var confirmLatch: CountDownLatch? = null
    @Volatile private var confirmResult = false
    @Volatile private var permLatch: CountDownLatch? = null
    @Volatile private var permResult = false

    // ---------- lifecycle ----------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Works on the lock screen too; personal actions ask for unlock (see Tools).
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        window.setDecorFitsSystemWindows(false)
        Speaker.init(this)
        buildUi()
        brain = Brain(applicationContext, Tools(applicationContext, this))
        recognizer = try { createRecognizer(this) } catch (e: Throwable) { null }
        recognizer?.setRecognitionListener(listener)
        start()
    }

    private fun start() {
        if (!Gemini.hasKey(this)) {
            heard.text = ""
            reply.text = "To use the voice assistant, add your free Gemini API key in NB's settings first."
            setupBtn.visibility = View.VISIBLE
            setState(St.IDLE)
            return
        }
        setupBtn.visibility = View.GONE
        main.postDelayed({ listen() }, 180)
    }

    override fun onDestroy() {
        main.removeCallbacksAndMessages(null)
        try { recognizer?.destroy() } catch (e: Exception) {}
        recognizer = null
        confirmResult = false
        confirmLatch?.countDown()
        permResult = false
        permLatch?.countDown()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        closeNow(stopSpeech = true)
    }

    // ---------- UI ----------

    private fun buildUi() {
        val root = FrameLayout(this).apply {
            setOnClickListener { closeNow(stopSpeech = true) }
        }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            isClickable = true
            background = GradientDrawable().apply {
                setColor(Ui.CARD)
                val r = dpf(28f)
                cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
            }
            elevation = dpf(16f)
        }
        card.setOnApplyWindowInsetsListener { v, insets ->
            val b = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.ime()).bottom
            v.setPadding(dp(20), dp(14), dp(20), dp(18) + b)
            insets
        }
        root.addView(card, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM
        ))

        // Header
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(label("NB", 14f, Ui.ACCENT, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(label("✕", 18f, Ui.SUB, true).apply {
            setPadding(dp(12), dp(4), dp(4), dp(4))
            setOnClickListener { closeNow(stopSpeech = true) }
        })
        card.addView(header)

        heard = label("", 15f, Ui.SUB).apply { setPadding(0, dp(8), 0, 0) }
        card.addView(heard)
        reply = label("", 19f, Ui.TEXT).apply {
            setPadding(0, dp(8), 0, dp(4))
            setLineSpacing(0f, 1.15f)
            maxLines = 9
            movementMethod = ScrollingMovementMethod()
        }
        card.addView(reply)

        setupBtn = pill("Add API key in settings", filled = true) {
            startActivity(Intent(this, MainActivity::class.java).putExtra(EXTRA_SETUP, true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            closeNow(stopSpeech = true)
        }.apply { visibility = View.GONE }
        card.addView(setupBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(10)
        })

        // Confirm (calls and messages)
        confirmBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundBg(Ui.CARD2, 18f)
            setPadding(dp(16), dp(14), dp(16), dp(14))
            visibility = View.GONE
        }
        confirmText = label("", 16f, Ui.TEXT, true)
        confirmBox.addView(confirmText)
        val btns = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(12), 0, 0) }
        btns.addView(pill("Cancel") { answer(false) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginEnd = dp(8)
        })
        btns.addView(pill("Yes, go ahead", filled = true) { answer(true) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        confirmBox.addView(btns)
        card.addView(confirmBox, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(10)
        })

        // Type instead of talking
        typeRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            visibility = View.GONE
        }
        input = EditText(this).apply {
            hint = "Type to NB"
            setHintTextColor(Ui.SUB)
            setTextColor(Ui.TEXT)
            textSize = 16f
            background = roundBg(Ui.CARD2, 18f)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            imeOptions = EditorInfo.IME_ACTION_SEND
            setSingleLine(true)
            setOnEditorActionListener { _, id, _ ->
                if (id == EditorInfo.IME_ACTION_SEND) { sendTyped(); true } else false
            }
        }
        typeRow.addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        typeRow.addView(pill("Send", filled = true) { sendTyped() }, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { marginStart = dp(8) })
        card.addView(typeRow, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(12)
        })

        // Controls: keyboard · mic · circle search
        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(14), 0, 0)
        }
        controls.addView(roundButton("⌨") { toggleTyping() })
        orb = Orb(this).apply { setOnClickListener { onOrbTap() } }
        controls.addView(orb, LinearLayout.LayoutParams(dp(96), dp(96)).apply { marginStart = dp(28); marginEnd = dp(28) })
        controls.addView(roundButton("◎") {
            val svc = NBAccessibilityService.instance
            if (svc == null) toast("Turn on NB in Accessibility first")
            else { afterClose { svc.openCaptureFromVoice() }; closeNow(stopSpeech = true) }
        })
        card.addView(controls)
        status = label("", 13f, Ui.SUB).apply { gravity = Gravity.CENTER; setPadding(0, dp(6), 0, 0) }
        card.addView(status, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        setContentView(root)
    }

    private fun roundButton(text: String, onClick: () -> Unit): TextView =
        label(text, 20f, Ui.TEXT, false).apply {
            gravity = Gravity.CENTER
            background = roundBg(Ui.CARD2, 26f)
            layoutParams = LinearLayout.LayoutParams(dp(52), dp(52))
            setOnClickListener { onClick() }
        }

    private fun setState(s: St) {
        st = s
        orb.mode = when (s) {
            St.LISTENING -> 1
            St.THINKING -> 2
            St.SPEAKING -> 3
            St.CONFIRM -> if (confirmMode) 1 else 0
            St.IDLE -> 0
        }
        if (s != St.LISTENING) orb.level = 0f
        status.text = when (s) {
            St.IDLE -> "Tap the mic to talk"
            St.LISTENING -> "Listening…"
            St.THINKING -> "Thinking…"
            St.SPEAKING -> "Tap the mic to interrupt"
            St.CONFIRM -> "Say yes or no, or tap a button"
        }
        orb.invalidate()
    }

    private fun onOrbTap() {
        when (st) {
            St.LISTENING -> try { recognizer?.stopListening() } catch (e: Exception) {}
            St.THINKING -> {
                // Cancel: ignore the answer when it arrives and listen again.
                askSeq++
                setState(St.IDLE)
                status.text = "Cancelled. Tap the mic to talk."
            }
            else -> {
                Speaker.stop()
                if (!Gemini.hasKey(this)) start() else listen()
            }
        }
    }

    private fun toggleTyping() {
        val imm = getSystemService(InputMethodManager::class.java)
        if (typeRow.visibility == View.VISIBLE) {
            typeRow.visibility = View.GONE
            imm?.hideSoftInputFromWindow(input.windowToken, 0)
        } else {
            try { recognizer?.cancel() } catch (e: Exception) {}
            Speaker.stop()
            setState(St.IDLE)
            typeRow.visibility = View.VISIBLE
            input.requestFocus()
            imm?.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT)
        }
    }

    private fun sendTyped() {
        val t = input.text.toString().trim()
        if (t.isEmpty()) return
        input.setText("")
        if (confirmMode) { handleConfirmAnswer(t); return }
        onUserText(t)
    }

    // ---------- listening ----------

    private fun listen() {
        if (isFinishing) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_MIC)
            return
        }
        val r = recognizer
        if (r == null) {
            status.text = "Voice input isn't available on this phone. Type instead."
            if (typeRow.visibility != View.VISIBLE) toggleTyping()
            return
        }
        Speaker.stop()
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, Prefs.voiceLang(this))
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        try {
            r.cancel()
            r.startListening(i)
            if (!confirmMode) { heard.text = ""; }
            setState(if (confirmMode) St.CONFIRM else St.LISTENING)
            if (confirmMode) { orb.mode = 1; status.text = "Listening for yes or no…" }
        } catch (e: Exception) {
            CrashLog.note(this, "start listening", e)
            status.text = "Couldn't start the microphone. Tap to try again."
        }
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {
            orb.level = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
        }
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {
            orb.level = 0f
        }
        override fun onPartialResults(partialResults: Bundle?) {
            val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (!t.isNullOrBlank()) heard.text = t
        }
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onResults(results: Bundle?) {
            busyRetry = 0
            val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
            if (confirmMode) { handleConfirmAnswer(t); return }
            if (t.isBlank()) { setState(St.IDLE); status.text = "I didn't catch that. Tap the mic to try again."; return }
            onUserText(t)
        }

        override fun onError(error: Int) {
            orb.level = 0f
            if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY && busyRetry < 2) {
                busyRetry++
                main.postDelayed({ listen() }, 400)
                return
            }
            busyRetry = 0
            if (confirmMode) {
                setState(St.CONFIRM)
                return
            }
            setState(St.IDLE)
            status.text = when (error) {
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "I didn't catch that. Tap the mic to try again."
                SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Voice needs internet. Check your connection."
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "NB needs microphone permission."
                SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED, SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE ->
                    "That voice language isn't available. Change it in NB's settings."
                else -> "Voice input stopped. Tap the mic to try again."
            }
        }
    }

    // ---------- thinking & replying ----------

    private fun onUserText(text: String) {
        val b = brain ?: return
        heard.text = text
        reply.text = ""
        confirmBox.visibility = View.GONE
        setState(St.THINKING)
        val seq = ++askSeq
        main.postDelayed({ if (seq == askSeq && st == St.THINKING) status.text = "Still thinking… tap the mic to cancel" }, 7000)
        Thread {
            val out = try {
                b.ask(text)
            } catch (e: Gemini.ApiError) {
                e.message ?: "The AI service had a problem."
            } catch (e: java.io.IOException) {
                CrashLog.note(applicationContext, "assistant network", e)
                Gemini.networkMessage(applicationContext, e)
            } catch (e: Throwable) {
                CrashLog.note(applicationContext, "assistant", e)
                "Sorry, something went wrong."
            }
            main.post { if (seq == askSeq) showReply(out) }
        }.start()
    }

    private fun showReply(text: String) {
        reply.text = text
        reply.scrollTo(0, 0)
        val closing = leaving
        if (Prefs.on(this, Prefs.SPEAK)) {
            setState(St.SPEAKING)
            Speaker.speak(this, text, Prefs.voiceLang(this)) { if (!closing) afterReply(text) }
            Speaker.missingVoice?.let { lang ->
                status.text = "No $lang voice installed. Settings → Text-to-speech → Google → Install voice data."
            }
        } else {
            setState(St.IDLE)
            if (!closing) afterReply(text)
        }
        // An app was opened, or an action needs the screen: get out of the way.
        if (closing) main.postDelayed({ closeNow(stopSpeech = false) }, 700)
    }

    private fun afterReply(text: String) {
        if (isFinishing || isDestroyed) return
        // NB asked a question: listen for the answer.
        if (text.trim().endsWith("?")) listen() else setState(St.IDLE)
    }

    private fun closeNow(stopSpeech: Boolean) {
        if (stopSpeech) Speaker.stop()
        try { recognizer?.cancel() } catch (e: Exception) {}
        val actions = synchronized(afterCloseActions) { ArrayList(afterCloseActions).also { afterCloseActions.clear() } }
        finish()
        @Suppress("DEPRECATION")
        overridePendingTransition(0, android.R.anim.fade_out)
        if (actions.isNotEmpty()) {
            later.postDelayed({
                for (a in actions) {
                    try { a() } catch (e: Throwable) { CrashLog.note(applicationContext, "after close", e) }
                }
            }, 550)
        }
    }

    // ---------- confirmation ----------

    private fun showConfirm(prompt: String) {
        confirmMode = true
        confirmText.text = prompt
        confirmBox.visibility = View.VISIBLE
        setState(St.CONFIRM)
        if (Prefs.on(this, Prefs.SPEAK)) {
            Speaker.speak(this, "$prompt Should I go ahead?", Prefs.voiceLang(this)) { if (confirmMode) listen() }
        } else {
            listen()
        }
    }

    private fun answer(yes: Boolean) {
        if (!confirmMode) return
        confirmMode = false
        try { recognizer?.cancel() } catch (e: Exception) {}
        Speaker.stop()
        confirmBox.visibility = View.GONE
        setState(St.THINKING)
        confirmResult = yes
        confirmLatch?.countDown()
    }

    private fun handleConfirmAnswer(raw: String) {
        // Keep letters AND vowel signs (\p{M}), which Malayalam words need.
        val t = " " + raw.lowercase(Locale.ROOT).replace(Regex("[^\\p{L}\\p{M}\\p{N} ]"), " ") + " "
        val noScript = listOf("വേണ്ട", "കണ്ട", "ഇല്ല", "ക്യാൻസൽ", "നിർത്ത", "നഹീ", "नहीं", "मत", "لا")
        val yesScript = listOf("ശരി", "ശെരി", "അതെ", "ഓക്കെ", "ഓകെ", "ഉവ്വ്", "അയക്ക", "വിളിക്ക", "ചെയ്യ്", "ചെയ്യൂ",
            "हाँ", "हां", "ठीक", "भेज", "نعم", "أيوه", "ايوه", "تمام")
        if (noScript.any { raw.contains(it) }) { answer(false); return }
        if (yesScript.any { raw.contains(it) }) { answer(true); return }
        val no = listOf(" no ", " nope ", " cancel ", " stop ", " don't ", " dont ", " not ", " wait ", " venda ", " illa ", " nahi ", " nahin ", " la ")
        val yes = listOf(" yes ", " yeah ", " yep ", " yup ", " ok ", " okay ", " sure ", " send ", " call ", " go ", " do it ", " confirm ",
            " haan ", " han ", " ha ", " aan ", " athe ", " sari ", " shari ", " theek ", " na'am ", " naam ", " aywa ")
        when {
            no.any { t.contains(it) } -> answer(false)
            yes.any { t.contains(it) } -> answer(true)
            else -> {
                setState(St.CONFIRM)
                status.text = "Tap Yes or Cancel"
            }
        }
    }

    // ---------- AssistantUi (called from the background thread) ----------

    override fun confirm(prompt: String): Boolean {
        val latch = CountDownLatch(1)
        confirmLatch = latch
        confirmResult = false
        main.post { showConfirm(prompt) }
        latch.await(90, TimeUnit.SECONDS)
        if (confirmMode) main.post { answer(false) }
        return confirmResult
    }

    override fun ensurePermissions(perms: Array<String>): Boolean {
        val missing = perms.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) return true
        if (isFinishing || isDestroyed) return false
        val latch = CountDownLatch(1)
        permLatch = latch
        permResult = false
        main.post { requestPermissions(missing.toTypedArray(), REQ_TOOL) }
        latch.await(60, TimeUnit.SECONDS)
        return permResult
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        val all = grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }
        when (requestCode) {
            REQ_MIC -> if (all) listen() else {
                setState(St.IDLE)
                status.text = "NB needs the microphone to hear you. You can type instead (⌨)."
            }
            REQ_TOOL -> {
                permResult = all
                permLatch?.countDown()
            }
        }
    }

    override fun ensureUnlocked(): Boolean {
        val km = getSystemService(android.app.KeyguardManager::class.java) ?: return true
        if (!km.isKeyguardLocked) return true
        if (isFinishing || isDestroyed) return false
        val latch = CountDownLatch(1)
        var ok = false
        main.post {
            status.text = "Unlock your phone to continue"
            km.requestDismissKeyguard(this, object : android.app.KeyguardManager.KeyguardDismissCallback() {
                override fun onDismissSucceeded() { ok = true; latch.countDown() }
                override fun onDismissCancelled() { latch.countDown() }
                override fun onDismissError() { latch.countDown() }
            })
        }
        latch.await(60, TimeUnit.SECONDS)
        if (ok) main.post { if (st == St.THINKING) status.text = "Thinking…" }
        return ok
    }

    override fun markLeaving() {
        leaving = true
    }

    override fun afterClose(action: () -> Unit) {
        synchronized(afterCloseActions) { afterCloseActions.add(action) }
        leaving = true
    }

    override fun screenText(): String? {
        val b = VoiceShot.bitmap ?: return null
        val rec = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        return try {
            Tasks.await(rec.process(InputImage.fromBitmap(b, 0)), 12, TimeUnit.SECONDS).text
        } catch (e: Exception) {
            null
        } finally {
            rec.close()
        }
    }
}

/** The glowing mic button. Grows with your voice, pulses while thinking or speaking. */
class Orb(ctx: Context) : View(ctx) {
    /** 0 idle, 1 listening, 2 thinking, 3 speaking */
    var mode = 0
        set(v) { field = v; postInvalidateOnAnimation() }
    var level = 0f
        set(v) { field = v; postInvalidateOnAnimation() }

    private var shown = 0f
    private var phase = 0f
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val mic = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF10131A.toInt() }
    private val micLine = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF10131A.toInt(); style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND
    }
    private val spin = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xCCFFFFFF.toInt(); style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND
    }
    private val rect = RectF()

    @SuppressLint("DrawAllocation")
    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val base = min(width, height) / 2f * 0.62f
        shown += (level - shown) * 0.35f
        phase += 0.07f
        val pulse = when (mode) {
            1 -> shown
            2 -> ((sin(phase * 2f) + 1f) / 2f) * 0.35f
            3 -> ((sin(phase * 3f) + 1f) / 2f) * 0.25f
            else -> 0f
        }

        fill.shader = RadialGradient(cx, cy, base * 1.6f, intArrayOf(0x668FA8FF, 0x008FA8FF), null, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, base * (1.25f + pulse * 0.45f), fill)
        fill.shader = LinearGradient(cx - base, cy - base, cx + base, cy + base,
            intArrayOf(Ui.ACCENT, Ui.ACCENT2, Ui.TEAL), null, Shader.TileMode.CLAMP)
        val r = base * (1f + pulse * 0.18f)
        c.drawCircle(cx, cy, r, fill)

        if (mode == 2) {
            spin.strokeWidth = base * 0.08f
            rect.set(cx - r - base * 0.12f, cy - r - base * 0.12f, cx + r + base * 0.12f, cy + r + base * 0.12f)
            c.drawArc(rect, (phase * 120f) % 360f, 70f, false, spin)
        }

        // Mic glyph
        val w = base * 0.30f
        val h = base * 0.52f
        rect.set(cx - w / 2f, cy - h * 0.72f, cx + w / 2f, cy + h * 0.28f)
        c.drawRoundRect(rect, w / 2f, w / 2f, mic)
        micLine.strokeWidth = base * 0.07f
        rect.set(cx - w * 0.95f, cy - h * 0.45f, cx + w * 0.95f, cy + h * 0.52f)
        c.drawArc(rect, 20f, 140f, false, micLine)
        c.drawLine(cx, cy + h * 0.52f, cx, cy + h * 0.78f, micLine)

        if (mode != 0 || kotlin.math.abs(shown - level) > 0.01f) postInvalidateOnAnimation()
    }
}
