package app.nb

import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.WindowInsets
import android.widget.TextView

/** Small helpers so the UI can be built in code without layout XML. */
object Ui {
    const val BG = 0xFF0F1115.toInt()
    const val CARD = 0xFF1A1D24.toInt()
    const val CARD2 = 0xFF232733.toInt()
    const val TEXT = 0xFFEDEFF3.toInt()
    const val SUB = 0xFF9AA0AB.toInt()
    const val ACCENT = 0xFF8FA8FF.toInt()
    const val ACCENT2 = 0xFFC9A6FF.toInt()
    const val TEAL = 0xFF5EEAD4.toInt()
    const val OK = 0xFF4ADE80.toInt()
    const val WARN = 0xFFFBBF24.toInt()
    const val SCRIM = 0xCC15171D.toInt()
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
fun Context.dpf(v: Float): Float = v * resources.displayMetrics.density

fun Context.roundBg(color: Int, radiusDp: Float, strokeColor: Int? = null, strokeDp: Int = 1): GradientDrawable =
    GradientDrawable().apply {
        setColor(color)
        cornerRadius = dpf(radiusDp)
        if (strokeColor != null) setStroke(dp(strokeDp), strokeColor)
    }

fun Context.label(text: CharSequence, sizeSp: Float = 15f, color: Int = Ui.TEXT, bold: Boolean = false): TextView =
    TextView(this).apply {
        this.text = text
        setTextColor(color)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp)
        if (bold) typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }

/** A rounded "pill" button. */
fun Context.pill(text: String, filled: Boolean = false, onClick: () -> Unit): TextView =
    label(text, 14f, if (filled) 0xFF10131A.toInt() else Ui.TEXT, bold = true).apply {
        gravity = Gravity.CENTER
        setPadding(dp(16), dp(10), dp(16), dp(10))
        background = if (filled) roundBg(Ui.ACCENT, 22f) else roundBg(Ui.SCRIM, 22f, 0x33FFFFFF, 1)
        isClickable = true
        isFocusable = true
        setOnClickListener { onClick() }
    }

/** Pads a root view so content stays clear of the status and navigation bars. */
fun View.padForSystemBars(extraDp: Int = 0) {
    val extra = context.dp(extraDp)
    setOnApplyWindowInsetsListener { v, insets ->
        val bars = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
        v.setPadding(bars.left + extra, bars.top + extra, bars.right + extra, bars.bottom + extra)
        insets
    }
    requestApplyInsets()
}
