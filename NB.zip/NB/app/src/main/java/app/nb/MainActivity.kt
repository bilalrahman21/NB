package app.nb

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.NotificationManager
import android.app.role.RoleManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

/** Home screen: setup checklist, history shortcuts and settings. */
class MainActivity : Activity() {

    private class Row(val status: TextView, val button: TextView)

    private lateinit var accRow: Row
    private lateinit var notifRow: Row
    private lateinit var assistRow: Row
    private lateinit var permRow: Row
    private lateinit var langValue: TextView
    private lateinit var sensValue: TextView
    private lateinit var keyRow: LinearLayout
    private lateinit var keyStatus: TextView
    private lateinit var keyValue: TextView
    private val voiceLangs = listOf(
        "en-IN" to "English (India)",
        "en-US" to "English (US)",
        "en-GB" to "English (UK)",
        "ml-IN" to "Malayalam",
        "hi-IN" to "Hindi",
        "ar-AE" to "Arabic",
        "ta-IN" to "Tamil",
        "ur-PK" to "Urdu"
    )
    private lateinit var crashBox: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setDecorFitsSystemWindows(false)

        val scroll = ScrollView(this).apply { setBackgroundColor(Ui.BG); isFillViewport = true }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(col)
        scroll.padForSystemBars(16)

        // Header
        col.addView(label("NB", 34f, Ui.TEXT, true).apply { setPadding(dp(4), dp(8), 0, 0) })
        col.addView(label("Circle to search · copy text anywhere", 14f, Ui.SUB).apply { setPadding(dp(4), 0, 0, dp(16)) })

        // Error report (only shown if NB hit a problem)
        crashBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundBg(0xFF3A1F24.toInt(), 20f, 0xFFF87171.toInt(), 1)
            setPadding(dp(16), dp(14), dp(16), dp(16))
            visibility = android.view.View.GONE
        }
        col.addView(crashBox, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = dp(12)
        })

        // Setup
        val setup = card(col, "Setup")
        accRow = row(setup, "Accessibility", "Needed for capture, edge handle, pin, torch and battery alert") { openAccessibility() }
        notifRow = row(setup, "Notification access", "Needed for notification history and OTP copy") { openNotificationAccess() }
        assistRow = row(setup, "Hold gesture bar to open", "Set NB as the Digital assistant app") { openAssistant() }
        permRow = row(setup, "Show alerts", "Lets NB show the battery and OTP alerts") { askNotifPermission() }
        setup.addView(label(
            "If a switch is greyed out: open App info, tap ⋮ (top right), choose \"Allow restricted settings\", then try again.",
            13f, Ui.WARN
        ).apply { setPadding(0, dp(12), 0, dp(8)) })
        setup.addView(smallButton("Open App info") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        })

        // Voice assistant
        val va = card(col, "Voice assistant")
        va.addView(label(
            "Hold the gesture bar (with NB as Digital assistant) or swipe in from the edge handle and hold, then just talk: \"turn on the torch\", \"send WhatsApp to Ahmed I'm on my way\", \"remind me at 6 to call mum\".",
            13f, Ui.SUB
        ).apply { setLineSpacing(0f, 1.2f); setPadding(0, 0, 0, dp(12)) })
        va.addView(bigButton("Talk to NB") {
            val svc = NBAccessibilityService.instance
            if (svc != null) { moveTaskToBack(true); svc.openAssistant(400) }
            else startActivity(Intent(this, VoiceActivity::class.java))
        })
        keyRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(14), 0, dp(8))
            isClickable = true
            setOnClickListener { askForKey() }
        }
        val keyTexts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        keyTexts.addView(label("Gemini API key", 15f))
        keyStatus = label("", 12.5f, Ui.SUB)
        keyTexts.addView(keyStatus)
        keyRow.addView(keyTexts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        keyValue = label("", 15f, Ui.ACCENT, true)
        keyRow.addView(keyValue)
        va.addView(keyRow)
        va.addView(bigButton("Test AI connection", filled = false) { runDiagnosis() })
        choice(va, "Voice language", "The language you speak to NB in",
            voiceLangs.map { it.second }, { voiceLangs.indexOfFirst { it.first == Prefs.voiceLang(this) }.coerceAtLeast(0) }) {
            Prefs.sp(this).edit().putString(Prefs.VOICE_LANG, voiceLangs[it].first).apply()
        }
        choice(va, "Listening patience", "How long NB waits while you pause",
            listOf("Short", "Normal", "Long (until you stop)"), { Prefs.int(this, Prefs.LISTEN_MODE, 2) }) {
            Prefs.setInt(this, Prefs.LISTEN_MODE, it)
        }
        toggle(va, "Keep listening after replies", "Talk back and forth without tapping. Close the panel or stay quiet to stop.", Prefs.KEEP_LISTENING)
        toggle(va, "Speak replies", "Off = replies are shown as text only", Prefs.SPEAK)
        choice(va, "Holding the gesture bar opens", "Needs NB set as Digital assistant",
            listOf("Voice assistant", "Circle to search"), { Prefs.assistAction(this) }) { Prefs.setInt(this, Prefs.ASSIST_ACTION, it) }

        // Try it
        val tryCard = card(col, "Open NB")
        tryCard.addView(label(
            "• Tap the back of the phone (held steady) for a screenshot you can share\n• Edge handle: swipe in to search, swipe in and hold to talk to NB, hold for the menu, triple-tap for a screenshot\n• Hold the gesture bar (after setting NB as assistant)\n• Pull down Quick Settings and add the \"NB search\" tile",
            14f, Ui.SUB
        ).apply { setLineSpacing(0f, 1.25f); setPadding(0, 0, 0, dp(12)) })
        tryCard.addView(bigButton("Try it now") {
            val svc = NBAccessibilityService.instance
            if (svc == null) toast("Turn on Accessibility first") else { moveTaskToBack(true); svc.capture(500) }
        })

        // Rear display
        val rear = card(col, "Rear display")
        rear.addView(label("Turn the back screen off at night, or on/off any time", 13f, Ui.SUB).apply { setPadding(0, 0, 0, dp(10)) })
        rear.addView(bigButton("Rear screen schedule", filled = false) {
            startActivity(Intent(this, RearActivity::class.java))
        })

        // History
        val hist = card(col, "History")
        hist.addView(bigButton("Notification history", filled = false) {
            startActivity(Intent(this, HistoryActivity::class.java).putExtra(HistoryActivity.MODE, HistoryActivity.NOTIF))
        })
        hist.addView(spacer(8))
        hist.addView(bigButton("Clipboard history", filled = false) {
            startActivity(Intent(this, HistoryActivity::class.java).putExtra(HistoryActivity.MODE, HistoryActivity.CLIP))
        })

        // Settings
        val set = card(col, "Settings")
        toggle(set, "Search right after circling", "Off = show Copy, Pin, Save options first", Prefs.AUTO_SEARCH)
        toggle(set, "Edge handle", "Swipe in to search · swipe in and hold for voice · hold for menu · triple-tap for screenshot", Prefs.HANDLE)
        toggle(set, "Handle on left side", "Off = right side", Prefs.HANDLE_LEFT)
        choice(set, "Handle position", "Move it away from buttons you tap often",
            listOf("Top", "Middle", "Bottom"), { Prefs.handlePos(this) }) { Prefs.setInt(this, Prefs.HANDLE_POS, it) }
        toggle(set, "Triple-tap handle for screenshot", "Saves it and shows Share", Prefs.HANDLE_TRIPLE_SHOT)
        toggle(set, "Double-tap handle to lock", "Off by default to avoid accidental locks", Prefs.LOCK_DOUBLE_TAP)
        toggle(set, "Back tap screenshot", "Tap the back of the phone while holding it steady", Prefs.BACK_TAP)
        choice(set, "Taps needed", "Triple tap almost never triggers by accident",
            listOf("Double tap", "Triple tap"), { Prefs.tapCount(this) - 2 }) { Prefs.setInt(this, Prefs.TAP_COUNT, it + 2) }

        val sensRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, dp(8))
            isClickable = true
            setOnClickListener { chooseSensitivity() }
        }
        val sensTexts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        sensTexts.addView(label("Back tap sensitivity", 15f))
        sensTexts.addView(label("Low = firm taps only, fewest accidents", 12.5f, Ui.SUB))
        sensRow.addView(sensTexts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        sensValue = label(sensName(Prefs.tapSens(this)) + "  ›", 15f, Ui.ACCENT, true)
        sensRow.addView(sensValue)
        set.addView(sensRow)

        toggle(set, "Shake for torch", "Shake the phone twice quickly", Prefs.SHAKE_TORCH)
        toggle(set, "OTP copy button", "Shows \"Copy code\" when a code arrives", Prefs.OTP)
        toggle(set, "Battery full alert", "Reminds you to unplug", Prefs.BATTERY)
        toggle(set, "Alert at 85%", "Off = alert at 100%", Prefs.BATTERY_85)

        val langRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(12), 0, dp(4))
            isClickable = true
            setOnClickListener { chooseLanguage() }
        }
        langRow.addView(label("Translate to", 15f), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        langValue = label(NBTranslate.name(Prefs.lang(this)) + "  ›", 15f, Ui.ACCENT, true)
        langRow.addView(langValue)
        set.addView(langRow)

        col.addView(label(
            "Text copying reads English and other Latin-script text. Everything stays on your phone unless you tap Search or Translate.",
            12f, Ui.SUB
        ).apply { setPadding(dp(4), dp(8), dp(4), dp(24)) })

        setContentView(scroll)
        if (intent?.getBooleanExtra(VoiceActivity.EXTRA_SETUP, false) == true) scroll.post { askForKey() }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    // ---------- status ----------

    private fun accessibilityOn(): Boolean {
        if (NBAccessibilityService.instance != null) return true
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return enabled.contains("$packageName/")
    }

    private fun notifAccessOn(): Boolean {
        val nm = getSystemService(NotificationManager::class.java)
        return nm.isNotificationListenerAccessGranted(ComponentName(this, NBNotificationListener::class.java))
    }

    private fun assistantOn(): Boolean = try {
        getSystemService(RoleManager::class.java)?.isRoleHeld(RoleManager.ROLE_ASSISTANT) == true
    } catch (e: Exception) {
        false
    }

    private fun refreshKey() {
        if (Gemini.hasKey(this)) {
            keyValue.text = "Change  ›"
            keyStatus.text = "Saved · model " + Gemini.model(this)
        } else {
            keyValue.text = "Add  ›"
            keyStatus.text = "Needed for the voice assistant (free)"
        }
    }

    private fun askForKey() {
        val box = android.widget.EditText(this).apply {
            hint = "Paste your key here"
            setSingleLine(true)
            setText(Gemini.key(this@MainActivity))
            setPadding(dp(20), dp(16), dp(20), dp(16))
        }
        AlertDialog.Builder(this)
            .setTitle("Gemini API key")
            .setMessage(
                "1. Tap \"Get free key\" and sign in with your Google account.\n" +
                    "2. Tap \"Create API key\" and copy it.\n" +
                    "3. Come back and paste it here.\n\n" +
                    "The key stays on your phone. Your questions go to Google's Gemini service."
            )
            .setView(box)
            .setPositiveButton("Save") { _, _ ->
                val k = box.text.toString().trim()
                Prefs.sp(this).edit().putString(Prefs.AI_KEY, k).remove(Prefs.AI_MODEL).remove(Prefs.AI_THINK).remove(Prefs.AI_FALLBACKS).apply()
                refreshKey()
                if (k.isNotEmpty()) testKey()
            }
            .setNeutralButton("Get free key") { _, _ ->
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/apikey")))
                } catch (e: Exception) {
                    toast("No browser found")
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun runDiagnosis() {
        if (!Gemini.hasKey(this)) { toast("Add your Gemini API key first"); return }
        val dlg = AlertDialog.Builder(this).setTitle("Testing…").setMessage("This can take up to a minute.").setCancelable(false).show()
        Thread {
            val report = try { Gemini.diagnose(applicationContext) } catch (e: Throwable) { "Test failed: $e" }
            runOnUiThread {
                dlg.dismiss()
                AlertDialog.Builder(this)
                    .setTitle("AI connection test")
                    .setMessage(report)
                    .setPositiveButton("Copy report") { _, _ -> Clip.copy(this, "NB connection test\n$report", "Report copied") }
                    .setNegativeButton("Close", null)
                    .show()
            }
        }.start()
    }

    private fun testKey() {
        keyStatus.text = "Checking the key and finding the fastest model… (up to 30 s)"
        Thread {
            val msg = try {
                "Connected · model " + Gemini.detectModel(applicationContext)
            } catch (e: Gemini.ApiError) {
                e.message ?: "The key didn't work"
            } catch (e: java.io.IOException) {
                CrashLog.note(applicationContext, "key check network", e)
                Gemini.networkMessage(applicationContext, e)
            } catch (e: Throwable) {
                "Couldn't check the key"
            }
            runOnUiThread {
                keyStatus.text = msg
                toast(msg)
            }
        }.start()
    }

    private fun refresh() {
        showCrashReport()
        refreshKey()
        val enabled = accessibilityOn()
        val running = NBAccessibilityService.instance != null
        if (enabled && !running) {
            accRow.status.text = "Not running"
            accRow.status.setTextColor(Ui.WARN)
            accRow.button.text = "Fix"
        } else {
            setStatus(accRow, running)
        }
        setStatus(notifRow, notifAccessOn())
        setStatus(assistRow, assistantOn())
        setStatus(permRow, Notifier.canPost(this))
    }

    private fun showCrashReport() {
        val report = CrashLog.read(this)
        crashBox.removeAllViews()
        if (report == null) { crashBox.visibility = android.view.View.GONE; return }
        crashBox.visibility = android.view.View.VISIBLE
        crashBox.addView(label("NB hit an error", 15f, 0xFFFCA5A5.toInt(), true))
        crashBox.addView(label("Tap Copy report and paste it to Claude so it can be fixed.", 13f, Ui.SUB).apply {
            setPadding(0, dp(4), 0, dp(10))
        })
        crashBox.addView(label(report.take(1500), 11f, Ui.TEXT).apply {
            typeface = android.graphics.Typeface.MONOSPACE
            setTextIsSelectable(true)
            maxLines = 18
        })
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(12), 0, 0) }
        buttons.addView(smallButton("Copy report") { Clip.copy(this, report, "Report copied") })
        buttons.addView(android.view.View(this), LinearLayout.LayoutParams(dp(8), 1))
        buttons.addView(smallButton("Clear") { CrashLog.clear(this); showCrashReport() })
        crashBox.addView(buttons)
    }

    private fun setStatus(r: Row, ok: Boolean) {
        r.status.text = if (ok) "On" else "Off"
        r.status.setTextColor(if (ok) Ui.OK else Ui.SUB)
        r.button.text = if (ok) "Open" else "Turn on"
    }

    // ---------- actions ----------

    private fun openAccessibility() {
        AlertDialog.Builder(this)
            .setTitle("Turn on NB")
            .setMessage(
                "On the next screen, open \"Installed apps\" (or \"Downloaded apps\"), tap NB and switch it on.\n\n" +
                    "NB only takes a screenshot when you open it, and the screenshot stays on your phone."
            )
            .setPositiveButton("Continue") { _, _ -> startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun openNotificationAccess() {
        val i = Intent(Settings.ACTION_NOTIFICATION_LISTENER_DETAIL_SETTINGS)
            .putExtra(Settings.EXTRA_NOTIFICATION_LISTENER_COMPONENT_NAME, ComponentName(this, NBNotificationListener::class.java).flattenToString())
        try {
            startActivity(i)
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
    }

    private fun openAssistant() {
        AlertDialog.Builder(this)
            .setTitle("Hold to open NB")
            .setMessage(
                "On the next screen, open \"Digital assistant app\" and choose NB.\n\n" +
                    "Then holding the gesture bar or home button opens NB. If your phone has no hold gesture, use the edge handle or the Quick Settings tile."
            )
            .setPositiveButton("Continue") { _, _ ->
                try {
                    startActivity(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS))
                } catch (e: Exception) {
                    startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS))
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun askNotifPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7)
        } else {
            startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refresh()
    }

    /** A settings row that opens a single-choice list. */
    private fun choice(parent: LinearLayout, title: String, desc: String, options: List<String>,
                       get: () -> Int, set: (Int) -> Unit) {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, dp(8))
            isClickable = true
        }
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(label(title, 15f))
        texts.addView(label(desc, 12.5f, Ui.SUB))
        r.addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val value = label(options[get().coerceIn(0, options.size - 1)] + "  ›", 15f, Ui.ACCENT, true)
        r.addView(value)
        r.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle(title)
                .setSingleChoiceItems(options.toTypedArray(), get().coerceIn(0, options.size - 1)) { d, which ->
                    set(which)
                    value.text = options[which] + "  ›"
                    d.dismiss()
                }
                .show()
        }
        parent.addView(r)
    }

    private val sensLevels = listOf("low" to "Low", "medium" to "Medium", "high" to "High")

    private fun sensName(v: String): String = sensLevels.firstOrNull { it.first == v }?.second ?: "Medium"

    private fun chooseSensitivity() {
        val current = sensLevels.indexOfFirst { it.first == Prefs.tapSens(this) }
        AlertDialog.Builder(this)
            .setTitle("Back tap sensitivity")
            .setSingleChoiceItems(sensLevels.map { it.second }.toTypedArray(), current) { d, which ->
                Prefs.setTapSens(this, sensLevels[which].first)
                sensValue.text = sensName(sensLevels[which].first) + "  ›"
                d.dismiss()
            }
            .show()
    }

    private fun chooseLanguage() {
        val names = NBTranslate.LANGS.map { it.second }.toTypedArray()
        val current = NBTranslate.LANGS.indexOfFirst { it.first == Prefs.lang(this) }
        AlertDialog.Builder(this)
            .setTitle("Translate to")
            .setSingleChoiceItems(names, current) { d, which ->
                Prefs.setLang(this, NBTranslate.LANGS[which].first)
                langValue.text = NBTranslate.name(Prefs.lang(this)) + "  ›"
                d.dismiss()
            }
            .show()
    }

    // ---------- small view builders ----------

    private fun card(parent: LinearLayout, title: String): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundBg(Ui.CARD, 20f)
            setPadding(dp(16), dp(14), dp(16), dp(16))
        }
        c.addView(label(title, 13f, Ui.ACCENT, true).apply { setPadding(0, 0, 0, dp(8)) })
        parent.addView(c, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = dp(12)
        })
        return c
    }

    private fun row(parent: LinearLayout, title: String, desc: String, onClick: () -> Unit): Row {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, dp(8))
        }
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(label(title, 15f, Ui.TEXT, true))
        val status = label("Off", 12f, Ui.SUB, true).apply { setPadding(dp(8), 0, 0, 0) }
        head.addView(status)
        texts.addView(head)
        texts.addView(label(desc, 12.5f, Ui.SUB))
        r.addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val btn = smallButton("Turn on", onClick)
        r.addView(btn)
        parent.addView(r)
        return Row(status, btn)
    }

    private fun smallButton(text: String, onClick: () -> Unit): TextView =
        label(text, 13f, Ui.TEXT, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(8), dp(14), dp(8))
            background = roundBg(Ui.CARD2, 16f)
            setOnClickListener { onClick() }
        }

    private fun bigButton(text: String, filled: Boolean = true, onClick: () -> Unit): TextView =
        label(text, 15f, if (filled) 0xFF10131A.toInt() else Ui.TEXT, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = if (filled) roundBg(Ui.ACCENT, 16f) else roundBg(Ui.CARD2, 16f)
            setOnClickListener { onClick() }
        }

    private fun spacer(h: Int) = android.view.View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(h))
    }

    private fun toggle(parent: LinearLayout, title: String, desc: String, key: String) {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, dp(8))
        }
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(label(title, 15f))
        texts.addView(label(desc, 12.5f, Ui.SUB))
        r.addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val sw = Switch(this).apply {
            isChecked = Prefs.on(this@MainActivity, key)
            setOnCheckedChangeListener { _, checked -> Prefs.set(this@MainActivity, key, checked) }
        }
        r.addView(sw)
        r.setOnClickListener { sw.toggle() }
        parent.addView(r)
    }
}
