package app.nb

import android.app.Activity
import android.app.AlertDialog
import android.app.SearchManager
import android.content.ActivityNotFoundException
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.provider.MediaStore
import android.widget.Toast
import androidx.core.content.FileProvider
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import java.io.File
import java.io.FileOutputStream
import java.net.URLEncoder

/** Hands the screenshot from the service (or assistant) to the capture screen. */
object ShotHolder {
    @Volatile var bitmap: Bitmap? = null
}

fun Context.toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

object Share {
    private val lensApps = listOf(
        "com.google.ar.lens",
        "com.google.android.googlequicksearchbox",
        "com.google.android.apps.searchlite"
    )

    fun cacheImage(c: Context, bmp: Bitmap): Uri {
        val dir = File(c.cacheDir, "shots").apply { mkdirs() }
        val f = File(dir, "nb_${System.currentTimeMillis()}.png")
        FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        dir.listFiles()?.filter { it != f && System.currentTimeMillis() - it.lastModified() > 60 * 60 * 1000L }?.forEach { it.delete() }
        return FileProvider.getUriForFile(c, "${c.packageName}.files", f)
    }

    private fun imageIntent(uri: Uri): Intent = Intent(Intent.ACTION_SEND)
        .setType("image/png")
        .putExtra(Intent.EXTRA_STREAM, uri)
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)

    /** Sends the image to Google Lens (or the Google app). Returns false if nothing could take it. */
    fun lens(a: Activity, bmp: Bitmap): Boolean {
        val uri = cacheImage(a, bmp)
        for (p in lensApps) {
            val i = imageIntent(uri).setPackage(p).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try {
                a.startActivity(i)
                return true
            } catch (e: ActivityNotFoundException) {
            } catch (e: SecurityException) {
            }
        }
        return try {
            a.startActivity(Intent.createChooser(imageIntent(uri), "Search image with").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            true
        } catch (e: Exception) {
            false
        }
    }

    fun shareImage(a: Activity, bmp: Bitmap) {
        val uri = cacheImage(a, bmp)
        a.startActivity(Intent.createChooser(imageIntent(uri), "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun shareText(a: Activity, text: String) {
        val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
        a.startActivity(Intent.createChooser(i, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun searchText(a: Activity, text: String) {
        val q = text.take(500)
        try {
            a.startActivity(Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, q).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            val url = "https://www.google.com/search?q=" + URLEncoder.encode(q, "UTF-8")
            try {
                a.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Exception) {
                a.toast("No browser found")
            }
        }
    }

    /** Saves to Pictures/NB in the gallery. No storage permission needed on Android 10+. */
    fun saveToGallery(c: Context, bmp: Bitmap): Boolean {
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "NB_${System.currentTimeMillis()}.png")
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/NB")
        }
        val uri = c.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return false
        return try {
            c.contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            true
        } catch (e: Exception) {
            false
        }
    }

    fun openLink(a: Activity, value: String): Boolean {
        val v = value.trim()
        val uri = when {
            v.startsWith("http://", true) || v.startsWith("https://", true) -> Uri.parse(v)
            v.startsWith("www.", true) -> Uri.parse("https://$v")
            v.contains(":") -> Uri.parse(v) // tel:, mailto:, upi:, geo:, WIFI: etc.
            else -> return false
        }
        return try {
            a.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            true
        } catch (e: Exception) {
            false
        }
    }
}

object NBTranslate {
    val LANGS = listOf(
        "en" to "English",
        "ar" to "Arabic",
        "hi" to "Hindi",
        "ta" to "Tamil",
        "ur" to "Urdu",
        "fr" to "French"
    )

    fun name(tag: String): String = LANGS.firstOrNull { it.first == tag }?.second ?: tag

    fun translate(a: Activity, text: String, onCopy: (String) -> Unit) {
        val targetTag = Prefs.lang(a)
        val target = TranslateLanguage.fromLanguageTag(targetTag) ?: TranslateLanguage.ENGLISH
        val progress = AlertDialog.Builder(a).setMessage("Translating…").setCancelable(true).create()
        progress.show()

        fun fail(msg: String) {
            if (a.isFinishing || a.isDestroyed) return
            progress.dismiss()
            a.toast(msg)
        }

        val lid = LanguageIdentification.getClient()
        lid.identifyLanguage(text)
            .addOnSuccessListener { tag ->
                lid.close()
                val source = TranslateLanguage.fromLanguageTag(if (tag == "und") "en" else tag) ?: TranslateLanguage.ENGLISH
                if (source == target) {
                    if (a.isFinishing || a.isDestroyed) return@addOnSuccessListener
                    progress.dismiss()
                    show(a, text, "Already in ${name(targetTag)}", onCopy)
                    return@addOnSuccessListener
                }
                val tr = Translation.getClient(
                    TranslatorOptions.Builder().setSourceLanguage(source).setTargetLanguage(target).build()
                )
                progress.setMessage("Getting the language pack (first time only, needs internet)…")
                tr.downloadModelIfNeeded(DownloadConditions.Builder().build())
                    .addOnSuccessListener {
                        progress.setMessage("Translating…")
                        tr.translate(text)
                            .addOnSuccessListener { out ->
                                tr.close()
                                if (a.isFinishing || a.isDestroyed) return@addOnSuccessListener
                                progress.dismiss()
                                show(a, out, "Translated to ${name(targetTag)}", onCopy)
                            }
                            .addOnFailureListener { tr.close(); fail("Couldn't translate this text") }
                    }
                    .addOnFailureListener { tr.close(); fail("Couldn't download the language. Check your internet.") }
            }
            .addOnFailureListener { lid.close(); fail("Couldn't detect the language") }
    }

    private fun show(a: Activity, text: String, title: String, onCopy: (String) -> Unit) {
        AlertDialog.Builder(a)
            .setTitle(title)
            .setMessage(text)
            .setPositiveButton("Copy") { _, _ -> onCopy(text) }
            .setNegativeButton("Close", null)
            .show()
    }
}
