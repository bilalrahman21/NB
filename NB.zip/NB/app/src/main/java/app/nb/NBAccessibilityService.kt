package app.nb

import android.accessibilityservice.AccessibilityButtonController
import android.accessibilityservice.AccessibilityService
import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.view.Display
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.min

/**
 * The heart of NB. Takes the screenshot when you open NB, draws the edge handle,
 * pinned images and the OTP chip, and runs shake-for-torch and the battery alert.
 */
class NBAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: NBAccessibilityService? = null
            private set
    }

    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())
    private var handle: View? = null
    private val pins = ArrayList<View>()
    private var otpChip: View? = null
    private var capturing = false
    private var torch: ShakeTorch? = null

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        when (key) {
            Prefs.HANDLE, Prefs.HANDLE_LEFT -> refreshHandle()
            Prefs.SHAKE_TORCH -> updateShake()
        }
    }

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) = updateShake()
    }

    private val buttonCallback = object : AccessibilityButtonController.AccessibilityButtonCallback() {
        override fun onClicked(controller: AccessibilityButtonController) = capture(250)
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(WindowManager::class.java)
        Prefs.sp(this).registerOnSharedPreferenceChangeListener(prefListener)
        refreshHandle()

        try { accessibilityButtonController.registerAccessibilityButtonCallback(buttonCallback) } catch (e: Exception) {}

        val f = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(screenReceiver, f, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(screenReceiver, f)
        updateShake()

        BatteryWatcher.start(this)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        instance = null
        Prefs.sp(this).unregisterOnSharedPreferenceChangeListener(prefListener)
        try { unregisterReceiver(screenReceiver) } catch (e: Exception) {}
        try { accessibilityButtonController.unregisterAccessibilityButtonCallback(buttonCallback) } catch (e: Exception) {}
        torch?.release(); torch = null
        BatteryWatcher.stop(this)
        removeView(handle); handle = null
        pins.forEach { removeView(it) }; pins.clear()
        removeView(otpChip); otpChip = null
        super.onDestroy()
    }

    private fun removeView(v: View?) {
        if (v == null) return
        try { wm.removeView(v) } catch (e: Exception) {}
    }

    // ---------- screenshot ----------

    /** Takes a screenshot (after [delayMs]) and opens the NB capture screen. */
    fun capture(delayMs: Long = 0) {
        if (capturing) return
        capturing = true
        handle?.visibility = View.INVISIBLE
        otpChip?.visibility = View.INVISIBLE
        main.postDelayed({ takeShot() }, delayMs + 60)
    }

    private fun takeShot() {
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : AccessibilityService.TakeScreenshotCallback {
            override fun onSuccess(result: AccessibilityService.ScreenshotResult) {
                val buffer = result.hardwareBuffer
                val bmp = try {
                    val hw = Bitmap.wrapHardwareBuffer(buffer, result.colorSpace)
                    val soft = hw?.copy(Bitmap.Config.ARGB_8888, false)
                    hw?.recycle()
                    soft
                } catch (e: Exception) {
                    null
                } finally {
                    buffer.close()
                }
                afterShot()
                if (bmp == null) { toast("Couldn't capture the screen"); return }
                ShotHolder.bitmap = bmp
                startActivity(
                    Intent(this@NBAccessibilityService, CaptureActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
                )
            }

            override fun onFailure(errorCode: Int) {
                afterShot()
                // Error 3 = asked too quickly after the last one; one quick retry.
                if (errorCode == AccessibilityService.ERROR_TAKE_SCREENSHOT_INTERVAL_TIME_SHORT) {
                    capturing = true
                    handle?.visibility = View.INVISIBLE
                    main.postDelayed({ takeShot() }, 400)
                } else {
                    toast("This screen can't be captured")
                }
            }
        })
    }

    private fun afterShot() {
        capturing = false
        handle?.visibility = View.VISIBLE
        otpChip?.visibility = View.VISIBLE
    }

    // ---------- edge handle ----------

    private fun refreshHandle() {
        removeView(handle)
        handle = null
        if (!Prefs.on(this, Prefs.HANDLE)) return
        val left = Prefs.on(this, Prefs.HANDLE_LEFT)
        val v = buildHandle(left)
        val lp = WindowManager.LayoutParams(
            dp(22), dp(110),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = (if (left) Gravity.START else Gravity.END) or Gravity.TOP
            y = (resources.displayMetrics.heightPixels * 0.36f).toInt()
        }
        try {
            wm.addView(v, lp)
            handle = v
        } catch (e: Exception) {}
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun buildHandle(left: Boolean): View {
        val frame = FrameLayout(this)
        val bar = View(this).apply { background = roundBg(0x8CFFFFFF.toInt(), 3f) }
        frame.addView(bar, FrameLayout.LayoutParams(
            dp(5), dp(84),
            (if (left) Gravity.START else Gravity.END) or Gravity.CENTER_VERTICAL
        ).apply { if (left) leftMargin = dp(3) else rightMargin = dp(3) })

        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean { capture(80); return true }
            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (Prefs.on(this@NBAccessibilityService, Prefs.LOCK_DOUBLE_TAP)) performGlobalAction(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)
                return true
            }
            override fun onLongPress(e: MotionEvent) {
                startActivity(Intent(this@NBAccessibilityService, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, velocityX: Float, velocityY: Float): Boolean {
                val inward = if (left) velocityX > 500 else velocityX < -500
                if (inward && abs(velocityX) > abs(velocityY)) { capture(120); return true }
                return false
            }
        })
        frame.setOnTouchListener { _, ev -> gd.onTouchEvent(ev); true }
        return frame
    }

    // ---------- pin to screen ----------

    @SuppressLint("ClickableViewAccessibility", "SetTextI18n")
    fun pin(bmp: Bitmap) {
        val dm = resources.displayMetrics
        val scale = min(1f, min(dm.widthPixels * 0.6f / bmp.width, dm.heightPixels * 0.45f / bmp.height))
        val w = (bmp.width * scale).toInt().coerceAtLeast(dp(48))
        val h = (bmp.height * scale).toInt().coerceAtLeast(dp(48))

        val card = FrameLayout(this).apply {
            background = roundBg(Ui.CARD, 14f, Ui.ACCENT, 2)
            setPadding(dp(3), dp(3), dp(3), dp(3))
            elevation = dpf(8f)
            clipToOutline = true
        }
        val iv = ImageView(this).apply {
            setImageBitmap(bmp)
            scaleType = ImageView.ScaleType.FIT_XY
        }
        card.addView(iv, FrameLayout.LayoutParams(w, h))
        val close = TextView(this).apply {
            text = "✕"
            textSize = 13f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            background = roundBg(0xCC000000.toInt(), 14f)
        }
        card.addView(close, FrameLayout.LayoutParams(dp(28), dp(28), Gravity.TOP or Gravity.END).apply {
            topMargin = dp(4); rightMargin = dp(4)
        })

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(24) + pins.size * dp(16)
            y = dp(140) + pins.size * dp(16)
        }

        var startX = 0; var startY = 0; var downRawX = 0f; var downRawY = 0f; var dragged = false
        iv.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y; downRawX = ev.rawX; downRawY = ev.rawY; dragged = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = ev.rawX - downRawX
                    val dy = ev.rawY - downRawY
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) dragged = true
                    if (dragged) {
                        lp.x = startX + dx.toInt()
                        lp.y = startY + dy.toInt()
                        try { wm.updateViewLayout(card, lp) } catch (e: Exception) {}
                    }
                }
                MotionEvent.ACTION_UP -> {
                    // Tap toggles see-through so you can read what's underneath.
                    if (!dragged) card.alpha = if (card.alpha > 0.9f) 0.45f else 1f
                }
            }
            true
        }
        close.setOnClickListener {
            removeView(card)
            pins.remove(card)
        }

        try {
            wm.addView(card, lp)
            pins.add(card)
        } catch (e: Exception) {
            toast("Couldn't pin")
        }
    }

    // ---------- OTP chip ----------

    @SuppressLint("SetTextI18n")
    fun showOtpChip(code: String) {
        main.post {
            removeView(otpChip)
            val chip = label("Copy code  $code", 15f, 0xFF10131A.toInt(), true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(18), dp(12), dp(18), dp(12))
                background = roundBg(Ui.ACCENT, 24f)
                elevation = dpf(8f)
            }
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                y = dp(56)
            }
            chip.setOnClickListener {
                Clip.copy(this, code, "Code copied")
                removeView(chip)
                if (otpChip === chip) otpChip = null
            }
            try {
                wm.addView(chip, lp)
                otpChip = chip
                main.postDelayed({
                    removeView(chip)
                    if (otpChip === chip) otpChip = null
                }, 12000)
            } catch (e: Exception) {
                Notifier.otp(this, code)
            }
        }
    }

    // ---------- shake for torch ----------

    private fun updateShake() {
        val want = Prefs.on(this, Prefs.SHAKE_TORCH)
        val screenOn = getSystemService(PowerManager::class.java)?.isInteractive ?: true
        if (want && torch == null) torch = ShakeTorch(this)
        torch?.listen(want && screenOn)
        if (!want) { torch?.release(); torch = null }
    }
}
