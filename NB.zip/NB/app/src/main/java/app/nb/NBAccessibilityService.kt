package app.nb

import android.accessibilityservice.AccessibilityButtonController
import android.accessibilityservice.AccessibilityService
import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.view.Display
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.min

/**
 * The heart of NB. Takes the screenshot when you open NB, draws the edge handle,
 * pinned images and the OTP chip, and runs shake-for-torch and the battery alert.
 */
class NBAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: NBAccessibilityService? = null
            private set
    }

    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())
    private var handle: View? = null
    private val pins = ArrayList<View>()
    private var otpChip: View? = null
    private var capturing = false
    private var torch: ShakeTorch? = null
    private var backTap: BackTap? = null
    private var preview: View? = null
    private var quickMenu: View? = null

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        when (key) {
            Prefs.HANDLE, Prefs.HANDLE_LEFT, Prefs.HANDLE_POS -> refreshHandle()
            Prefs.SHAKE_TORCH, Prefs.BACK_TAP, Prefs.TAP_SENS, Prefs.TAP_COUNT -> updateSensors()
            Prefs.REAR_NIGHT -> safe("rear night") { onNightToggled() }
            Prefs.NIGHT_START, Prefs.NIGHT_END -> safe("rear night") { applyNight(); Rear.schedule(this) }
        }
    }

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            safe("screen on/off") { updateSensors() }
            // After unlocking, give the home screen a moment, then catch up on the schedule.
            if (intent.action == Intent.ACTION_USER_PRESENT) main.postDelayed({ safe("rear night") { applyNight() } }, 1500)
        }
    }

    private val buttonCallback = object : AccessibilityButtonController.AccessibilityButtonCallback() {
        override fun onClicked(controller: AccessibilityButtonController) { safe("quick menu") { showQuickMenu() } }
    }

    /** Runs one part of NB; if it fails, NB keeps running and the error is saved for the report. */
    private inline fun safe(where: String, block: () -> Unit): Boolean {
        return try {
            block()
            true
        } catch (e: Throwable) {
            CrashLog.note(this, where, e)
            false
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(WindowManager::class.java)
        safe("settings listener") { Prefs.sp(this).registerOnSharedPreferenceChangeListener(prefListener) }
        safe("edge handle") { refreshHandle() }
        safe("accessibility button") { accessibilityButtonController.registerAccessibilityButtonCallback(buttonCallback) }
        safe("screen receiver") {
            val f = IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_ON)
                addAction(Intent.ACTION_SCREEN_OFF)
                addAction(Intent.ACTION_USER_PRESENT)
            }
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(screenReceiver, f, Context.RECEIVER_NOT_EXPORTED)
            else registerReceiver(screenReceiver, f)
        }
        safe("sensors") { updateSensors() }
        safe("battery alert") { BatteryWatcher.start(this) }
        safe("rear night") { applyNight(); Rear.schedule(this) }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val e = event ?: return
        if (job != null) {
            // The settings screen changed: look again shortly.
            main.removeCallbacks(stepRunnable)
            main.postDelayed(stepRunnable, 350)
        } else if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            safe("rear learn") { learnPage(e) }
        }
    }
    override fun onInterrupt() {}

    override fun onDestroy() {
        instance = null
        Prefs.sp(this).unregisterOnSharedPreferenceChangeListener(prefListener)
        try { unregisterReceiver(screenReceiver) } catch (e: Exception) {}
        try { accessibilityButtonController.unregisterAccessibilityButtonCallback(buttonCallback) } catch (e: Exception) {}
        torch?.release(); torch = null
        backTap?.release(); backTap = null
        removeView(preview); preview = null
        removeView(quickMenu); quickMenu = null
        main.removeCallbacks(stepRunnable)
        main.removeCallbacks(timeoutRunnable)
        BatteryWatcher.stop(this)
        removeView(handle); handle = null
        pins.forEach { removeView(it) }; pins.clear()
        removeView(otpChip); otpChip = null
        super.onDestroy()
    }

    private fun removeView(v: View?) {
        if (v == null) return
        try { wm.removeView(v) } catch (e: Exception) {}
    }

    // ---------- screenshot ----------

    /** Takes a screenshot (after [delayMs]) and opens the NB capture screen. */
    fun capture(delayMs: Long = 0) {
        shootAfter(delayMs) { bmp ->
            ShotHolder.bitmap = bmp
            startActivity(
                Intent(this, CaptureActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
            )
        }
    }

    /** Back tap: a normal screenshot, saved to the gallery, with a share preview. */
    fun quickShot() {
        removePreview()
        shootAfter(0) { bmp ->
            flash()
            buzz(this, 30)
            Thread {
                val uri = try { Share.saveScreenshot(this, bmp) } catch (e: Throwable) { CrashLog.note(this, "save screenshot", e); null }
                main.post {
                    if (uri == null) toast("Couldn't save the screenshot")
                    else safe("screenshot preview") { showPreview(bmp, uri) }
                }
            }.start()
        }
    }

    private fun shootAfter(delayMs: Long, onBitmap: (Bitmap) -> Unit) {
        if (capturing) return
        capturing = true
        handle?.visibility = View.INVISIBLE
        otpChip?.visibility = View.INVISIBLE
        main.postDelayed({ if (!safe("capture") { takeShot(onBitmap) }) afterShot() }, delayMs + 60)
    }

    private fun takeShot(onBitmap: (Bitmap) -> Unit) {
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : AccessibilityService.TakeScreenshotCallback {
            override fun onSuccess(result: AccessibilityService.ScreenshotResult) {
                var bmp: Bitmap? = null
                val ok = safe("screenshot") {
                    val buffer = result.hardwareBuffer
                    try {
                        val hw = Bitmap.wrapHardwareBuffer(buffer, result.colorSpace)
                        bmp = hw?.copy(Bitmap.Config.ARGB_8888, false)
                        hw?.recycle()
                    } finally {
                        buffer.close()
                    }
                }
                afterShot()
                val b = bmp
                if (!ok || b == null) { toast("Couldn't capture the screen"); return }
                safe("after screenshot") { onBitmap(b) }
            }

            override fun onFailure(errorCode: Int) {
                afterShot()
                // Asked too quickly after the last one: one quick retry.
                if (errorCode == AccessibilityService.ERROR_TAKE_SCREENSHOT_INTERVAL_TIME_SHORT) {
                    capturing = true
                    handle?.visibility = View.INVISIBLE
                    main.postDelayed({ if (!safe("capture retry") { takeShot(onBitmap) }) afterShot() }, 400)
                } else {
                    toast("This screen can't be captured")
                }
            }
        })
    }

    private fun afterShot() {
        capturing = false
        handle?.visibility = View.VISIBLE
        otpChip?.visibility = View.VISIBLE
    }

    // ---------- screenshot preview (back tap) ----------

    private fun flash() {
        val v = View(this).apply { setBackgroundColor(0xFFFFFFFF.toInt()); alpha = 0.7f }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        try {
            wm.addView(v, lp)
            v.animate().alpha(0f).setDuration(220).withEndAction { removeView(v) }.start()
        } catch (e: Exception) {}
    }

    private fun removePreview() {
        removeView(preview)
        preview = null
    }

    private fun showPreview(bmp: Bitmap, uri: android.net.Uri) {
        removePreview()
        val dm = resources.displayMetrics
        val thumbW = (dm.widthPixels * 0.28f).toInt()
        val thumbH = min((thumbW.toFloat() * bmp.height / bmp.width).toInt(), (dm.heightPixels * 0.4f).toInt())
        val thumb = Bitmap.createScaledBitmap(bmp, thumbW, thumbH, true)

        val card = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.HORIZONTAL
            background = roundBg(Ui.CARD, 18f, 0x55FFFFFF, 1)
            setPadding(dp(8), dp(8), dp(8), dp(8))
            elevation = dpf(10f)
        }
        val iv = ImageView(this).apply {
            setImageBitmap(thumb)
            scaleType = ImageView.ScaleType.FIT_XY
            background = roundBg(0xFF000000.toInt(), 10f)
            clipToOutline = true
            setOnClickListener { openImage(uri); removePreview() }
        }
        card.addView(iv, android.widget.LinearLayout.LayoutParams(thumbW, thumbH))

        val col = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(dp(8), 0, 0, 0)
        }
        fun btn(text: String, filled: Boolean, onClick: () -> Unit) {
            val b = label(text, 13f, if (filled) 0xFF10131A.toInt() else Ui.TEXT, true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(14), dp(9), dp(14), dp(9))
                background = if (filled) roundBg(Ui.ACCENT, 16f) else roundBg(Ui.CARD2, 16f)
                setOnClickListener { safe("preview button") { onClick() } }
            }
            col.addView(b, android.widget.LinearLayout.LayoutParams(dp(96), android.widget.LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(6)
            })
        }
        btn("Share", true) { shareImage(uri); removePreview() }
        btn("Search", false) {
            removePreview()
            ShotHolder.bitmap = bmp
            startActivity(Intent(this, CaptureActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
        }
        btn("Delete", false) {
            try { contentResolver.delete(uri, null, null); toast("Screenshot deleted") } catch (e: Exception) { toast("Couldn't delete") }
            removePreview()
        }
        btn("Close", false) { removePreview() }
        card.addView(col)

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.START
            x = dp(16)
            y = dp(90)
        }
        try {
            wm.addView(card, lp)
            preview = card
            main.postDelayed({ if (preview === card) removePreview() }, 8000)
        } catch (e: Exception) {
            toast("Screenshot saved")
        }
    }

    private fun shareImage(uri: android.net.Uri) {
        val send = Intent(Intent.ACTION_SEND)
            .setType("image/png")
            .putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        send.clipData = android.content.ClipData.newRawUri("screenshot", uri)
        startActivity(
            Intent.createChooser(send, "Share screenshot")
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        )
    }

    private fun openImage(uri: android.net.Uri) {
        try {
            startActivity(
                Intent(Intent.ACTION_VIEW).setDataAndType(uri, "image/png")
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        } catch (e: Exception) {
            toast("No gallery app found")
        }
    }

    // ---------- edge handle ----------

    private var handleLp: WindowManager.LayoutParams? = null
    private val handleW get() = dp(22)
    private val handleH get() = dp(110)
    private val handleWideW get() = dp(64)
    private val handleWideH get() = dp(180)

    private fun handleBaseY(): Int {
        val frac = when (Prefs.handlePos(this)) { 0 -> 0.18f; 2 -> 0.58f; else -> 0.38f }
        return (resources.displayMetrics.heightPixels * frac).toInt()
    }

    private fun refreshHandle() {
        removeView(handle)
        handle = null
        handleLp = null
        if (!Prefs.on(this, Prefs.HANDLE)) return
        val left = Prefs.on(this, Prefs.HANDLE_LEFT)
        val lp = WindowManager.LayoutParams(
            handleW, handleH,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = (if (left) Gravity.START else Gravity.END) or Gravity.TOP
            y = handleBaseY()
        }
        val v = buildHandle(left)
        try {
            wm.addView(v, lp)
            handle = v
            handleLp = lp
        } catch (e: Exception) {}
    }

    /** After the first tap, the handle's touch area grows so the next taps don't miss. */
    private fun setHandleWide(wide: Boolean) {
        val v = handle ?: return
        val lp = handleLp ?: return
        val w = if (wide) handleWideW else handleW
        val h = if (wide) handleWideH else handleH
        if (lp.width == w && lp.height == h) return
        lp.width = w
        lp.height = h
        lp.y = handleBaseY() - (h - handleH) / 2
        try { wm.updateViewLayout(v, lp) } catch (e: Exception) {}
    }

    /**
     * Edge handle:
     *  - swipe inward (or slide along the bar) and let go → circle to search
     *  - swipe inward (or slide along the bar) and hold → voice assistant
     *  - hold → quick menu
     *  - triple-tap → screenshot with share preview
     *  - double-tap → lock screen, only if turned on in settings
     *  - single taps do nothing, so brushing the edge is harmless
     */
    @SuppressLint("ClickableViewAccessibility")
    private fun buildHandle(left: Boolean): View {
        val frame = FrameLayout(this)
        val bar = View(this).apply { background = roundBg(0xFFFFFFFF.toInt(), 3f) }
        val barLp = FrameLayout.LayoutParams(
            dp(4), dp(72),
            (if (left) Gravity.START else Gravity.END) or Gravity.CENTER_VERTICAL
        ).apply { if (left) leftMargin = dp(3) else rightMargin = dp(3) }
        frame.addView(bar, barLp)
        bar.alpha = 0.45f

        // Tell Android this strip belongs to NB, so the "Back" edge swipe doesn't steal it.
        frame.addOnLayoutChangeListener { v, l, t, r, b, _, _, _, _ ->
            v.systemGestureExclusionRects = listOf(android.graphics.Rect(0, 0, r - l, b - t))
        }

        var downX = 0f
        var downY = 0f
        var done = false
        var moved = false
        var taps = 0
        var lastTapUp = 0L
        val swipeMin = dpf(32f)
        val slop = dpf(12f)

        fun showTapState(n: Int) {
            bar.alpha = if (n > 0) 1f else 0.45f
            barLp.width = if (n > 0) dp(6) else dp(4)
            bar.layoutParams = barLp
        }

        val resolveTaps = Runnable {
            val n = taps
            taps = 0
            showTapState(0)
            setHandleWide(false)
            when {
                n == 3 && Prefs.on(this, Prefs.HANDLE_TRIPLE_SHOT) -> {
                    safe("handle screenshot") { quickShot() }
                }
                n == 2 && Prefs.on(this, Prefs.LOCK_DOUBLE_TAP) -> {
                    performGlobalAction(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)
                }
                else -> {}
            }
        }
        val longPress = Runnable {
            if (!moved && !done) {
                done = true
                taps = 0
                main.removeCallbacks(resolveTaps)
                showTapState(0)
                setHandleWide(false)
                buzz(this, 25)
                safe("quick menu") { showQuickMenu() }
            }
        }

        // Swipe in and keep holding → voice assistant. Swipe in and let go → circle search.
        var armed = false
        val holdForVoice = Runnable {
            if (armed && !done) {
                done = true
                armed = false
                buzz(this, 45)
                showTapState(0)
                safe("voice from handle") { openAssistant(150) }
            }
        }

        frame.setOnTouchListener { v, ev ->
            safe("edge handle touch") {
                when (ev.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = ev.rawX; downY = ev.rawY
                        done = false; moved = false; armed = false
                        main.removeCallbacks(holdForVoice)
                        bar.alpha = 1f
                        main.removeCallbacks(resolveTaps)
                        main.postDelayed(longPress, 550)
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = if (left) ev.rawX - downX else downX - ev.rawX
                        val dy = abs(ev.rawY - downY)
                        if (abs(ev.rawX - downX) > slop || dy > slop) {
                            moved = true
                            main.removeCallbacks(longPress)
                        }
                        // A deliberate swipe inward, or a slide along the bar (works even if
                        // the phone's Back gesture grabs sideways swipes at the edge).
                        val inward = dx >= swipeMin && dx > dy
                        val along = dy >= dpf(56f) && dy > abs(ev.rawX - downX) * 1.5f
                        if (!done && !armed && (inward || along)) {
                            // Swipe recognised: wait to see if the finger stays down.
                            armed = true
                            taps = 0
                            setHandleWide(false)
                            showTapState(3)
                            buzz(this, 15)
                            main.postDelayed(holdForVoice, 450)
                        }
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        main.removeCallbacks(longPress)
                        main.removeCallbacks(holdForVoice)
                        if (armed && !done) {
                            // Let go quickly after the swipe: circle search.
                            armed = false
                            done = true
                            showTapState(0)
                            if (ev.actionMasked == MotionEvent.ACTION_UP) capture(120)
                        } else if (ev.actionMasked == MotionEvent.ACTION_UP && !done && !moved) {
                            val now = SystemClock.elapsedRealtime()
                            taps = if (now - lastTapUp < 500) taps + 1 else 1
                            lastTapUp = now
                            v.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY)
                            showTapState(taps)
                            if (taps >= 3) {
                                main.post(resolveTaps)
                            } else {
                                // Make it easier to land the next tap.
                                setHandleWide(true)
                                main.postDelayed(resolveTaps, 500)
                            }
                        } else if (taps == 0) {
                            showTapState(0)
                        } else {
                            main.postDelayed(resolveTaps, 500)
                        }
                    }
                }
            }
            true
        }
        return frame
    }

    // ---------- pin to screen ----------

    @SuppressLint("ClickableViewAccessibility", "SetTextI18n")
    fun pin(bmp: Bitmap) {
        val dm = resources.displayMetrics
        val scale = min(1f, min(dm.widthPixels * 0.6f / bmp.width, dm.heightPixels * 0.45f / bmp.height))
        val w = (bmp.width * scale).toInt().coerceAtLeast(dp(48))
        val h = (bmp.height * scale).toInt().coerceAtLeast(dp(48))

        val card = FrameLayout(this).apply {
            background = roundBg(Ui.CARD, 14f, Ui.ACCENT, 2)
            setPadding(dp(3), dp(3), dp(3), dp(3))
            elevation = dpf(8f)
            clipToOutline = true
        }
        val iv = ImageView(this).apply {
            setImageBitmap(bmp)
            scaleType = ImageView.ScaleType.FIT_XY
        }
        card.addView(iv, FrameLayout.LayoutParams(w, h))
        val close = TextView(this).apply {
            text = "✕"
            textSize = 13f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            background = roundBg(0xCC000000.toInt(), 14f)
        }
        card.addView(close, FrameLayout.LayoutParams(dp(28), dp(28), Gravity.TOP or Gravity.END).apply {
            topMargin = dp(4); rightMargin = dp(4)
        })

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(24) + pins.size * dp(16)
            y = dp(140) + pins.size * dp(16)
        }

        var startX = 0; var startY = 0; var downRawX = 0f; var downRawY = 0f; var dragged = false
        iv.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y; downRawX = ev.rawX; downRawY = ev.rawY; dragged = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = ev.rawX - downRawX
                    val dy = ev.rawY - downRawY
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) dragged = true
                    if (dragged) {
                        lp.x = startX + dx.toInt()
                        lp.y = startY + dy.toInt()
                        try { wm.updateViewLayout(card, lp) } catch (e: Exception) {}
                    }
                }
                MotionEvent.ACTION_UP -> {
                    // Tap toggles see-through so you can read what's underneath.
                    if (!dragged) card.alpha = if (card.alpha > 0.9f) 0.45f else 1f
                }
            }
            true
        }
        close.setOnClickListener {
            removeView(card)
            pins.remove(card)
        }

        try {
            wm.addView(card, lp)
            pins.add(card)
        } catch (e: Exception) {
            toast("Couldn't pin")
        }
    }

    // ---------- OTP chip ----------

    @SuppressLint("SetTextI18n")
    fun showOtpChip(code: String) {
        main.post {
            removeView(otpChip)
            val chip = label("Copy code  $code", 15f, 0xFF10131A.toInt(), true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(18), dp(12), dp(18), dp(12))
                background = roundBg(Ui.ACCENT, 24f)
                elevation = dpf(8f)
            }
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                y = dp(56)
            }
            chip.setOnClickListener {
                Clip.copy(this, code, "Code copied")
                removeView(chip)
                if (otpChip === chip) otpChip = null
            }
            try {
                wm.addView(chip, lp)
                otpChip = chip
                main.postDelayed({
                    removeView(chip)
                    if (otpChip === chip) otpChip = null
                }, 12000)
            } catch (e: Exception) {
                Notifier.otp(this, code)
            }
        }
    }

    // ---------- motion sensors: shake for torch, back tap ----------

    private fun updateSensors() {
        val screenOn = getSystemService(PowerManager::class.java)?.isInteractive ?: true

        val wantShake = Prefs.on(this, Prefs.SHAKE_TORCH)
        if (wantShake && torch == null) torch = ShakeTorch(this)
        torch?.listen(wantShake && screenOn)
        if (!wantShake) { torch?.release(); torch = null }

        val wantTap = Prefs.on(this, Prefs.BACK_TAP)
        if (wantTap && backTap == null) backTap = BackTap(this) { onBackTap() }
        backTap?.threshold = Prefs.tapThreshold(this)
        backTap?.tapsNeeded = Prefs.tapCount(this)
        backTap?.listen(wantTap && screenOn)
        if (!wantTap) { backTap?.release(); backTap = null }
    }

    private fun onBackTap() {
        if (capturing) return
        safe("back tap") { quickShot() }
    }

    // ---------- rear display: night switch ----------
    // NB opens the "Secondary display" settings page, flips "Secondary display features"
    // and goes back. Android only allows this while the phone is unlocked.

    private val featuresLabel = "Secondary display features"
    private val entryLabel = "Secondary display"

    private var job: Boolean? = null   // the state we want the switch in (true = on)
    private var jobScrolls = 0
    private var jobBacks = 0
    private var jobPhase = 0
    private var jobClicked = false
    private val stepRunnable = Runnable { safe("rear switch") { jobStep() } }
    private val timeoutRunnable = Runnable { if (job != null) finishJob(false, "couldn't find the Secondary display switch") }

    private fun isUnlocked(): Boolean {
        val pm = getSystemService(PowerManager::class.java)
        val km = getSystemService(android.app.KeyguardManager::class.java)
        return (pm?.isInteractive ?: false) && !(km?.isKeyguardLocked ?: true)
    }

    private fun setStatus(msg: String) {
        val time = java.text.SimpleDateFormat("h:mm a", java.util.Locale.US).format(java.util.Date())
        Prefs.sp(this).edit().putString(Prefs.REAR_STATUS, "$msg ($time)").apply()
    }

    private fun onNightToggled() {
        if (Prefs.on(this, Prefs.REAR_NIGHT)) {
            // Assume the rear screen is on right now; the schedule takes it from here.
            Prefs.sp(this).edit().putString(Prefs.REAR_APPLIED, "on").apply()
            applyNight()
        } else if (Prefs.sp(this).getString(Prefs.REAR_APPLIED, "on") == "off") {
            // Night mode switched off while the rear screen is off: turn it back on.
            if (isUnlocked()) startRearSwitch(true)
        }
        Rear.schedule(this)
    }

    /** Called at the start/end times and after each unlock. */
    fun applyNight() {
        if (!Prefs.on(this, Prefs.REAR_NIGHT)) return
        // You switched it by hand: leave it until the next scheduled time.
        if (System.currentTimeMillis() < Prefs.sp(this).getLong(Prefs.REAR_OVERRIDE_UNTIL, 0L)) return
        val want = if (Rear.isNightNow(this)) "off" else "on"
        if (Prefs.sp(this).getString(Prefs.REAR_APPLIED, "on") == want) return
        if (!isUnlocked()) {
            setStatus("will switch $want the next time you unlock")
            return
        }
        startRearSwitch(want == "on")
    }

    /** Opens the setting and puts "Secondary display features" into [wantOn]. */
    fun startRearSwitch(wantOn: Boolean) {
        if (job != null || capturing) return
        job = wantOn
        jobScrolls = 0
        jobBacks = 0
        jobPhase = 0
        jobClicked = false
        if (!launchPhase()) { finishJob(false, "couldn't open Settings"); return }
        main.postDelayed(stepRunnable, 1200)
        main.postDelayed(timeoutRunnable, 15000)
    }

    private fun candidates(): List<Intent> {
        val list = ArrayList<Intent>()
        Prefs.sp(this).getString(Prefs.REAR_COMPONENT, null)?.let { flat ->
            android.content.ComponentName.unflattenFromString(flat)?.let { list.add(Intent().setComponent(it)) }
        }
        list.add(Intent(android.provider.Settings.ACTION_DISPLAY_SETTINGS))
        list.add(Intent(android.provider.Settings.ACTION_SETTINGS))
        return list
    }

    /** Opens the next place to look. Returns false when there is nowhere left. */
    private fun launchPhase(): Boolean {
        val list = candidates()
        while (jobPhase < list.size) {
            try {
                startActivity(list[jobPhase].addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP))
                jobBacks += 1
                return true
            } catch (e: Throwable) {
                jobPhase++
            }
        }
        return false
    }

    private fun jobStep() {
        val wantOn = job ?: return
        val root = rootInActiveWindow ?: return

        // 1) On the Secondary display page: flip the switch.
        val label = root.findAccessibilityNodeInfosByText(featuresLabel).firstOrNull()
        if (label != null) {
            val sw = findSwitchNear(label)
            if (sw == null) { finishJob(false, "found the page but not the switch"); return }
            if (sw.isChecked == wantOn) {
                finishJob(true, if (jobClicked) "rear screen turned ${if (wantOn) "on" else "off"}" else "rear screen was already ${if (wantOn) "on" else "off"}")
                return
            }
            if (!jobClicked) {
                jobClicked = true
                clickNode(sw)
                main.postDelayed(stepRunnable, 700)
            } else {
                finishJob(false, "the switch didn't change")
            }
            return
        }

        // 2) A page that lists "Secondary display": open it.
        val entry = root.findAccessibilityNodeInfosByText(entryLabel).firstOrNull {
            it.text?.toString()?.trim()?.equals(entryLabel, ignoreCase = true) == true
        }
        if (entry != null) {
            if (clickNode(entry)) {
                jobBacks += 1
                jobScrolls = 0
                main.postDelayed(stepRunnable, 900)
                return
            }
        }

        // 3) Not visible yet: scroll down.
        val scroller = findScrollable(root)
        if (scroller != null && jobScrolls < 12 && scroller.performAction(android.view.accessibility.AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)) {
            jobScrolls++
            main.postDelayed(stepRunnable, 500)
            return
        }

        // 4) Try the next place.
        jobPhase++
        jobScrolls = 0
        if (launchPhase()) main.postDelayed(stepRunnable, 1200)
        else finishJob(false, "couldn't find the Secondary display switch")
    }

    private fun finishJob(ok: Boolean, msg: String) {
        val wanted = job
        job = null
        main.removeCallbacks(stepRunnable)
        main.removeCallbacks(timeoutRunnable)
        if (ok && wanted != null) Prefs.sp(this).edit().putString(Prefs.REAR_APPLIED, if (wanted) "on" else "off").apply()
        setStatus(msg)
        // Leave Settings and return to what you were doing.
        val backs = jobBacks.coerceIn(1, 4)
        for (i in 0 until backs) {
            main.postDelayed({ performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK) }, 250L + i * 300L)
        }
    }

    private fun findSwitchNear(label: android.view.accessibility.AccessibilityNodeInfo): android.view.accessibility.AccessibilityNodeInfo? {
        var node: android.view.accessibility.AccessibilityNodeInfo? = label
        for (level in 0..4) {
            val n = node ?: return null
            findCheckable(n, 0)?.let { return it }
            node = n.parent
        }
        return null
    }

    private fun findCheckable(n: android.view.accessibility.AccessibilityNodeInfo, depth: Int): android.view.accessibility.AccessibilityNodeInfo? {
        if (n.isCheckable || n.className?.toString()?.contains("Switch") == true) return n
        if (depth > 6) return null
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            findCheckable(c, depth + 1)?.let { return it }
        }
        return null
    }

    private fun findScrollable(n: android.view.accessibility.AccessibilityNodeInfo, depth: Int = 0): android.view.accessibility.AccessibilityNodeInfo? {
        if (n.isScrollable) return n
        if (depth > 12) return null
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            findScrollable(c, depth + 1)?.let { return it }
        }
        return null
    }

    /** Clicks the node, or the nearest clickable parent. */
    private fun clickNode(start: android.view.accessibility.AccessibilityNodeInfo): Boolean {
        var node: android.view.accessibility.AccessibilityNodeInfo? = start
        for (level in 0..5) {
            val n = node ?: return false
            if (n.isClickable && n.performAction(android.view.accessibility.AccessibilityNodeInfo.ACTION_CLICK)) return true
            node = n.parent
        }
        return false
    }

    /** Remembers which screen holds the switch, so next time NB can open it directly. */
    private fun learnPage(e: AccessibilityEvent) {
        val pkg = e.packageName?.toString() ?: return
        if (!pkg.contains("settings", ignoreCase = true)) return
        val cls = e.className?.toString() ?: return
        main.postDelayed({
            safe("rear learn") {
                val root = rootInActiveWindow ?: return@safe
                if (root.findAccessibilityNodeInfosByText(featuresLabel).isNotEmpty()) {
                    Prefs.sp(this).edit().putString(Prefs.REAR_COMPONENT, "$pkg/$cls").apply()
                }
            }
        }, 600)
    }

    /** Rear screen on/off by hand (floating button or the Rear display page). */
    fun manualRearSwitch(on: Boolean) {
        if (Prefs.on(this, Prefs.REAR_NIGHT)) {
            Prefs.sp(this).edit().putLong(Prefs.REAR_OVERRIDE_UNTIL, Rear.nextBoundary(this)).apply()
        }
        startRearSwitch(on)
    }

    // ---------- quick menu (floating NB button / long-press edge handle) ----------

    private fun removeQuickMenu() {
        removeView(quickMenu)
        quickMenu = null
    }

    fun showQuickMenu() {
        removeQuickMenu()
        val rearOn = Prefs.sp(this).getString(Prefs.REAR_APPLIED, "on") != "off"

        val scrim = FrameLayout(this).apply {
            setBackgroundColor(0x66000000)
            setOnClickListener { removeQuickMenu() }
        }
        val panel = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            background = roundBg(Ui.CARD, 22f, 0x33FFFFFF, 1)
            setPadding(dp(8), dp(10), dp(8), dp(10))
            elevation = dpf(12f)
            isClickable = true // taps on the panel don't close it
        }
        panel.addView(label("NB", 13f, Ui.ACCENT, true).apply { setPadding(dp(14), dp(2), 0, dp(6)) })

        fun item(text: String, sub: String?, action: () -> Unit) {
            val row = android.widget.LinearLayout(this).apply {
                orientation = android.widget.LinearLayout.VERTICAL
                setPadding(dp(14), dp(12), dp(14), dp(12))
                background = roundBg(Ui.CARD2, 14f)
                setOnClickListener {
                    removeQuickMenu()
                    safe("quick menu action") { action() }
                }
            }
            row.addView(label(text, 16f, Ui.TEXT, true))
            if (sub != null) row.addView(label(sub, 12.5f, Ui.SUB))
            panel.addView(row, android.widget.LinearLayout.LayoutParams(dp(260), android.widget.LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(6)
            })
        }

        item("Ask NB", "Talk to your voice assistant") { openAssistant(250) }
        item("Circle to search", "Search or copy anything on screen") { capture(250) }
        item("Screenshot", "Save and share") { main.postDelayed({ quickShot() }, 300) }
        item(
            if (rearOn) "Turn rear screen off" else "Turn rear screen on",
            "Rear screen is ${if (rearOn) "on" else "off"}"
        ) { manualRearSwitch(!rearOn) }
        item("Open NB", null) {
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }

        scrim.addView(panel, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER
        ))

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        try {
            wm.addView(scrim, lp)
            quickMenu = scrim
            main.postDelayed({ if (quickMenu === scrim) removeQuickMenu() }, 12000)
        } catch (e: Exception) {
            capture(250)
        }
    }

    // ---------- voice assistant ----------

    /** Remembers the current screen (for "read this" / circle search), then opens the voice assistant. */
    fun openAssistant(delayMs: Long = 0) {
        removeQuickMenu()
        if (capturing) return
        capturing = true
        handle?.visibility = View.INVISIBLE
        val launchIt = {
            afterShot()
            startActivity(
                Intent(this, VoiceActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            )
        }
        main.postDelayed({
            try {
                takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : AccessibilityService.TakeScreenshotCallback {
                    override fun onSuccess(result: AccessibilityService.ScreenshotResult) {
                        safe("assistant screenshot") {
                            val buffer = result.hardwareBuffer
                            try {
                                val hw = Bitmap.wrapHardwareBuffer(buffer, result.colorSpace)
                                VoiceShot.bitmap = hw?.copy(Bitmap.Config.ARGB_8888, false)
                                hw?.recycle()
                            } finally {
                                buffer.close()
                            }
                        }
                        launchIt()
                    }

                    override fun onFailure(errorCode: Int) {
                        VoiceShot.bitmap = null
                        launchIt()
                    }
                })
            } catch (e: Throwable) {
                VoiceShot.bitmap = null
                launchIt()
            }
        }, delayMs + 60)
    }

    /** Circle to search on the screen the user was on before asking NB. */
    fun openCaptureFromVoice() {
        val b = VoiceShot.bitmap
        if (b != null) {
            ShotHolder.bitmap = b
            startActivity(
                Intent(this, CaptureActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
            )
        } else {
            capture(0)
        }
    }

    /** After WhatsApp opens with the message typed in, taps its Send button. */
    fun autoTapSend(pkg: String, onDone: (Boolean) -> Unit) {
        var tries = 0
        val step = object : Runnable {
            override fun run() {
                tries++
                var sent = false
                safe("auto send") {
                    val root = rootInActiveWindow
                    if (root != null && root.packageName?.toString() == pkg) {
                        val btn = root.findAccessibilityNodeInfosByViewId("$pkg:id/send").firstOrNull()
                            ?: root.findAccessibilityNodeInfosByText("Send").firstOrNull {
                                it.contentDescription?.toString()?.equals("Send", ignoreCase = true) == true
                            }
                        if (btn != null && btn.isEnabled && clickNode(btn)) sent = true
                    }
                }
                when {
                    sent -> onDone(true)
                    tries < 20 -> main.postDelayed(this, 400)
                    else -> onDone(false)
                }
            }
        }
        main.postDelayed(step, 1000)
    }
}
