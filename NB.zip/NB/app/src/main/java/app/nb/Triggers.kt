package app.nb

import android.accessibilityservice.AccessibilityService
import android.annotation.SuppressLint
import android.app.Activity
import android.app.PendingIntent
import android.content.Intent
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.service.voice.VoiceInteractionService
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService
import android.speech.RecognitionService
import android.speech.SpeechRecognizer

/** Quick Settings tile: pull down the shade and tap "NB search". */
class NBTileService : TileService() {
    override fun onStartListening() {
        super.onStartListening()
        qsTile?.apply {
            state = if (NBAccessibilityService.instance != null) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
            updateTile()
        }
    }

    @SuppressLint("StartActivityAndCollapseDeprecated")
    override fun onClick() {
        super.onClick()
        val svc = NBAccessibilityService.instance
        if (svc != null) {
            if (Build.VERSION.SDK_INT >= 31) {
                svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_DISMISS_NOTIFICATION_SHADE)
            }
            svc.capture(650)
            return
        }
        val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (Build.VERSION.SDK_INT >= 34) {
            startActivityAndCollapse(PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE))
        } else {
            startActivityAndCollapse(i)
        }
    }
}

/** Opens NB when NB is chosen as the digital assistant (hold the home button / gesture bar). */
class AssistActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val svc = NBAccessibilityService.instance
        val voice = Prefs.assistAction(this) == 0
        when {
            svc != null && voice -> svc.openAssistant(300)
            svc != null -> svc.capture(350)
            voice -> startActivity(Intent(this, VoiceActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            else -> startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        finish()
    }
}

/** Needed so Android lists NB under Settings → Default apps → Digital assistant app. */
class NBVoiceService : VoiceInteractionService()

class NBSessionService : VoiceInteractionSessionService() {
    override fun onNewSession(args: Bundle?): VoiceInteractionSession = NBSession(this)
}

class NBSession(service: NBSessionService) : VoiceInteractionSession(service) {
    private val main = Handler(Looper.getMainLooper())
    private var waitingForShot = false

    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        val svc = NBAccessibilityService.instance
        val voice = Prefs.assistAction(context) == 0
        if (svc != null) {
            hide()
            if (voice) svc.openAssistant(300) else svc.capture(350)
        } else if (voice) {
            startAssistantActivity(Intent(context, VoiceActivity::class.java))
            hide()
        } else {
            // Fall back to the screenshot the assistant system hands us.
            waitingForShot = true
            main.postDelayed({
                if (waitingForShot) {
                    waitingForShot = false
                    startAssistantActivity(Intent(context, MainActivity::class.java))
                    hide()
                }
            }, 1500)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onHandleScreenshot(screenshot: Bitmap?) {
        super.onHandleScreenshot(screenshot)
        if (!waitingForShot) return
        waitingForShot = false
        if (screenshot != null) {
            ShotHolder.bitmap = screenshot.copy(Bitmap.Config.ARGB_8888, false)
            startAssistantActivity(Intent(context, CaptureActivity::class.java))
        } else {
            startAssistantActivity(Intent(context, MainActivity::class.java))
        }
        hide()
    }
}

/** Required stub: NB doesn't do voice input. */
class NBRecognitionService : RecognitionService() {
    override fun onStartListening(recognizerIntent: Intent?, listener: RecognitionService.Callback?) {
        try { listener?.error(SpeechRecognizer.ERROR_CLIENT) } catch (e: Exception) {}
    }
    override fun onCancel(listener: RecognitionService.Callback?) {}
    override fun onStopListening(listener: RecognitionService.Callback?) {}
}
