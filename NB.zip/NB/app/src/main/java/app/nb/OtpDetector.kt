package app.nb

/** Finds a one-time code in a message, e.g. "Your OTP is 482913". */
object OtpDetector {
    private val keyword = Regex(
        "(otp|one[- ]?time|verification|verify|passcode|security code|login code|code|pin|رمز|كود|التحقق)",
        RegexOption.IGNORE_CASE
    )
    private val number = Regex("(?<![\\d.,])(\\d{4,8})(?![\\d.,])")
    private val money = Regex("(aed|inr|rs\\.?|usd|sar|\\$|₹|dhs?)\\s*$", RegexOption.IGNORE_CASE)

    fun find(text: String): String? {
        if (!keyword.containsMatchIn(text)) return null
        val candidates = number.findAll(text).filter { m ->
            val before = text.substring(0, m.range.first).takeLast(6)
            !money.containsMatchIn(before)
        }.map { it.groupValues[1] }.toList()
        if (candidates.isEmpty()) return null
        return candidates.firstOrNull { it.length == 6 } ?: candidates.first()
    }
}
