package app.nb

import android.Manifest
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.provider.Settings
import android.telephony.SmsManager
import android.telephony.TelephonyManager
import android.view.KeyEvent
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference

/** What the voice screen does for the tools (all calls come from a background thread). */
interface AssistantUi {
    /** Asks the user yes/no and waits for the answer. */
    fun confirm(prompt: String): Boolean
    /** Asks Android for permissions if needed and waits. */
    fun ensurePermissions(perms: Array<String>): Boolean
    /** Closes the voice screen when the reply is done (an app was opened). */
    fun markLeaving()
    /** Closes the voice screen, then runs [action]. */
    fun afterClose(action: () -> Unit)
    /** Text on the screen the user was looking at when NB opened. */
    fun screenText(): String?
    /** If the phone is locked, asks the user to unlock (PIN/fingerprint) and waits. */
    fun ensureUnlocked(): Boolean
}

/** The actions NB's AI can take on the phone. */
class Tools(private val ctx: Context, private val ui: AssistantUi) {

    companion object {
        fun declarations(): JSONArray = JSONArray(DECLS)

        private const val DECLS = """
[
 {"name":"open_app","description":"Open an installed app by its name.",
  "parameters":{"type":"object","properties":{"name":{"type":"string","description":"App name, e.g. WhatsApp, Camera, YouTube"}},"required":["name"]}},
 {"name":"torch","description":"Turn the flashlight on or off.",
  "parameters":{"type":"object","properties":{"on":{"type":"boolean"}},"required":["on"]}},
 {"name":"take_screenshot","description":"Take a screenshot of the screen the user was on, save it and offer to share it.",
  "parameters":{"type":"object","properties":{}}},
 {"name":"circle_to_search","description":"Open NB's circle-to-search / copy-text screen on what the user was looking at.",
  "parameters":{"type":"object","properties":{}}},
 {"name":"lock_screen","description":"Lock the phone screen.",
  "parameters":{"type":"object","properties":{}}},
 {"name":"rear_screen","description":"Turn the phone's small rear (secondary) screen on or off.",
  "parameters":{"type":"object","properties":{"on":{"type":"boolean"}},"required":["on"]}},
 {"name":"open_settings","description":"Open a settings page or quick panel. Apps can't switch Wi-Fi, mobile data or Bluetooth directly, so open the panel for the user.",
  "parameters":{"type":"object","properties":{"page":{"type":"string","enum":["wifi","internet","bluetooth","volume","display","sound","battery","location","airplane","hotspot","apps","notifications","storage","date","nfc","do_not_disturb","accessibility","main"]}},"required":["page"]}},
 {"name":"set_volume","description":"Change the volume.",
  "parameters":{"type":"object","properties":{
    "stream":{"type":"string","enum":["media","ring","alarm"]},
    "action":{"type":"string","enum":["set","up","down","mute","unmute"]},
    "level":{"type":"integer","description":"0-100, only for action=set"}},"required":["stream","action"]}},
 {"name":"media_control","description":"Control music or video that is playing.",
  "parameters":{"type":"object","properties":{"action":{"type":"string","enum":["play_pause","play","pause","next","previous"]}},"required":["action"]}},
 {"name":"lookup_contact","description":"Find a contact's phone number by name.",
  "parameters":{"type":"object","properties":{"name":{"type":"string"}},"required":["name"]}},
 {"name":"call_contact","description":"Phone call a contact by name, or a phone number. The phone asks the user to confirm.",
  "parameters":{"type":"object","properties":{"contact":{"type":"string","description":"Contact name or phone number"}},"required":["contact"]}},
 {"name":"send_message","description":"Send a WhatsApp message or SMS to a contact. The phone shows the message and asks the user to confirm.",
  "parameters":{"type":"object","properties":{
    "contact":{"type":"string","description":"Contact name or phone number"},
    "message":{"type":"string"},
    "app":{"type":"string","enum":["whatsapp","sms"],"description":"Default whatsapp"}},"required":["contact","message"]}},
 {"name":"set_alarm","description":"Set an alarm in the clock app.",
  "parameters":{"type":"object","properties":{
    "hour":{"type":"integer","description":"0-23"},
    "minute":{"type":"integer"},
    "label":{"type":"string"},
    "days":{"type":"array","items":{"type":"string","enum":["monday","tuesday","wednesday","thursday","friday","saturday","sunday"]},"description":"Repeat days, empty for one-time"}},"required":["hour","minute"]}},
 {"name":"set_timer","description":"Start a countdown timer.",
  "parameters":{"type":"object","properties":{"seconds":{"type":"integer"},"label":{"type":"string"}},"required":["seconds"]}},
 {"name":"add_reminder","description":"Remind the user about something at a time, with a notification.",
  "parameters":{"type":"object","properties":{
    "text":{"type":"string","description":"What to remind about"},
    "when":{"type":"string","description":"Local date and time as YYYY-MM-DDTHH:MM"}},"required":["text","when"]}},
 {"name":"list_reminders","description":"List upcoming reminders set with NB.",
  "parameters":{"type":"object","properties":{}}},
 {"name":"cancel_reminder","description":"Cancel an upcoming reminder by matching its text.",
  "parameters":{"type":"object","properties":{"text":{"type":"string"}},"required":["text"]}},
 {"name":"read_screen","description":"Get the text that was on the user's screen when they opened NB.",
  "parameters":{"type":"object","properties":{}}},
 {"name":"recent_notifications","description":"Get recent notifications (messages etc.) saved by NB, newest first.",
  "parameters":{"type":"object","properties":{
    "app":{"type":"string","description":"Optional app or sender name to filter, e.g. WhatsApp or Ahmed"},
    "count":{"type":"integer","description":"How many, default 5"}}}},
 {"name":"navigate","description":"Start Google Maps navigation to a place.",
  "parameters":{"type":"object","properties":{
    "destination":{"type":"string"},
    "mode":{"type":"string","enum":["driving","walking","two_wheeler","transit"]}},"required":["destination"]}},
 {"name":"search_web","description":"Open a Google search for a query.",
  "parameters":{"type":"object","properties":{"query":{"type":"string"}},"required":["query"]}},
 {"name":"play_youtube","description":"Search YouTube for a video or song.",
  "parameters":{"type":"object","properties":{"query":{"type":"string"}},"required":["query"]}}
]
"""
    }

    private val main = Handler(Looper.getMainLooper())

    private fun ok(msg: String) = JSONObject().put("ok", true).put("result", msg)
    private fun err(msg: String) = JSONObject().put("ok", false).put("error", msg)

    /** Runs [block] on the main thread and waits for it. */
    @Suppress("UNCHECKED_CAST")
    private fun <T> onMain(block: () -> T): T {
        if (Looper.myLooper() == Looper.getMainLooper()) return block()
        val ref = AtomicReference<Any?>()
        val errRef = AtomicReference<Throwable?>()
        val latch = CountDownLatch(1)
        main.post {
            try { ref.set(block()) } catch (e: Throwable) { errRef.set(e) } finally { latch.countDown() }
        }
        latch.await(15, TimeUnit.SECONDS)
        errRef.get()?.let { throw it }
        return ref.get() as T
    }

    private fun launch(i: Intent): Boolean = onMain {
        try {
            ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            true
        } catch (e: Exception) {
            false
        }
    }

    /** These work on the lock screen. Everything else asks the user to unlock first. */
    private val lockScreenOk = setOf("torch", "set_alarm", "set_timer", "media_control", "set_volume")

    fun run(name: String, a: JSONObject): JSONObject {
        if (name == "lock_screen" && isLocked()) return ok("The phone is already locked")
        if (name !in lockScreenOk && isLocked()) {
            if (!ui.ensureUnlocked()) return err("The phone is locked and the user didn't unlock it, so this wasn't done")
        }
        return runUnlocked(name, a)
    }

    private fun isLocked(): Boolean =
        ctx.getSystemService(android.app.KeyguardManager::class.java)?.isKeyguardLocked == true

    private fun runUnlocked(name: String, a: JSONObject): JSONObject = when (name) {
        "open_app" -> openApp(a.optString("name"))
        "torch" -> torch(a.optBoolean("on", true))
        "take_screenshot" -> service()?.let { s ->
            ui.afterClose { s.quickShot() }
            ok("Taking the screenshot now")
        } ?: err("NB's Accessibility is off")
        "circle_to_search" -> service()?.let { s ->
            ui.afterClose { s.openCaptureFromVoice() }
            ok("Opening circle to search")
        } ?: err("NB's Accessibility is off")
        "lock_screen" -> service()?.let { s ->
            ui.afterClose { s.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN) }
            ok("Locking the screen")
        } ?: err("NB's Accessibility is off")
        "rear_screen" -> service()?.let { s ->
            val on = a.optBoolean("on", true)
            ui.afterClose { s.manualRearSwitch(on) }
            ok("Turning the rear screen ${if (on) "on" else "off"}")
        } ?: err("NB's Accessibility is off")
        "open_settings" -> openSettings(a.optString("page", "main"))
        "set_volume" -> volume(a.optString("stream", "media"), a.optString("action", "set"), if (a.has("level")) a.optInt("level") else -1)
        "media_control" -> media(a.optString("action", "play_pause"))
        "lookup_contact" -> lookup(a.optString("name"))
        "call_contact" -> call(a.optString("contact"))
        "send_message" -> message(a.optString("contact"), a.optString("message"), a.optString("app", "whatsapp"))
        "set_alarm" -> alarm(a)
        "set_timer" -> timer(a.optInt("seconds", 60), a.optString("label", ""))
        "add_reminder" -> addReminder(a.optString("text"), a.optString("when"))
        "list_reminders" -> listReminders()
        "cancel_reminder" -> cancelReminder(a.optString("text"))
        "read_screen" -> ui.screenText()?.let { t ->
            if (t.isBlank()) err("No readable text on the screen") else JSONObject().put("ok", true).put("screen_text", t.take(5000))
        } ?: err("The screen couldn't be captured")
        "recent_notifications" -> notifications(a.optString("app", ""), a.optInt("count", 5))
        "navigate" -> navigate(a.optString("destination"), a.optString("mode", "driving"))
        "search_web" -> searchWeb(a.optString("query"))
        "play_youtube" -> youtube(a.optString("query"))
        else -> err("Unknown action $name")
    }

    private fun service(): NBAccessibilityService? = NBAccessibilityService.instance

    // ---------- apps ----------

    private fun openApp(name: String): JSONObject {
        val q = name.lowercase(Locale.ROOT).trim()
        if (q.isEmpty()) return err("No app name given")
        val pm = ctx.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        var best: Pair<String, String>? = null
        var bestScore = 0
        val qs = q.replace(" ", "")
        for (ri in apps) {
            val label = ri.loadLabel(pm).toString()
            val l = label.lowercase(Locale.ROOT)
            val ls = l.replace(" ", "")
            val score = when {
                l == q || ls == qs -> 100
                l.startsWith(q) || ls.startsWith(qs) -> 80
                l.split(" ").any { it.startsWith(q) } -> 70
                l.contains(q) || ls.contains(qs) -> 60
                qs.length >= 4 && editDistance(ls, qs) <= 2 -> 50
                else -> 0
            }
            if (score > bestScore) {
                bestScore = score
                best = Pair(ri.activityInfo.packageName, label)
            }
        }
        if (best == null || Translit.hasMalayalam(name)) {
            // Spoken in Malayalam ("വാട്സാപ്പ്") or spelled differently: match by sound.
            var sBest = 0
            for (ri in apps) {
                val label = ri.loadLabel(pm).toString()
                val sc = Translit.score(label, name)
                if (sc > sBest) { sBest = sc; best = Pair(ri.activityInfo.packageName, label) }
            }
        }
        val b = best ?: return err("No app called \"$name\" is installed")
        val i = pm.getLaunchIntentForPackage(b.first) ?: return err("Can't open ${b.second}")
        return if (launch(i)) { ui.markLeaving(); ok("Opened ${b.second}") } else err("Can't open ${b.second}")
    }

    private fun editDistance(a: String, b: String): Int {
        val d = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = d[0]
            d[0] = i
            for (j in 1..b.length) {
                val tmp = d[j]
                d[j] = minOf(d[j] + 1, d[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = tmp
            }
        }
        return d[b.length]
    }

    // ---------- phone controls ----------

    private fun torch(on: Boolean): JSONObject {
        val cam = ctx.getSystemService(CameraManager::class.java) ?: return err("No camera")
        return try {
            val id = cam.cameraIdList.firstOrNull {
                cam.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return err("This phone has no flashlight")
            cam.setTorchMode(id, on)
            ok("Flashlight ${if (on) "on" else "off"}")
        } catch (e: Exception) {
            err("The flashlight is busy (the camera may be open)")
        }
    }

    private fun openSettings(page: String): JSONObject {
        val action = when (page) {
            "wifi" -> Settings.Panel.ACTION_WIFI
            "internet" -> Settings.Panel.ACTION_INTERNET_CONNECTIVITY
            "volume" -> Settings.Panel.ACTION_VOLUME
            "nfc" -> Settings.Panel.ACTION_NFC
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            "battery" -> Intent.ACTION_POWER_USAGE_SUMMARY
            "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            "airplane" -> Settings.ACTION_AIRPLANE_MODE_SETTINGS
            "hotspot" -> Settings.ACTION_WIRELESS_SETTINGS
            "apps" -> Settings.ACTION_APPLICATION_SETTINGS
            "notifications" -> "android.settings.NOTIFICATION_SETTINGS"
            "storage" -> Settings.ACTION_INTERNAL_STORAGE_SETTINGS
            "date" -> Settings.ACTION_DATE_SETTINGS
            "do_not_disturb" -> "android.settings.ZEN_MODE_SETTINGS"
            "accessibility" -> Settings.ACTION_ACCESSIBILITY_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        val opened = launch(Intent(action)) || launch(Intent(Settings.ACTION_SETTINGS))
        return if (opened) { ui.markLeaving(); ok("Opened $page settings") } else err("Couldn't open settings")
    }

    private fun volume(stream: String, action: String, level: Int): JSONObject {
        val am = ctx.getSystemService(AudioManager::class.java) ?: return err("No audio")
        val s = when (stream) {
            "ring" -> AudioManager.STREAM_RING
            "alarm" -> AudioManager.STREAM_ALARM
            else -> AudioManager.STREAM_MUSIC
        }
        return try {
            onMain {
                when (action) {
                    "up" -> am.adjustStreamVolume(s, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                    "down" -> am.adjustStreamVolume(s, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                    "mute" -> am.adjustStreamVolume(s, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
                    "unmute" -> am.adjustStreamVolume(s, AudioManager.ADJUST_UNMUTE, AudioManager.FLAG_SHOW_UI)
                    else -> {
                        val max = am.getStreamMaxVolume(s)
                        val v = ((level.coerceIn(0, 100) * max) + 50) / 100
                        am.setStreamVolume(s, v, AudioManager.FLAG_SHOW_UI)
                    }
                }
            }
            val pct = am.getStreamVolume(s) * 100 / am.getStreamMaxVolume(s).coerceAtLeast(1)
            ok("$stream volume is now $pct%")
        } catch (e: SecurityException) {
            err("Android blocked changing the $stream volume (Do Not Disturb may be on)")
        }
    }

    private fun media(action: String): JSONObject {
        val am = ctx.getSystemService(AudioManager::class.java) ?: return err("No audio")
        val code = when (action) {
            "play" -> KeyEvent.KEYCODE_MEDIA_PLAY
            "pause" -> KeyEvent.KEYCODE_MEDIA_PAUSE
            "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            else -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
        }
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        return ok("Sent $action")
    }

    // ---------- contacts, calls, messages ----------

    private data class Contact(val name: String, val number: String)

    private fun looksLikeNumber(s: String) = s.count { it.isDigit() } >= 5 && s.all { it.isDigit() || it in "+-() " }

    /** Returns one contact, or an error object (not found / several matches). */
    private fun resolve(query: String): Pair<Contact?, JSONObject?> {
        if (looksLikeNumber(query)) return Pair(Contact(query, query.filter { it.isDigit() || it == '+' }), null)
        if (!ui.ensurePermissions(arrayOf(Manifest.permission.READ_CONTACTS))) {
            return Pair(null, err("NB needs Contacts permission to find people"))
        }
        var all = if (Translit.hasMalayalam(query)) emptyList() else findContacts(query)
        if (all.isEmpty()) {
            // Spoken in Malayalam or spelled differently: match by sound.
            val scored = allContacts().map { Pair(it, Translit.score(it.name, query)) }.filter { it.second > 0 }
            val best = scored.maxOfOrNull { it.second } ?: 0
            all = scored.filter { it.second == best }.map { it.first }
        }
        if (all.isEmpty()) return Pair(null, err("No contact matches \"$query\""))
        if (Translit.hasMalayalam(query)) {
            val names = all.map { it.name }.distinct()
            if (names.size > 1) return Pair(null, JSONObject().put("ok", false).put("error", "Several contacts match")
                .put("matches", JSONArray(names.take(6))))
            return Pair(all.first(), null)
        }
        val q = query.lowercase(Locale.ROOT).trim()
        fun score(n: String): Int {
            val l = n.lowercase(Locale.ROOT)
            return when {
                l == q -> 3
                l.startsWith(q) -> 2
                l.split(" ").any { it == q } -> 2
                else -> 1
            }
        }
        val top = all.maxOf { score(it.name) }
        val names = all.filter { score(it.name) == top }.map { it.name }.distinct()
        if (names.size > 1) {
            return Pair(null, JSONObject().put("ok", false).put("error", "Several contacts match")
                .put("matches", JSONArray(names.take(6))))
        }
        return Pair(all.first { it.name == names[0] }, null)
    }

    private fun findContacts(query: String): List<Contact> {
        val out = ArrayList<Contact>()
        val seen = HashSet<String>()
        fun q(term: String) {
            ctx.contentResolver.query(
                Phone.CONTENT_URI, arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER, Phone.IS_SUPER_PRIMARY),
                "${Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$term%"), "${Phone.IS_SUPER_PRIMARY} DESC"
            )?.use { c ->
                while (c.moveToNext()) {
                    val n = c.getString(0) ?: continue
                    val num = c.getString(1) ?: continue
                    val key = n + "|" + num.filter { it.isDigit() }.takeLast(9)
                    if (seen.add(key)) out.add(Contact(n, num))
                }
            }
        }
        q(query.trim())
        if (out.isEmpty()) query.trim().split(" ").filter { it.length >= 3 }.forEach { q(it) }
        return out
    }

    private fun allContacts(): List<Contact> {
        val out = ArrayList<Contact>()
        val seen = HashSet<String>()
        ctx.contentResolver.query(
            Phone.CONTENT_URI, arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER), null, null, "${Phone.IS_SUPER_PRIMARY} DESC"
        )?.use { c ->
            while (c.moveToNext()) {
                val n = c.getString(0) ?: continue
                val num = c.getString(1) ?: continue
                if (seen.add(n + "|" + num.filter { it.isDigit() }.takeLast(9))) out.add(Contact(n, num))
            }
        }
        return out
    }

    private fun lookup(name: String): JSONObject {
        val (c, e) = resolve(name)
        if (c == null) return e ?: err("Not found")
        return JSONObject().put("ok", true).put("name", c.name).put("number", c.number)
    }

    private fun call(who: String): JSONObject {
        val (c, e) = resolve(who)
        if (c == null) return e ?: err("Not found")
        if (!ui.confirm("Call ${c.name}?")) return err("The user cancelled the call")
        val direct = ui.ensurePermissions(arrayOf(Manifest.permission.CALL_PHONE))
        val i = Intent(if (direct) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(c.number)))
        return if (launch(i)) { ui.markLeaving(); ok(if (direct) "Calling ${c.name}" else "Opened the dialer for ${c.name}") }
        else err("Couldn't start the call")
    }

    /** International number without '+', for WhatsApp links. */
    private fun waNumber(raw: String): String {
        val d = raw.filter { it.isDigit() }
        if (raw.trim().startsWith("+")) return d
        if (d.startsWith("00")) return d.drop(2)
        val cc = countryCode()
        return when {
            d.length == 10 && d[0] in "6789" && cc != "91" -> "91$d"   // Indian mobile saved without +91
            d.startsWith("0") -> cc + d.drop(1)
            cc == "971" && d.length == 9 && d.startsWith("5") -> "971$d"
            d.length <= 10 -> cc + d
            else -> d
        }
    }

    private fun countryCode(): String {
        val iso = try {
            ctx.getSystemService(TelephonyManager::class.java)?.simCountryIso?.lowercase(Locale.ROOT)
        } catch (e: Exception) { null }
        return when (iso) {
            "ae" -> "971"
            "in" -> "91"
            "sa" -> "966"
            "om" -> "968"
            "qa" -> "974"
            "kw" -> "965"
            "bh" -> "973"
            "us", "ca" -> "1"
            "gb" -> "44"
            "pk" -> "92"
            "bd" -> "880"
            "lk" -> "94"
            else -> "971"
        }
    }

    private fun installed(pkg: String) = try { ctx.packageManager.getPackageInfo(pkg, 0); true } catch (e: Exception) { false }

    private fun message(who: String, text: String, app: String): JSONObject {
        if (text.isBlank()) return err("The message is empty")
        val (c, e) = resolve(who)
        if (c == null) return e ?: err("Not found")
        val useSms = app == "sms"
        val via = if (useSms) "SMS" else "WhatsApp"
        if (!ui.confirm("Send $via to ${c.name}: \"$text\"")) return err("The user cancelled the message")

        if (useSms) {
            if (ui.ensurePermissions(arrayOf(Manifest.permission.SEND_SMS))) {
                return try {
                    val sm: SmsManager = (if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java) else null)
                        ?: SmsManager.getDefault()
                    sm.sendMultipartTextMessage(c.number, null, sm.divideMessage(text), null, null)
                    ok("SMS sent to ${c.name}")
                } catch (ex: Exception) {
                    err("The SMS couldn't be sent")
                }
            }
            val i = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(c.number))).putExtra("sms_body", text)
            return if (launch(i)) { ui.markLeaving(); ok("Opened Messages with the text ready; the user needs to tap Send") } else err("No SMS app")
        }

        val pkg = when {
            installed("com.whatsapp") -> "com.whatsapp"
            installed("com.whatsapp.w4b") -> "com.whatsapp.w4b"
            else -> return err("WhatsApp isn't installed")
        }
        val url = "https://api.whatsapp.com/send?phone=${waNumber(c.number)}&text=" + URLEncoder.encode(text, "UTF-8")
        if (!launch(Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage(pkg))) return err("Couldn't open WhatsApp")
        ui.markLeaving()
        val svc = service() ?: return ok("Opened WhatsApp with the message ready; the user needs to tap Send")
        val latch = CountDownLatch(1)
        val sent = AtomicReference(false)
        main.post { svc.autoTapSend(pkg) { done -> sent.set(done); latch.countDown() } }
        latch.await(12, TimeUnit.SECONDS)
        return if (sent.get()) ok("WhatsApp message sent to ${c.name}")
        else ok("Opened WhatsApp with the message ready; the user needs to tap Send")
    }

    // ---------- alarms, timers, reminders ----------

    private fun alarm(a: JSONObject): JSONObject {
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, a.optInt("hour").coerceIn(0, 23))
            .putExtra(AlarmClock.EXTRA_MINUTES, a.optInt("minute").coerceIn(0, 59))
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        a.optString("label").takeIf { it.isNotBlank() }?.let { i.putExtra(AlarmClock.EXTRA_MESSAGE, it) }
        val days = a.optJSONArray("days")
        if (days != null && days.length() > 0) {
            val map = mapOf(
                "sunday" to Calendar.SUNDAY, "monday" to Calendar.MONDAY, "tuesday" to Calendar.TUESDAY,
                "wednesday" to Calendar.WEDNESDAY, "thursday" to Calendar.THURSDAY, "friday" to Calendar.FRIDAY,
                "saturday" to Calendar.SATURDAY
            )
            val list = ArrayList<Int>()
            for (k in 0 until days.length()) map[days.optString(k).lowercase(Locale.ROOT)]?.let { list.add(it) }
            if (list.isNotEmpty()) i.putIntegerArrayListExtra(AlarmClock.EXTRA_DAYS, list)
        }
        val t = "%d:%02d".format(a.optInt("hour"), a.optInt("minute"))
        return if (launch(i)) ok("Alarm set for $t") else err("The clock app didn't accept the alarm")
    }

    private fun timer(seconds: Int, label: String): JSONObject {
        val i = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, seconds.coerceIn(1, 86399))
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        if (label.isNotBlank()) i.putExtra(AlarmClock.EXTRA_MESSAGE, label)
        return if (launch(i)) ok("Timer started for $seconds seconds") else err("The clock app didn't accept the timer")
    }

    private fun addReminder(text: String, whenStr: String): JSONObject {
        if (text.isBlank()) return err("Nothing to remind about")
        val at = parseTime(whenStr) ?: return err("Couldn't understand the time \"$whenStr\"")
        if (at < System.currentTimeMillis() + 30_000) return err("That time has already passed")
        if (Build.VERSION.SDK_INT >= 33) ui.ensurePermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS))
        Reminders.add(ctx, text, at)
        val pretty = SimpleDateFormat("EEE d MMM, h:mm a", Locale.US).format(java.util.Date(at))
        return ok("Reminder set for $pretty")
    }

    private fun parseTime(s: String): Long? {
        val fmts = listOf("yyyy-MM-dd'T'HH:mm", "yyyy-MM-dd'T'HH:mm:ss", "yyyy-MM-dd HH:mm")
        for (f in fmts) {
            try {
                val p = SimpleDateFormat(f, Locale.US).apply { isLenient = false }
                return p.parse(s.trim().take(19))?.time
            } catch (e: Exception) {
            }
        }
        return null
    }

    private fun listReminders(): JSONObject {
        val fmt = SimpleDateFormat("EEE d MMM, h:mm a", Locale.US)
        val arr = JSONArray()
        Reminders.list(ctx).forEach { arr.put("${it.text} at ${fmt.format(java.util.Date(it.at))}") }
        return JSONObject().put("ok", true).put("reminders", arr)
    }

    private fun cancelReminder(text: String): JSONObject {
        val q = text.lowercase(Locale.ROOT)
        val r = Reminders.list(ctx).firstOrNull { it.text.lowercase(Locale.ROOT).contains(q) || q.contains(it.text.lowercase(Locale.ROOT)) }
            ?: return err("No upcoming reminder matches \"$text\"")
        Reminders.cancel(ctx, r.id)
        return ok("Cancelled the reminder: ${r.text}")
    }

    // ---------- info ----------

    private fun notifications(app: String, count: Int): JSONObject {
        val list = NBDb.get(ctx).notifs(app).take(count.coerceIn(1, 15))
        if (list.isEmpty()) return err("No saved notifications" + if (app.isNotBlank()) " from $app" else "")
        val arr = JSONArray()
        val now = System.currentTimeMillis()
        for (n in list) {
            val mins = (now - n.time) / 60000
            val ago = when {
                mins < 1 -> "just now"
                mins < 60 -> "$mins min ago"
                mins < 1440 -> "${mins / 60} h ago"
                else -> "${mins / 1440} days ago"
            }
            arr.put(JSONObject().put("app", n.app).put("from", n.title).put("text", n.body.take(500)).put("when", ago))
        }
        return JSONObject().put("ok", true).put("notifications", arr)
    }

    private fun navigate(dest: String, mode: String): JSONObject {
        val m = when (mode) { "walking" -> "w"; "two_wheeler" -> "l"; "transit" -> "r"; else -> "d" }
        val nav = Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(dest) + "&mode=$m"))
            .setPackage("com.google.android.apps.maps")
        if (launch(nav)) { ui.markLeaving(); return ok("Navigating to $dest") }
        val geo = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(dest)))
        return if (launch(geo)) { ui.markLeaving(); ok("Opened maps for $dest") } else err("No maps app")
    }

    private fun searchWeb(q: String): JSONObject {
        val i = Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, q)
        if (launch(i)) { ui.markLeaving(); return ok("Searching for $q") }
        val web = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + URLEncoder.encode(q, "UTF-8")))
        return if (launch(web)) { ui.markLeaving(); ok("Searching for $q") } else err("No browser")
    }

    private fun youtube(q: String): JSONObject {
        val yt = Intent(Intent.ACTION_SEARCH).setPackage("com.google.android.youtube").putExtra("query", q)
        if (launch(yt)) { ui.markLeaving(); return ok("Showing YouTube results for $q") }
        val web = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + URLEncoder.encode(q, "UTF-8")))
        return if (launch(web)) { ui.markLeaving(); ok("Showing YouTube results for $q") } else err("Couldn't open YouTube")
    }

    @Suppress("unused")
    private fun granted(p: String) = ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
}
