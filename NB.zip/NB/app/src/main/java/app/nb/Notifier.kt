package app.nb

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Icon
import android.os.Build

object Notifier {
    private const val CH_BATTERY = "battery"
    private const val CH_OTP = "otp"
    private const val CH_REMINDER = "reminders"
    const val ID_BATTERY = 101
    const val ID_OTP = 102

    private fun nm(c: Context): NotificationManager = c.getSystemService(NotificationManager::class.java)

    private fun ensureChannels(c: Context) {
        val nm = nm(c)
        nm.createNotificationChannel(NotificationChannel(CH_BATTERY, "Battery full alert", NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel(CH_OTP, "OTP copy", NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel(CH_REMINDER, "Reminders", NotificationManager.IMPORTANCE_HIGH))
    }

    fun canPost(c: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    fun battery(c: Context, level: Int) {
        if (!canPost(c)) return
        ensureChannels(c)
        val n = Notification.Builder(c, CH_BATTERY)
            .setSmallIcon(R.drawable.ic_stat_nb)
            .setContentTitle("Battery at $level%")
            .setContentText("Unplug the charger to help your battery last longer.")
            .setCategory(Notification.CATEGORY_STATUS)
            .setAutoCancel(true)
            .build()
        nm(c).notify(ID_BATTERY, n)
    }

    fun otp(c: Context, code: String) {
        if (!canPost(c)) return
        ensureChannels(c)
        val pi = PendingIntent.getBroadcast(
            c, 0,
            Intent(c, CopyReceiver::class.java).putExtra("text", code),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val action = Notification.Action.Builder(Icon.createWithResource(c, R.drawable.ic_stat_nb), "Copy $code", pi).build()
        val n = Notification.Builder(c, CH_OTP)
            .setSmallIcon(R.drawable.ic_stat_nb)
            .setContentTitle("Code $code")
            .setContentText("Tap to copy")
            .setContentIntent(pi)
            .addAction(action)
            .setAutoCancel(true)
            .setTimeoutAfter(3 * 60 * 1000L)
            .build()
        nm(c).notify(ID_OTP, n)
    }

    fun reminder(c: Context, id: Int, text: String) {
        if (!canPost(c)) return
        ensureChannels(c)
        val open = PendingIntent.getActivity(
            c, id, Intent(c, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(c, CH_REMINDER)
            .setSmallIcon(R.drawable.ic_stat_nb)
            .setContentTitle("Reminder")
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setCategory(Notification.CATEGORY_REMINDER)
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        nm(c).notify(1000 + (id % 100000), n)
    }

    fun cancel(c: Context, id: Int) = nm(c).cancel(id)
}

/** Handles the "Copy code" button on the OTP notification. */
class CopyReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val text = intent.getStringExtra("text") ?: return
        Clip.copy(context, text, "Code copied")
        Notifier.cancel(context, Notifier.ID_OTP)
    }
}
