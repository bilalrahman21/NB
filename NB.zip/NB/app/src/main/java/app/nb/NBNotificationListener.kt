package app.nb

import android.app.Notification
import android.os.Bundle
import android.os.Parcelable
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Saves notifications (so deleted messages stay readable) and spots OTP codes. */
class NBNotificationListener : NotificationListenerService() {

    private val skipPackages = setOf("android", "com.android.systemui", "com.android.providers.downloads")
    private val summaryLine = Regex("^\\d+ (new )?messages?( from \\d+ chats)?$", RegexOption.IGNORE_CASE)
    private var lastOtp = ""
    private var lastOtpTime = 0L

    override fun onListenerConnected() {
        super.onListenerConnected()
        BatteryWatcher.start(this)
    }

    override fun onListenerDisconnected() {
        BatteryWatcher.stop(this)
        super.onListenerDisconnected()
    }

    override fun onDestroy() {
        BatteryWatcher.stop(this)
        super.onDestroy()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        val s = sbn ?: return
        val pkg = s.packageName ?: return
        if (pkg == packageName || pkg in skipPackages) return
        val n = s.notification ?: return
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        if (s.isOngoing) return

        val extras = n.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val body = (lastMessage(extras)
            ?: extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString()?.trim().orEmpty()
        if (body.isEmpty() || summaryLine.matches(body)) return

        try {
            NBDb.get(this).addNotif(pkg, appName(pkg), title, body, s.postTime)
        } catch (e: Exception) {
        }

        if (Prefs.on(this, Prefs.OTP)) {
            val code = OtpDetector.find("$title $body") ?: return
            val now = System.currentTimeMillis()
            if (code == lastOtp && now - lastOtpTime < 60_000) return
            lastOtp = code
            lastOtpTime = now
            NBDb.get(this).addClip(code)
            val acc = NBAccessibilityService.instance
            if (acc != null) acc.showOtpChip(code) else Notifier.otp(this, code)
        }
    }

    /** Messaging apps put the newest message in EXTRA_MESSAGES. */
    private fun lastMessage(extras: Bundle): CharSequence? {
        return try {
            @Suppress("DEPRECATION")
            val arr: Array<Parcelable>? = extras.getParcelableArray(Notification.EXTRA_MESSAGES)
            val last = arr?.lastOrNull() as? Bundle ?: return null
            last.getCharSequence("text")
        } catch (e: Exception) {
            null
        }
    }

    private fun appName(pkg: String): String = try {
        val pm = packageManager
        pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) {
        pkg
    }
}
