package app.nb

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/** Talks to Google's Gemini API using the user's own free API key. */
object Gemini {
    private const val BASE = "https://generativelanguage.googleapis.com/v1beta"
    const val DEFAULT_MODEL = "gemini-3.8-flash"

    class ApiError(val code: Int, msg: String) : Exception(msg)

    fun key(c: Context): String = Prefs.sp(c).getString(Prefs.AI_KEY, "")?.trim().orEmpty()
    fun hasKey(c: Context): Boolean = key(c).isNotEmpty()
    fun model(c: Context): String = Prefs.sp(c).getString(Prefs.AI_MODEL, null) ?: DEFAULT_MODEL

    private fun http(method: String, url: String, key: String, body: String?): Pair<Int, String> {
        return try {
            httpOnce(method, url, key, body)
        } catch (e: java.net.UnknownHostException) {
            throw e
        } catch (e: java.io.IOException) {
            // Slow or dropped connection (common on mobile data): try once more.
            Thread.sleep(800)
            httpOnce(method, url, key, body)
        }
    }

    /** Explains a network failure in plain words. */
    fun networkMessage(c: Context, e: Throwable): String {
        val online = try {
            val cm = c.getSystemService(android.net.ConnectivityManager::class.java)
            val caps = cm?.getNetworkCapabilities(cm.activeNetwork)
            caps?.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true
        } catch (x: Exception) { true }
        return when {
            !online -> "You're offline. Turn on mobile data or Wi-Fi (and Data roaming if you're abroad)."
            e is java.net.UnknownHostException -> "I can't find Google's AI server. The internet may be blocked or very weak right now."
            e is java.net.SocketTimeoutException -> "The connection is too slow right now. Please try again."
            e is javax.net.ssl.SSLException -> "A secure connection failed. Check that the phone's date and time are correct."
            else -> "Network problem: ${e.javaClass.simpleName}" + (e.message?.let { ": " + it.take(80) } ?: "")
        }
    }

    private fun httpOnce(method: String, url: String, key: String, body: String?): Pair<Int, String> {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = method
            conn.connectTimeout = 15000
            conn.readTimeout = 60000
            conn.setRequestProperty("x-goog-api-key", key)
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            if (body != null) {
                conn.doOutput = true
                conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            return Pair(code, text)
        } finally {
            conn.disconnect()
        }
    }

    private fun errorMessage(code: Int, body: String): String {
        val m = try { JSONObject(body).optJSONObject("error")?.optString("message") } catch (e: Exception) { null }
        return when {
            code == 429 -> "NB's free AI limit is used up for the moment. Try again in a minute."
            code == 403 || (code == 400 && m?.contains("API key", ignoreCase = true) == true) ->
                "The Gemini API key isn't working. Check it in NB's settings."
            m.isNullOrBlank() -> "The AI service returned error $code."
            else -> m.take(220)
        }
    }

    /** Picks the newest Flash model this key can use, and remembers it. */
    fun detectModel(c: Context): String {
        val (code, body) = http("GET", "$BASE/models?pageSize=200", key(c), null)
        if (code !in 200..299) throw ApiError(code, errorMessage(code, body))
        val arr = JSONObject(body).optJSONArray("models") ?: JSONArray()
        val skip = listOf("lite", "image", "tts", "live", "audio", "embed", "8b", "robotics", "computer")
        data class M(val name: String, val version: Double, val preview: Boolean)
        val found = ArrayList<M>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val name = o.optString("name").removePrefix("models/")
            val lower = name.lowercase()
            if (!lower.startsWith("gemini") || !lower.contains("flash")) continue
            if (skip.any { lower.contains(it) }) continue
            val methods = o.optJSONArray("supportedGenerationMethods")?.toString() ?: ""
            if (!methods.contains("generateContent")) continue
            val v = Regex("gemini-(\\d+(?:\\.\\d+)?)").find(lower)?.groupValues?.get(1)?.toDoubleOrNull() ?: 0.0
            found.add(M(name, v, lower.contains("preview") || lower.contains("exp")))
        }
        val pick = found.sortedWith(
            compareBy<M> { it.preview }.thenByDescending { it.version }.thenBy { it.name.length }
        ).firstOrNull()?.name ?: DEFAULT_MODEL
        Prefs.sp(c).edit().putString(Prefs.AI_MODEL, pick).apply()
        return pick
    }

    fun generate(c: Context, body: JSONObject): JSONObject {
        var model = model(c)
        for (attempt in 0..2) {
            val (code, text) = http("POST", "$BASE/models/$model:generateContent", key(c), body.toString())
            if (code in 200..299) return JSONObject(text)
            val lower = text.lowercase()
            if (attempt < 2 && (code == 404 || (code == 400 && lower.contains("not found")))) {
                model = detectModel(c)
                continue
            }
            if (attempt < 2 && code == 400 && lower.contains("thinking") && body.has("generationConfig")) {
                body.remove("generationConfig")
                Prefs.set(c, Prefs.AI_NO_THINK_LEVEL, true)
                continue
            }
            throw ApiError(code, errorMessage(code, text))
        }
        throw ApiError(0, "The AI service didn't respond.")
    }
}

/** One conversation with NB. Call [ask] from a background thread. */
class Brain(private val ctx: Context, private val tools: Tools) {
    private val history = JSONArray()

    private fun systemPrompt(): String {
        val now = SimpleDateFormat("EEEE d MMMM yyyy, h:mm a", Locale.US).format(Date())
        val tz = TimeZone.getDefault().id
        return """
            You are NB, a friendly voice assistant built into the user's Android phone (an Honor Play 20a).
            The user talks to you by voice and your reply is read aloud, so answer in one or two short sentences of plain text.
            No markdown, lists, emojis or links. Reply in the same language the user spoke.
            Use the tools to act on the phone whenever the user asks for an action. Never say you did something unless the tool result says it worked.
            If a tool returns an error or several possible matches, say so briefly or ask one short question.
            For calls and messages the phone itself asks the user to confirm, so don't ask for confirmation yourself; just call the tool.
            Never invent phone numbers or contact names.
            When you pass a contact or app name to a tool, write it in English letters the way it is most likely saved in the phone
            (for example "Ahmed", not "അഹമ്മദ്"; "WhatsApp", not "വാട്സാപ്പ്"). Keep the message text itself in the language the user wants.
            The phone may be locked. Tools that need the phone unlocked will ask the user to unlock it themselves; just call them.
            For questions about what is on the screen, use read_screen. For "read my messages" or "what did X send", use recent_notifications.
            You cannot browse the web. For news, prices, weather or other live information, offer to search and use search_web if they agree or asked to search.
            The current date and time is $now (time zone $tz). Turn relative times like "in 20 minutes" or "tomorrow at 7" into exact local times.
        """.trimIndent()
    }

    fun ask(userText: String): String {
        val start = history.length()
        history.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", userText))))
        try {
            for (round in 0 until 6) {
                val body = JSONObject()
                    .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt()))))
                    .put("contents", history)
                    .put("tools", JSONArray().put(JSONObject().put("functionDeclarations", Tools.declarations())))
                if (!Prefs.on(ctx, Prefs.AI_NO_THINK_LEVEL)) {
                    body.put("generationConfig", JSONObject().put("thinkingConfig", JSONObject().put("thinkingLevel", "low")))
                }
                val res = Gemini.generate(ctx, body)
                val content = res.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")
                if (content == null) {
                    truncate(start)
                    return "Sorry, I can't help with that one."
                }
                if (!content.has("role")) content.put("role", "model")
                val parts = content.optJSONArray("parts") ?: JSONArray()
                // Keep the model's turn exactly as sent (it may carry thought signatures).
                history.put(content)

                val calls = ArrayList<JSONObject>()
                val text = StringBuilder()
                for (i in 0 until parts.length()) {
                    val p = parts.optJSONObject(i) ?: continue
                    p.optJSONObject("functionCall")?.let { calls.add(it) }
                    if (p.has("text") && !p.optBoolean("thought", false)) text.append(p.optString("text"))
                }
                if (calls.isEmpty()) return text.toString().trim().ifEmpty { "Done." }

                val responses = JSONArray()
                for (call in calls) {
                    val name = call.optString("name")
                    val args = call.optJSONObject("args") ?: JSONObject()
                    val result = try {
                        tools.run(name, args)
                    } catch (e: Throwable) {
                        CrashLog.note(ctx, "tool $name", e)
                        JSONObject().put("error", e.message ?: "failed")
                    }
                    val fr = JSONObject().put("name", name).put("response", JSONObject().put("result", result))
                    if (call.has("id")) fr.put("id", call.optString("id"))
                    responses.put(JSONObject().put("functionResponse", fr))
                }
                history.put(JSONObject().put("role", "user").put("parts", responses))
            }
            return "Sorry, that took too many steps."
        } catch (e: Throwable) {
            truncate(start)
            throw e
        }
    }

    private fun truncate(len: Int) {
        while (history.length() > len) history.remove(history.length() - 1)
    }
}

/** Reads NB's replies aloud. Lives on after the voice screen closes so speech isn't cut off. */
object Speaker : TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var ready = false
    private var pending: Triple<String, String, (() -> Unit)?>? = null
    private val callbacks = HashMap<String, () -> Unit>()
    private val main = Handler(Looper.getMainLooper())

    fun init(c: Context) {
        if (tts == null) tts = TextToSpeech(c.applicationContext, this)
    }

    override fun onInit(status: Int) {
        ready = status == TextToSpeech.SUCCESS
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) = finish(utteranceId)
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) = finish(utteranceId)
            override fun onError(utteranceId: String?, errorCode: Int) = finish(utteranceId)
            override fun onStop(utteranceId: String?, interrupted: Boolean) {
                // Stopped on purpose: drop the callback.
                if (utteranceId != null) synchronized(callbacks) { callbacks.remove(utteranceId) }
            }
        })
        val p = pending
        pending = null
        if (p != null) {
            if (ready) speakNow(p.first, p.second, p.third) else p.third?.let { cb -> main.post { cb() } }
        }
    }

    private fun finish(id: String?) {
        if (id == null) return
        val cb = synchronized(callbacks) { callbacks.remove(id) } ?: return
        main.post { cb() }
    }

    fun speak(c: Context, text: String, lang: String, onDone: (() -> Unit)? = null) {
        init(c)
        if (!ready) {
            pending = Triple(text, lang, onDone)
            return
        }
        speakNow(text, lang, onDone)
    }

    /** Set when the reply's language has no voice on this phone (e.g. "Malayalam"). */
    @Volatile var missingVoice: String? = null
        private set

    /** Chooses the voice from the reply's own script, so a Malayalam reply gets a Malayalam voice. */
    private fun langFor(text: String, setting: String): String {
        fun has(a: Char, b: Char) = text.any { it in a..b }
        return when {
            has('\u0D00', '\u0D7F') -> "ml-IN"
            has('\u0B80', '\u0BFF') -> "ta-IN"
            has('\u0900', '\u097F') -> "hi-IN"
            has('\u0600', '\u06FF') -> if (setting.startsWith("ur")) "ur-PK" else "ar-AE"
            setting.startsWith("en") -> setting
            else -> "en-IN" // English reply while the voice language is something else
        }
    }

    private fun speakNow(text: String, lang: String, onDone: (() -> Unit)?) {
        val t = tts ?: run { onDone?.let { cb -> main.post { cb() } }; return }
        val want = langFor(text, lang)
        missingVoice = null
        try {
            val loc = Locale.forLanguageTag(want)
            val r = t.setLanguage(loc)
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                missingVoice = loc.getDisplayLanguage(Locale.ENGLISH)
                // Speak with the English voice rather than staying silent, unless the text isn't English at all.
                if (want.startsWith("en")) t.setLanguage(Locale.US)
                else { onDone?.let { cb -> main.post { cb() } }; return }
            }
        } catch (e: Exception) {}
        val id = "nb" + System.nanoTime()
        if (onDone != null) synchronized(callbacks) { callbacks[id] = onDone }
        val r = t.speak(text, TextToSpeech.QUEUE_FLUSH, null, id)
        if (r != TextToSpeech.SUCCESS) finish(id)
    }

    fun stop() {
        pending = null
        synchronized(callbacks) { callbacks.clear() }
        try { tts?.stop() } catch (e: Exception) {}
    }
}
