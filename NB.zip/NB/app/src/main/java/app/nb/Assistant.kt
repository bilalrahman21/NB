package app.nb

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import org.json.JSONArray
import org.json.JSONObject
import okhttp3.Dns
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.net.Inet4Address
import java.net.InetAddress
import java.util.concurrent.TimeUnit
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/** Talks to Google's Gemini API using the user's own free API key. */
object Gemini {
    private const val BASE = "https://generativelanguage.googleapis.com/v1beta"
    const val DEFAULT_MODEL = "gemini-3.8-flash"

    class ApiError(val code: Int, msg: String) : Exception(msg)

    fun key(c: Context): String = Prefs.sp(c).getString(Prefs.AI_KEY, "")?.trim().orEmpty()
    fun hasKey(c: Context): Boolean = key(c).isNotEmpty()
    fun model(c: Context): String = Prefs.sp(c).getString(Prefs.AI_MODEL, null) ?: DEFAULT_MODEL

    private fun http(method: String, url: String, key: String, body: String?): Pair<Int, String> {
        return try {
            httpOnce(method, url, key, body)
        } catch (e: java.net.UnknownHostException) {
            throw e
        } catch (e: java.io.IOException) {
            // Slow or dropped connection (common on mobile data): try once more.
            Thread.sleep(800)
            httpOnce(method, url, key, body)
        }
    }

    /** Explains a network failure in plain words. */
    fun networkMessage(c: Context, e: Throwable): String {
        val online = try {
            val cm = c.getSystemService(android.net.ConnectivityManager::class.java)
            val caps = cm?.getNetworkCapabilities(cm.activeNetwork)
            caps?.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true
        } catch (x: Exception) { true }
        return when {
            !online -> "You're offline. Turn on mobile data or Wi-Fi (and Data roaming if you're abroad)."
            e is java.net.UnknownHostException -> "I can't find Google's AI server. The internet may be blocked or very weak right now."
            e is java.net.SocketTimeoutException -> "Gemini took too long to answer. Please try again in a moment."
            e is javax.net.ssl.SSLException -> "A secure connection failed. Check that the phone's date and time are correct."
            else -> "Network problem: ${e.javaClass.simpleName}" + (e.message?.let { ": " + it.take(80) } ?: "")
        }
    }

    /** Prefers IPv4: some mobile networks silently drop larger uploads sent over IPv6. */
    private object V4First : Dns {
        override fun lookup(hostname: String): List<InetAddress> {
            val all = Dns.SYSTEM.lookup(hostname)
            val v4 = all.filterIsInstance<Inet4Address>()
            return if (v4.isEmpty()) all else v4 + all.filter { it !is Inet4Address }
        }
    }

    private val JSON_TYPE = "application/json; charset=utf-8".toMediaType()

    private val base: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .readTimeout(45, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build()
    }

    /** IPv4-first client (default), or the phone's normal route when [v4] is false. */
    private fun client(v4: Boolean, readMs: Int): OkHttpClient {
        val b = base.newBuilder().readTimeout(readMs.toLong(), TimeUnit.MILLISECONDS)
        if (v4) b.dns(V4First)
        return b.build()
    }

    private fun request(url: String, key: String, body: String?, sse: Boolean = false): Request {
        val r = Request.Builder().url(url).header("x-goog-api-key", key)
        if (sse) r.header("Accept", "text/event-stream")
        if (body != null) r.post(body.toRequestBody(JSON_TYPE)) else r.get()
        return r.build()
    }

    private fun httpOnce(method: String, url: String, key: String, body: String?, readMs: Int = 60000, v4: Boolean = true): Pair<Int, String> {
        val send = if (method == "GET") null else (body ?: "")
        client(v4, readMs).newCall(request(url, key, send)).execute().use { resp ->
            return Pair(resp.code, resp.body?.string() ?: "")
        }
    }

    private fun errorMessage(code: Int, body: String): String {
        val m = try { JSONObject(body).optJSONObject("error")?.optString("message") } catch (e: Exception) { null }
        return when {
            code == 429 -> "NB's free AI limit is used up for the moment. Try again in a minute."
            code == 403 || (code == 400 && m?.contains("API key", ignoreCase = true) == true) ->
                "The Gemini API key isn't working. Check it in NB's settings."
            m.isNullOrBlank() -> "The AI service returned error $code."
            else -> m.take(220)
        }
    }

    /** Flash models this key can use, newest first (including the faster "Lite" ones). */
    fun listModels(c: Context): List<String> {
        val (code, body) = http("GET", "$BASE/models?pageSize=200", key(c), null)
        if (code !in 200..299) throw ApiError(code, errorMessage(code, body))
        val arr = JSONObject(body).optJSONArray("models") ?: JSONArray()
        val skip = listOf("image", "tts", "live", "audio", "embed", "8b", "robotics", "computer", "thinking")
        data class M(val name: String, val version: Double, val preview: Boolean, val lite: Boolean)
        val found = ArrayList<M>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val name = o.optString("name").removePrefix("models/")
            val lower = name.lowercase()
            if (!lower.startsWith("gemini") || !lower.contains("flash")) continue
            if (skip.any { lower.contains(it) }) continue
            val methods = o.optJSONArray("supportedGenerationMethods")?.toString() ?: ""
            if (!methods.contains("generateContent")) continue
            val v = Regex("gemini-(\\d+(?:\\.\\d+)?)").find(lower)?.groupValues?.get(1)?.toDoubleOrNull() ?: 0.0
            found.add(M(name, v, lower.contains("preview") || lower.contains("exp"), lower.contains("lite")))
        }
        return found.sortedWith(
            compareBy<M> { it.preview }.thenByDescending { it.version }.thenBy { it.lite }.thenBy { it.name.length }
        ).map { it.name }.distinct()
    }

    /** Thinking settings to try for a model, fastest first. */
    private fun modesFor(model: String): List<String> {
        val v = Regex("gemini-(\\d+)").find(model.lowercase())?.groupValues?.get(1)?.toIntOrNull() ?: 3
        return if (v <= 2) listOf("budget0", "none") else listOf("minimal", "low", "none")
    }

    private fun thinkingFor(mode: String): JSONObject? = when (mode) {
        "minimal", "low" -> JSONObject().put("thinkingConfig", JSONObject().put("thinkingLevel", mode))
        "budget0" -> JSONObject().put("thinkingConfig", JSONObject().put("thinkingBudget", 0))
        else -> null
    }

    /** The generationConfig to send with the chosen model, or null. */
    fun thinkingConfig(c: Context): JSONObject? {
        val mode = Prefs.sp(c).getString(Prefs.AI_THINK, null) ?: modesFor(model(c)).first()
        return thinkingFor(mode)
    }

    class Trial(val model: String, val mode: String, val ms: Long?, val note: String)

    /** Asks one model a tiny question (with NB's tools) and times it. */
    private fun trial(c: Context, model: String, timeoutMs: Int): Trial {
        val gen = "$BASE/models/$model:generateContent"
        for (mode in modesFor(model)) {
            val req = JSONObject()
                .put("contents", JSONArray().put(JSONObject().put("role", "user")
                    .put("parts", JSONArray().put(JSONObject().put("text", "Reply with just: OK")))))
                .put("tools", JSONArray().put(JSONObject().put("functionDeclarations", Tools.declarations())))
            thinkingFor(mode)?.let { req.put("generationConfig", it) }
            val t0 = System.currentTimeMillis()
            try {
                val (code, body) = httpOnce("POST", gen, key(c), req.toString(), timeoutMs)
                val ms = System.currentTimeMillis() - t0
                if (code in 200..299) return Trial(model, mode, ms, "OK")
                if (code == 400 && body.lowercase().contains("thinking")) continue
                return Trial(model, mode, null, "HTTP $code " + errorMessage(code, body).take(70))
            } catch (e: java.net.SocketTimeoutException) {
                return Trial(model, mode, null, "too slow (over ${timeoutMs / 1000} s)")
            } catch (e: Exception) {
                return Trial(model, mode, null, e.javaClass.simpleName)
            }
        }
        return Trial(model, "none", null, "no thinking setting accepted")
    }

    /** Tests the newest Flash models side by side and keeps the fastest that works. */
    fun pickFastest(c: Context, exclude: String? = null): List<Trial> {
        val candidates = listModels(c).filter { it != exclude }.take(6)
        if (candidates.isEmpty()) throw ApiError(0, "No usable Gemini models were found for this key.")
        val pool = java.util.concurrent.Executors.newFixedThreadPool(candidates.size)
        val trials = try {
            candidates.map { m -> pool.submit<Trial> { trial(c, m, 15000) } }.map { f ->
                try { f.get(40, TimeUnit.SECONDS) } catch (e: Exception) { Trial("?", "none", null, "no answer") }
            }
        } finally {
            pool.shutdownNow()
        }
        val best = trials.filter { it.ms != null }.minByOrNull { it.ms ?: Long.MAX_VALUE }
            ?: throw ApiError(0, "No Gemini model answered in time. Google's free service may be busy; please try again later.")
        Prefs.sp(c).edit().putString(Prefs.AI_MODEL, best.model).putString(Prefs.AI_THINK, best.mode).apply()
        return trials
    }

    /** Used when the key is saved: picks the fastest model and says which. */
    fun detectModel(c: Context): String {
        val trials = pickFastest(c)
        val best = trials.filter { it.ms != null }.minByOrNull { it.ms ?: Long.MAX_VALUE }
        return model(c) + (best?.ms?.let { " (%.1f s)".format(it / 1000.0) } ?: "")
    }

    /** Step-by-step connection test, so problems can be pinned down. */
    fun diagnose(c: Context): String {
        val sb = StringBuilder()
        val key = key(c)
        sb.append("Key: ").append(if (key.length > 8) key.take(4) + "…" + key.takeLast(4) else "(missing)").append("\n")
        sb.append("Model before test: ").append(model(c)).append("\n\n")
        val t0 = System.currentTimeMillis()
        try {
            val (code, body) = httpOnce("GET", "$BASE/models?pageSize=5", key, null, 20000)
            sb.append("1. Reach Google (${System.currentTimeMillis() - t0} ms): HTTP $code")
                .append(if (code in 200..299) " OK" else " " + errorMessage(code, body)).append("\n\n")
        } catch (e: Exception) {
            sb.append("1. Reach Google: FAILED ${e.javaClass.simpleName}\n\n")
            return sb.toString().trim()
        }
        sb.append("2. Model speed test (tiny question with NB's tools):\n")
        try {
            for (t in pickFastest(c)) {
                sb.append("• ").append(t.model).append(" [").append(t.mode).append("]: ")
                    .append(t.ms?.let { "%.1f s".format(it / 1000.0) } ?: t.note).append("\n")
            }
            sb.append("\nNB will now use: ").append(model(c))
                .append(" [").append(Prefs.sp(c).getString(Prefs.AI_THINK, "") ?: "").append("]")
        } catch (e: ApiError) {
            sb.append(e.message)
        } catch (e: Exception) {
            sb.append("FAILED ${e.javaClass.simpleName}")
        }
        return sb.toString().trim()
    }

    private class Resp(val code: Int, val error: String, val json: JSONObject?)

    /** Streams the reply, so the connection never sits silent while Gemini works. */
    private fun streamOnce(url: String, key: String, body: String, v4: Boolean = true): Resp {
        client(v4, 45000).newCall(request(url, key, body, sse = true)).execute().use { resp ->
            val code = resp.code
            if (code !in 200..299) return Resp(code, resp.body?.string() ?: "", null)
            val parts = JSONArray()
            var feedback: JSONObject? = null
            var gotCandidate = false
            val source = resp.body?.source() ?: return Resp(code, "", JSONObject())
            while (true) {
                val line = source.readUtf8Line() ?: break
                if (!line.startsWith("data:")) continue
                val obj = try { JSONObject(line.substring(5).trim()) } catch (e: Exception) { null } ?: continue
                obj.optJSONObject("promptFeedback")?.let { feedback = it }
                val cand = obj.optJSONArray("candidates")?.optJSONObject(0) ?: continue
                gotCandidate = true
                val ps = cand.optJSONObject("content")?.optJSONArray("parts") ?: continue
                for (i in 0 until ps.length()) addPart(parts, ps.optJSONObject(i) ?: continue)
            }
            val out = JSONObject()
            if (gotCandidate && parts.length() > 0) {
                out.put("candidates", JSONArray().put(JSONObject().put("content",
                    JSONObject().put("role", "model").put("parts", parts))))
            }
            feedback?.let { out.put("promptFeedback", it) }
            return Resp(code, "", out)
        }
    }

    private fun plainText(p: JSONObject) = p.length() == 1 && p.has("text")

    /** Joins streamed text pieces. Parts carrying signatures or function calls are kept exactly as sent. */
    private fun addPart(parts: JSONArray, p: JSONObject) {
        if (plainText(p) && parts.length() > 0) {
            val last = parts.optJSONObject(parts.length() - 1)
            if (last != null && plainText(last)) {
                last.put("text", last.optString("text") + p.optString("text"))
                return
            }
        }
        parts.put(p)
    }

    fun generate(c: Context, body: JSONObject): JSONObject {
        var model = model(c)
        var switched = false
        for (attempt in 0..5) {
            val url = "$BASE/models/$model:streamGenerateContent?alt=sse"
            val r = try {
                streamOnce(url, key(c), body.toString())
            } catch (e: java.net.SocketTimeoutException) {
                // This model is too slow right now: switch to the fastest other model once.
                if (switched) throw e
                switched = true
                pickFastest(c, exclude = model)
                model = model(c)
                applyThinking(c, body)
                continue
            } catch (e: java.net.UnknownHostException) {
                throw e
            } catch (e: java.io.IOException) {
                if (attempt >= 1) throw e
                Thread.sleep(800)
                continue
            }
            if (r.code in 200..299 && r.json != null) return r.json
            val lower = r.error.lowercase()
            if (!switched && (r.code == 404 || (r.code == 400 && lower.contains("not found")))) {
                switched = true
                pickFastest(c, exclude = model)
                model = model(c)
                applyThinking(c, body)
                continue
            }
            if (r.code == 400 && lower.contains("thinking")) {
                // This model doesn't accept that thinking setting: use the next one and remember it.
                val modes = modesFor(model)
                val cur = Prefs.sp(c).getString(Prefs.AI_THINK, null) ?: modes.first()
                val next = modes.getOrNull(modes.indexOf(cur) + 1) ?: "none"
                if (next == cur) throw ApiError(r.code, errorMessage(r.code, r.error))
                Prefs.sp(c).edit().putString(Prefs.AI_THINK, next).apply()
                applyThinking(c, body)
                continue
            }
            throw ApiError(r.code, errorMessage(r.code, r.error))
        }
        throw ApiError(0, "Gemini didn't answer. Please try again.")
    }

    private fun applyThinking(c: Context, body: JSONObject) {
        val cfg = thinkingConfig(c)
        if (cfg == null) body.remove("generationConfig") else body.put("generationConfig", cfg)
    }
}

/** One conversation with NB. Call [ask] from a background thread. */
class Brain(private val ctx: Context, private val tools: Tools) {
    private val history = JSONArray()

    private fun systemPrompt(): String {
        val now = SimpleDateFormat("EEEE d MMMM yyyy, h:mm a", Locale.US).format(Date())
        val tz = TimeZone.getDefault().id
        return """
            You are NB, a friendly voice assistant built into the user's Android phone (an Honor Play 20a).
            The user talks to you by voice and your reply is read aloud, so answer in one or two short sentences of plain text.
            No markdown, lists, emojis or links. Reply in the same language the user spoke.
            Use the tools to act on the phone whenever the user asks for an action. Never say you did something unless the tool result says it worked.
            If a tool returns an error or several possible matches, say so briefly or ask one short question.
            For calls and messages the phone itself asks the user to confirm, so don't ask for confirmation yourself; just call the tool.
            Never invent phone numbers or contact names.
            When you pass a contact or app name to a tool, write it in English letters the way it is most likely saved in the phone
            (for example "Ahmed", not "അഹമ്മദ്"; "WhatsApp", not "വാട്സാപ്പ്"). Keep the message text itself in the language the user wants.
            The phone may be locked. Tools that need the phone unlocked will ask the user to unlock it themselves; just call them.
            For questions about what is on the screen, use read_screen. For "read my messages" or "what did X send", use recent_notifications.
            You cannot browse the web. For news, prices, weather or other live information, offer to search and use search_web if they agree or asked to search.
            The current date and time is $now (time zone $tz). Turn relative times like "in 20 minutes" or "tomorrow at 7" into exact local times.
        """.trimIndent()
    }

    fun ask(userText: String): String {
        val start = history.length()
        history.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", userText))))
        try {
            for (round in 0 until 6) {
                val body = JSONObject()
                    .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt()))))
                    .put("contents", history)
                    .put("tools", JSONArray().put(JSONObject().put("functionDeclarations", Tools.declarations())))
                Gemini.thinkingConfig(ctx)?.let { body.put("generationConfig", it) }
                val res = Gemini.generate(ctx, body)
                val content = res.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")
                if (content == null) {
                    truncate(start)
                    return "Sorry, I can't help with that one."
                }
                if (!content.has("role")) content.put("role", "model")
                val parts = content.optJSONArray("parts") ?: JSONArray()
                // Keep the model's turn exactly as sent (it may carry thought signatures).
                history.put(content)

                val calls = ArrayList<JSONObject>()
                val text = StringBuilder()
                for (i in 0 until parts.length()) {
                    val p = parts.optJSONObject(i) ?: continue
                    p.optJSONObject("functionCall")?.let { calls.add(it) }
                    if (p.has("text") && !p.optBoolean("thought", false)) text.append(p.optString("text"))
                }
                if (calls.isEmpty()) return text.toString().trim().ifEmpty { "Done." }

                val responses = JSONArray()
                for (call in calls) {
                    val name = call.optString("name")
                    val args = call.optJSONObject("args") ?: JSONObject()
                    val result = try {
                        tools.run(name, args)
                    } catch (e: Throwable) {
                        CrashLog.note(ctx, "tool $name", e)
                        JSONObject().put("error", e.message ?: "failed")
                    }
                    val fr = JSONObject().put("name", name).put("response", JSONObject().put("result", result))
                    if (call.has("id")) fr.put("id", call.optString("id"))
                    responses.put(JSONObject().put("functionResponse", fr))
                }
                history.put(JSONObject().put("role", "user").put("parts", responses))
            }
            return "Sorry, that took too many steps."
        } catch (e: Throwable) {
            truncate(start)
            throw e
        }
    }

    private fun truncate(len: Int) {
        while (history.length() > len) history.remove(history.length() - 1)
    }
}

/** Reads NB's replies aloud. Lives on after the voice screen closes so speech isn't cut off. */
object Speaker : TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var ready = false
    private var pending: Triple<String, String, (() -> Unit)?>? = null
    private val callbacks = HashMap<String, () -> Unit>()
    private val main = Handler(Looper.getMainLooper())

    fun init(c: Context) {
        if (tts == null) tts = TextToSpeech(c.applicationContext, this)
    }

    override fun onInit(status: Int) {
        ready = status == TextToSpeech.SUCCESS
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) = finish(utteranceId)
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) = finish(utteranceId)
            override fun onError(utteranceId: String?, errorCode: Int) = finish(utteranceId)
            override fun onStop(utteranceId: String?, interrupted: Boolean) {
                // Stopped on purpose: drop the callback.
                if (utteranceId != null) synchronized(callbacks) { callbacks.remove(utteranceId) }
            }
        })
        val p = pending
        pending = null
        if (p != null) {
            if (ready) speakNow(p.first, p.second, p.third) else p.third?.let { cb -> main.post { cb() } }
        }
    }

    private fun finish(id: String?) {
        if (id == null) return
        val cb = synchronized(callbacks) { callbacks.remove(id) } ?: return
        main.post { cb() }
    }

    fun speak(c: Context, text: String, lang: String, onDone: (() -> Unit)? = null) {
        init(c)
        if (!ready) {
            pending = Triple(text, lang, onDone)
            return
        }
        speakNow(text, lang, onDone)
    }

    /** Set when the reply's language has no voice on this phone (e.g. "Malayalam"). */
    @Volatile var missingVoice: String? = null
        private set

    /** Chooses the voice from the reply's own script, so a Malayalam reply gets a Malayalam voice. */
    private fun langFor(text: String, setting: String): String {
        fun has(a: Char, b: Char) = text.any { it in a..b }
        return when {
            has('\u0D00', '\u0D7F') -> "ml-IN"
            has('\u0B80', '\u0BFF') -> "ta-IN"
            has('\u0900', '\u097F') -> "hi-IN"
            has('\u0600', '\u06FF') -> if (setting.startsWith("ur")) "ur-PK" else "ar-AE"
            setting.startsWith("en") -> setting
            else -> "en-IN" // English reply while the voice language is something else
        }
    }

    private fun speakNow(text: String, lang: String, onDone: (() -> Unit)?) {
        val t = tts ?: run { onDone?.let { cb -> main.post { cb() } }; return }
        val want = langFor(text, lang)
        missingVoice = null
        try {
            val loc = Locale.forLanguageTag(want)
            val r = t.setLanguage(loc)
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                missingVoice = loc.getDisplayLanguage(Locale.ENGLISH)
                // Speak with the English voice rather than staying silent, unless the text isn't English at all.
                if (want.startsWith("en")) t.setLanguage(Locale.US)
                else { onDone?.let { cb -> main.post { cb() } }; return }
            }
        } catch (e: Exception) {}
        val id = "nb" + System.nanoTime()
        if (onDone != null) synchronized(callbacks) { callbacks[id] = onDone }
        val r = t.speak(text, TextToSpeech.QUEUE_FLUSH, null, id)
        if (r != TextToSpeech.SUCCESS) finish(id)
    }

    fun stop() {
        pending = null
        synchronized(callbacks) { callbacks.clear() }
        try { tts?.stop() } catch (e: Exception) {}
    }
}
