package app.nb

import android.app.Activity
import android.app.AlarmManager
import android.app.PendingIntent
import android.app.TimePickerDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import java.util.Calendar

/** Schedule helpers for rear-screen night mode. */
object Rear {
    fun nightStart(c: Context) = Prefs.int(c, Prefs.NIGHT_START, 23 * 60)
    fun nightEnd(c: Context) = Prefs.int(c, Prefs.NIGHT_END, 7 * 60)

    fun fmt(minutes: Int): String {
        val h = minutes / 60
        val m = minutes % 60
        val ampm = if (h < 12) "AM" else "PM"
        val h12 = if (h % 12 == 0) 12 else h % 12
        return "%d:%02d %s".format(h12, m, ampm)
    }

    fun isNightNow(c: Context): Boolean {
        val cal = Calendar.getInstance()
        val now = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        val s = nightStart(c)
        val e = nightEnd(c)
        return if (s == e) false else if (s < e) now in s until e else now >= s || now < e
    }

    /** The next start or end time, in milliseconds. */
    fun nextBoundary(c: Context): Long = minOf(nextAt(nightStart(c)), nextAt(nightEnd(c)))

    /** Wakes NB at the next start/end time, even if the phone is asleep. */
    fun schedule(c: Context) {
        val am = c.getSystemService(AlarmManager::class.java) ?: return
        val pi = PendingIntent.getBroadcast(
            c, 11, Intent(c, RearNightReceiver::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        am.cancel(pi)
        if (!Prefs.on(c, Prefs.REAR_NIGHT)) return
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, nextBoundary(c) + 3000, pi)
    }

    private fun nextAt(minutes: Int): Long {
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, minutes / 60)
            set(Calendar.MINUTE, minutes % 60)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        if (cal.timeInMillis <= System.currentTimeMillis()) cal.add(Calendar.DAY_OF_YEAR, 1)
        return cal.timeInMillis
    }
}

class RearNightReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        try {
            NBAccessibilityService.instance?.applyNight()
        } catch (e: Throwable) {
            CrashLog.note(context, "rear night", e)
        }
        Rear.schedule(context)
    }
}

/** Rear display page: night schedule plus manual on/off. */
class RearActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var startValue: TextView
    private lateinit var endValue: TextView
    private val main = Handler(Looper.getMainLooper())
    private val refresher = object : Runnable {
        override fun run() {
            refreshStatus()
            main.postDelayed(this, 1500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setDecorFitsSystemWindows(false)

        val scroll = ScrollView(this).apply { setBackgroundColor(Ui.BG); isFillViewport = true }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(col)
        scroll.padForSystemBars(16)

        col.addView(label("Rear display", 26f, Ui.TEXT, true).apply { setPadding(dp(4), dp(8), 0, dp(4)) })
        col.addView(label(
            "NB turns the phone's \"Secondary display features\" switch off at night and on in the morning. It opens that setting for a moment, flips the switch and goes back.",
            14f, Ui.SUB
        ).apply { setPadding(dp(4), 0, dp(4), dp(16)) })

        // Night schedule
        val night = card(col, "Night schedule")
        val swRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, dp(8))
        }
        swRow.addView(label("Turn rear screen off at night", 15f), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val sw = Switch(this).apply {
            isChecked = Prefs.on(this@RearActivity, Prefs.REAR_NIGHT)
            setOnCheckedChangeListener { _, checked ->
                Prefs.set(this@RearActivity, Prefs.REAR_NIGHT, checked)
                if (checked && NBAccessibilityService.instance == null) toast("Turn on NB in Accessibility for this to work")
            }
        }
        swRow.addView(sw)
        night.addView(swRow)
        startValue = timeRow(night, "Off from") { pickTime(Prefs.NIGHT_START, Rear.nightStart(this)) }
        endValue = timeRow(night, "On again at") { pickTime(Prefs.NIGHT_END, Rear.nightEnd(this)) }
        night.addView(label(
            "If the phone is locked at that time, NB switches it the next time you unlock.",
            12.5f, Ui.SUB
        ).apply { setPadding(0, dp(6), 0, 0) })
        status = label("", 13f, Ui.SUB).apply { setPadding(0, dp(10), 0, 0) }
        night.addView(status)

        // Manual
        val manual = card(col, "Switch now")
        manual.addView(label(
            "You can also do this from the round floating NB button: tap it and choose Rear screen.",
            13f, Ui.SUB
        ).apply { setPadding(0, 0, 0, dp(12)) })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(button("Turn off") { manualSwitch(false) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginEnd = dp(8)
        })
        row.addView(button("Turn on") { manualSwitch(true) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        manual.addView(row)

        setContentView(scroll)
        refreshTimes()
    }

    override fun onResume() {
        super.onResume()
        main.post(refresher)
    }

    override fun onPause() {
        main.removeCallbacks(refresher)
        super.onPause()
    }

    private fun manualSwitch(on: Boolean) {
        val svc = NBAccessibilityService.instance
        if (svc == null) { toast("Turn on NB in Accessibility first"); return }
        svc.manualRearSwitch(on)
    }

    private fun pickTime(key: String, current: Int) {
        TimePickerDialog(this, { _, h, m ->
            Prefs.setInt(this, key, h * 60 + m)
            refreshTimes()
        }, current / 60, current % 60, false).show()
    }

    private fun refreshTimes() {
        startValue.text = Rear.fmt(Rear.nightStart(this)) + "  ›"
        endValue.text = Rear.fmt(Rear.nightEnd(this)) + "  ›"
    }

    private fun refreshStatus() {
        val last = Prefs.sp(this).getString(Prefs.REAR_STATUS, null)
        status.text = when {
            NBAccessibilityService.instance == null -> "Waiting for NB Accessibility to be turned on."
            last != null -> "Last: $last"
            Prefs.on(this, Prefs.REAR_NIGHT) -> "Waiting for the schedule."
            else -> "Night schedule is off."
        }
    }

    // ---------- view helpers ----------

    private fun card(parent: LinearLayout, title: String): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundBg(Ui.CARD, 20f)
            setPadding(dp(16), dp(14), dp(16), dp(16))
        }
        c.addView(label(title, 13f, Ui.ACCENT, true).apply { setPadding(0, 0, 0, dp(8)) })
        parent.addView(c, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = dp(12)
        })
        return c
    }

    private fun timeRow(parent: LinearLayout, title: String, onClick: () -> Unit): TextView {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), 0, dp(10))
            isClickable = true
            setOnClickListener { onClick() }
        }
        r.addView(label(title, 15f), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val v = label("", 15f, Ui.ACCENT, true)
        r.addView(v)
        parent.addView(r)
        return v
    }

    private fun button(text: String, onClick: () -> Unit): TextView =
        label(text, 15f, Ui.TEXT, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(13), dp(16), dp(13))
            background = roundBg(Ui.CARD2, 16f)
            setOnClickListener { onClick() }
        }
}
