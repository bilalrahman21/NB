package app.nb

import java.util.Locale

/**
 * Helps match names spoken in Malayalam ("അഹമ്മദ്") to names saved in English ("Ahmed").
 * Both are turned into a rough sound "skeleton" (first letter + consonants) and compared.
 */
object Translit {

    private val vowels = mapOf(
        'അ' to "a", 'ആ' to "aa", 'ഇ' to "i", 'ഈ' to "ee", 'ഉ' to "u", 'ഊ' to "oo", 'ഋ' to "ru",
        'എ' to "e", 'ഏ' to "e", 'ഐ' to "ai", 'ഒ' to "o", 'ഓ' to "o", 'ഔ' to "au"
    )
    private val consonants = mapOf(
        'ക' to "k", 'ഖ' to "kh", 'ഗ' to "g", 'ഘ' to "gh", 'ങ' to "ng",
        'ച' to "ch", 'ഛ' to "ch", 'ജ' to "j", 'ഝ' to "jh", 'ഞ' to "nj",
        'ട' to "t", 'ഠ' to "t", 'ഡ' to "d", 'ഢ' to "d", 'ണ' to "n",
        'ത' to "th", 'ഥ' to "th", 'ദ' to "d", 'ധ' to "dh", 'ന' to "n",
        'പ' to "p", 'ഫ' to "f", 'ബ' to "b", 'ഭ' to "bh", 'മ' to "m",
        'യ' to "y", 'ര' to "r", 'ല' to "l", 'വ' to "v", 'ശ' to "sh",
        'ഷ' to "sh", 'സ' to "s", 'ഹ' to "h", 'ള' to "l", 'ഴ' to "zh", 'റ' to "r"
    )
    private val signs = mapOf(
        'ാ' to "aa", 'ി' to "i", 'ീ' to "ee", 'ു' to "u", 'ൂ' to "oo", 'ൃ' to "ru",
        'െ' to "e", 'േ' to "e", 'ൈ' to "ai", 'ൊ' to "o", 'ോ' to "o", 'ൌ' to "au", 'ൗ' to "au",
        'ം' to "m", 'ഃ' to "h", '്' to ""
    )
    private val chillu = mapOf('ൺ' to "n", 'ൻ' to "n", 'ർ' to "r", 'ൽ' to "l", 'ൾ' to "l", 'ൿ' to "k")

    fun hasMalayalam(s: String) = s.any { it in 'ഀ'..'ൿ' }

    /** Malayalam script → rough English letters. Other characters are kept. */
    fun toLatin(s: String): String {
        val sb = StringBuilder()
        var i = 0
        while (i < s.length) {
            val ch = s[i]
            val next = if (i + 1 < s.length) s[i + 1] else ' '
            when {
                consonants.containsKey(ch) -> {
                    sb.append(consonants[ch])
                    // A consonant carries an "a" sound unless a vowel sign or virama follows.
                    if (!signs.containsKey(next) || next == 'ം' || next == 'ഃ') sb.append("a")
                }
                vowels.containsKey(ch) -> sb.append(vowels[ch])
                signs.containsKey(ch) -> sb.append(signs[ch])
                chillu.containsKey(ch) -> sb.append(chillu[ch])
                else -> sb.append(ch)
            }
            i++
        }
        return sb.toString()
    }

    /** "Ahmed", "ahammad" and "അഹമ്മദ്" all become "amd". */
    fun skeleton(raw: String): String {
        var s = (if (hasMalayalam(raw)) toLatin(raw) else raw).lowercase(Locale.ROOT)
        s = s.filter { it in 'a'..'z' }
        if (s.isEmpty()) return ""
        s = s.replace("ph", "f").replace("w", "v").replace("q", "k").replace("z", "s")
            .replace("ck", "k").replace("c", "k").replace("x", "ks")
        val first = s[0]
        val sb = StringBuilder().append(first)
        var last = first
        for (k in 1 until s.length) {
            val c = s[k]
            if (c in "aeiouyh") continue
            if (c == last) continue
            sb.append(c)
            last = c
        }
        return sb.toString()
    }

    /** How well [name] matches what was said: 3 = full name, 2 = one word, 1 = starts the same, 0 = no. */
    fun score(name: String, spoken: String): Int {
        val q = skeleton(spoken)
        if (q.length < 2) return 0
        if (skeleton(name) == q) return 3
        val words = name.split(" ", "-", ".").filter { it.isNotBlank() }
        if (words.any { skeleton(it) == q }) return 2
        if (words.any { val w = skeleton(it); w.length >= 3 && (w.startsWith(q) || q.startsWith(w)) }) return 1
        return 0
    }
}
