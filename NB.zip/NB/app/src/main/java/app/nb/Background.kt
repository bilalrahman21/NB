package app.nb

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import kotlin.math.abs
import kotlin.math.sqrt

/** Shake the phone (a quick back-and-forth, twice) to toggle the torch. */
class ShakeTorch(private val ctx: Context) : SensorEventListener {
    private val sm = ctx.getSystemService(SensorManager::class.java)
    private val accel: Sensor? = sm?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    private val cam = ctx.getSystemService(CameraManager::class.java)
    private var torchId: String? = null
    private var torchOn = false
    private var listening = false

    private var windowStart = 0L
    private var lastPeak = 0L
    private var peaks = 0
    private var lastToggle = 0L

    private val torchCallback = object : CameraManager.TorchCallback() {
        override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
            if (cameraId == torchId) torchOn = enabled
        }
    }

    init {
        val c = cam
        if (c != null) {
            try {
                torchId = c.cameraIdList.firstOrNull { id ->
                    c.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                }
                c.registerTorchCallback(torchCallback, Handler(Looper.getMainLooper()))
            } catch (e: Exception) {
            }
        }
    }

    fun listen(on: Boolean) {
        if (on && !listening && accel != null) {
            sm?.registerListener(this, accel, SensorManager.SENSOR_DELAY_UI)
            listening = true
        } else if (!on && listening) {
            sm?.unregisterListener(this)
            listening = false
        }
    }

    fun release() {
        listen(false)
        try { cam?.unregisterTorchCallback(torchCallback) } catch (e: Exception) {}
    }

    override fun onSensorChanged(e: SensorEvent) {
        val x = e.values[0]; val y = e.values[1]; val z = e.values[2]
        val g = sqrt(x * x + y * y + z * z) / SensorManager.GRAVITY_EARTH
        if (g < 2.6f) return
        val now = SystemClock.elapsedRealtime()
        if (now - lastPeak < 150) return
        if (now - windowStart > 1200) { windowStart = now; peaks = 0 }
        peaks++
        lastPeak = now
        if (peaks >= 3 && now - lastToggle > 1500) {
            peaks = 0
            lastToggle = now
            toggle()
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    private fun toggle() {
        val id = torchId ?: return
        try {
            cam?.setTorchMode(id, !torchOn)
            buzz(ctx)
        } catch (e: Exception) {
        }
    }
}

/**
 * Detects deliberate taps on the back of the phone using the accelerometer.
 *
 * To avoid accidental triggers it only counts taps when:
 *  - the phone was held steady just before the first tap (not walking, not being put down),
 *  - each tap is a sharp jolt straight through the phone (Z axis), not a sideways knock,
 *  - the taps are evenly spaced (120–450 ms apart) with stillness between them,
 *  - exactly the required number of taps happen, followed by stillness,
 *  - the phone is not in a pocket or bag (proximity sensor).
 */
class BackTap(ctx: Context, private val onTaps: () -> Unit) : SensorEventListener {
    private val sm = ctx.getSystemService(SensorManager::class.java)
    private val accel: Sensor? = sm?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    private val prox: Sensor? = sm?.getDefaultSensor(Sensor.TYPE_PROXIMITY)
    private val main = Handler(Looper.getMainLooper())
    private var listening = false

    /** Minimum jolt in m/s² (from the sensitivity setting). */
    var threshold = 4.0f
    /** 2 = double tap, 3 = triple tap. */
    var tapsNeeded = 2

    private val gravity = FloatArray(3)
    private var samples = 0
    private var near = false

    // Recent movement history (about 2 seconds).
    private val size = 512
    private val times = LongArray(size)
    private val mags = FloatArray(size)
    private var head = 0
    private var filled = 0

    private val taps = ArrayList<Long>()
    private var lastPeak = 0L
    private var lastFire = 0L

    private val confirm = Runnable { confirmTaps() }

    private fun quietLimit() = maxOf(1.1f, threshold * 0.28f)

    fun listen(on: Boolean) {
        if (on && !listening && accel != null) {
            samples = 0
            filled = 0
            taps.clear()
            near = false
            // ~200 samples a second so short taps aren't missed.
            sm?.registerListener(this, accel, 5000)
            prox?.let { sm?.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL) }
            listening = true
        } else if (!on && listening) {
            sm?.unregisterListener(this)
            main.removeCallbacks(confirm)
            taps.clear()
            listening = false
        }
    }

    fun release() = listen(false)

    /** True if nothing moved the phone more than a little between [from] and [to]. */
    private fun quiet(from: Long, to: Long): Boolean {
        if (to <= from) return true
        val limit = quietLimit()
        var seen = 0
        var i = head
        for (n in 0 until filled) {
            i = if (i == 0) size - 1 else i - 1
            val t = times[i]
            if (t < from) break
            if (t <= to) {
                seen++
                if (mags[i] > limit) return false
            }
        }
        // Not enough history yet counts as "not steady".
        return seen >= ((to - from) / 15).toInt().coerceAtMost(20)
    }

    private fun reset() {
        taps.clear()
        main.removeCallbacks(confirm)
    }

    override fun onSensorChanged(e: SensorEvent) {
        if (e.sensor.type == Sensor.TYPE_PROXIMITY) {
            val max = e.sensor.maximumRange
            near = e.values[0] < minOf(max, 3f)
            if (near) reset()
            return
        }

        val v = e.values
        if (samples < 40) {
            // Settle the gravity estimate first.
            for (i in 0..2) gravity[i] = if (samples == 0) v[i] else gravity[i] * 0.8f + v[i] * 0.2f
            samples++
            return
        }
        for (i in 0..2) gravity[i] = gravity[i] * 0.94f + v[i] * 0.06f
        val lx = v[0] - gravity[0]
        val ly = v[1] - gravity[1]
        val lz = v[2] - gravity[2]
        val mag = sqrt(lx * lx + ly * ly + lz * lz)
        val now = SystemClock.elapsedRealtime()

        times[head] = now
        mags[head] = mag
        head = (head + 1) % size
        if (filled < size) filled++

        if (near) return
        val z = abs(lz)
        val side = sqrt(lx * lx + ly * ly)
        val isTap = z >= threshold && z >= side * 2f
        if (!isTap) return
        if (now - lastPeak < 110) return // the same tap still ringing
        lastPeak = now
        if (now - lastFire < 2000) return

        if (taps.isEmpty()) {
            // The phone must be steady before the first tap.
            if (quiet(now - 500, now - 30)) taps.add(now)
            return
        }

        val gap = now - taps.last()
        when {
            gap > 450 -> {
                reset()
                if (quiet(now - 500, now - 30)) taps.add(now)
                return
            }
            gap < 120 -> return
            !quiet(taps.last() + 110, now - 30) -> { reset(); return }
        }
        taps.add(now)
        if (taps.size > tapsNeeded) { reset(); return }
        if (taps.size == tapsNeeded) {
            main.removeCallbacks(confirm)
            main.postDelayed(confirm, 420)
        }
    }

    private fun confirmTaps() {
        val last = taps.lastOrNull() ?: return
        val now = SystemClock.elapsedRealtime()
        // Exactly the right number of taps, then stillness.
        val ok = !near && taps.size == tapsNeeded && quiet(last + 110, now)
        taps.clear()
        if (ok) {
            lastFire = now
            onTaps()
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}

fun buzz(c: Context, ms: Long = 40) {
    try {
        val v: Vibrator? = if (Build.VERSION.SDK_INT >= 31) {
            c.getSystemService(VibratorManager::class.java)?.defaultVibrator
        } else {
            c.getSystemService(Vibrator::class.java)
        }
        v?.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
    } catch (e: Exception) {
    }
}

/** Alerts once per charge when the battery reaches 85% (or 100%). */
object BatteryWatcher {
    private var owner: Context? = null
    private var alerted = false

    private val rx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) = handle(c, i)
    }

    fun start(c: Context) {
        if (owner != null) return
        owner = c
        val f = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        try {
            if (Build.VERSION.SDK_INT >= 33) c.registerReceiver(rx, f, Context.RECEIVER_NOT_EXPORTED)
            else c.registerReceiver(rx, f)
        } catch (e: Exception) {
            owner = null
        }
    }

    fun stop(c: Context) {
        if (owner !== c) return
        try { c.unregisterReceiver(rx) } catch (e: Exception) {}
        owner = null
    }

    private fun handle(c: Context, i: Intent) {
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
        if (level < 0) return
        val pct = level * 100 / scale
        val plugged = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
        if (!plugged) { alerted = false; return }
        if (!Prefs.on(c, Prefs.BATTERY)) return
        val threshold = if (Prefs.on(c, Prefs.BATTERY_85)) 85 else 100
        if (pct >= threshold && !alerted) {
            alerted = true
            Notifier.battery(c, pct)
        }
    }
}
