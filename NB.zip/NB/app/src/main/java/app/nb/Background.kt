package app.nb

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import kotlin.math.sqrt

/** Shake the phone (a quick back-and-forth, twice) to toggle the torch. */
class ShakeTorch(private val ctx: Context) : SensorEventListener {
    private val sm = ctx.getSystemService(SensorManager::class.java)
    private val accel: Sensor? = sm?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    private val cam = ctx.getSystemService(CameraManager::class.java)
    private var torchId: String? = null
    private var torchOn = false
    private var listening = false

    private var windowStart = 0L
    private var lastPeak = 0L
    private var peaks = 0
    private var lastToggle = 0L

    private val torchCallback = object : CameraManager.TorchCallback() {
        override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
            if (cameraId == torchId) torchOn = enabled
        }
    }

    init {
        val c = cam
        if (c != null) {
            try {
                torchId = c.cameraIdList.firstOrNull { id ->
                    c.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                }
                c.registerTorchCallback(torchCallback, Handler(Looper.getMainLooper()))
            } catch (e: Exception) {
            }
        }
    }

    fun listen(on: Boolean) {
        if (on && !listening && accel != null) {
            sm?.registerListener(this, accel, SensorManager.SENSOR_DELAY_UI)
            listening = true
        } else if (!on && listening) {
            sm?.unregisterListener(this)
            listening = false
        }
    }

    fun release() {
        listen(false)
        try { cam?.unregisterTorchCallback(torchCallback) } catch (e: Exception) {}
    }

    override fun onSensorChanged(e: SensorEvent) {
        val x = e.values[0]; val y = e.values[1]; val z = e.values[2]
        val g = sqrt(x * x + y * y + z * z) / SensorManager.GRAVITY_EARTH
        if (g < 2.6f) return
        val now = SystemClock.elapsedRealtime()
        if (now - lastPeak < 150) return
        if (now - windowStart > 1200) { windowStart = now; peaks = 0 }
        peaks++
        lastPeak = now
        if (peaks >= 3 && now - lastToggle > 1500) {
            peaks = 0
            lastToggle = now
            toggle()
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    private fun toggle() {
        val id = torchId ?: return
        try {
            cam?.setTorchMode(id, !torchOn)
            buzz(ctx)
        } catch (e: Exception) {
        }
    }
}

fun buzz(c: Context, ms: Long = 40) {
    try {
        val v: Vibrator? = if (Build.VERSION.SDK_INT >= 31) {
            c.getSystemService(VibratorManager::class.java)?.defaultVibrator
        } else {
            c.getSystemService(Vibrator::class.java)
        }
        v?.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
    } catch (e: Exception) {
    }
}

/** Alerts once per charge when the battery reaches 85% (or 100%). */
object BatteryWatcher {
    private var owner: Context? = null
    private var alerted = false

    private val rx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) = handle(c, i)
    }

    fun start(c: Context) {
        if (owner != null) return
        owner = c
        val f = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        try {
            if (Build.VERSION.SDK_INT >= 33) c.registerReceiver(rx, f, Context.RECEIVER_NOT_EXPORTED)
            else c.registerReceiver(rx, f)
        } catch (e: Exception) {
            owner = null
        }
    }

    fun stop(c: Context) {
        if (owner !== c) return
        try { c.unregisterReceiver(rx) } catch (e: Exception) {}
        owner = null
    }

    private fun handle(c: Context, i: Intent) {
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
        if (level < 0) return
        val pct = level * 100 / scale
        val plugged = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
        if (!plugged) { alerted = false; return }
        if (!Prefs.on(c, Prefs.BATTERY)) return
        val threshold = if (Prefs.on(c, Prefs.BATTERY_85)) 85 else 100
        if (pct >= threshold && !alerted) {
            alerted = true
            Notifier.battery(c, pct)
        }
    }
}
