package app.nb

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Bitmap
import android.graphics.Rect
import android.graphics.RectF
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

/** The frozen-screen overlay: circle to search, copy text, scan QR, translate, pin. */
class CaptureActivity : Activity(), CaptureView.Listener {

    private lateinit var shot: Bitmap
    private lateinit var cv: CaptureView
    private lateinit var bar: LinearLayout
    private lateinit var hint: TextView
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private var areaRect: Rect? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val bmp = ShotHolder.bitmap
        if (bmp == null) { finish(); return }
        ShotHolder.bitmap = null
        shot = bmp

        goFullScreen()

        val root = FrameLayout(this)
        cv = CaptureView(this, shot)
        cv.listener = this
        root.addView(cv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // Top: close button + hint
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(36), dp(16), 0)
        }
        val close = label("✕", 18f, Ui.TEXT, true).apply {
            gravity = Gravity.CENTER
            background = roundBg(Ui.SCRIM, 22f, 0x33FFFFFF, 1)
            setOnClickListener { finish() }
        }
        top.addView(close, LinearLayout.LayoutParams(dp(44), dp(44)))
        hint = label("Circle anything · tap or hold text", 13f, Ui.TEXT).apply {
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = roundBg(Ui.SCRIM, 22f, 0x33FFFFFF, 1)
        }
        top.addView(hint, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(10) })
        root.addView(top, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP))

        // Bottom: action bar that changes with what is selected
        val scroller = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            clipToPadding = false
            setPadding(dp(16), 0, dp(16), 0)
        }
        bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        scroller.addView(bar)
        root.addView(scroller, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        ).apply { bottomMargin = dp(40) })

        setContentView(root)
        showDefaultBar()
        runOcr()
    }

    private fun goFullScreen() {
        window.attributes = window.attributes.apply {
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        }
        window.setDecorFitsSystemWindows(false)
        window.insetsController?.let {
            it.hide(WindowInsets.Type.systemBars())
            it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    private fun runOcr() {
        recognizer.process(InputImage.fromBitmap(shot, 0))
            .addOnSuccessListener { result ->
                val words = ArrayList<CaptureView.Word>()
                var line = 0
                for (block in result.textBlocks) {
                    for (l in block.lines) {
                        for (el in l.elements) {
                            val box = el.boundingBox ?: continue
                            words.add(CaptureView.Word(el.text, RectF(box), line))
                        }
                        line++
                    }
                }
                cv.setWords(words)
            }
            .addOnFailureListener { cv.setWords(emptyList()) }
    }

    // ---------- bars ----------

    private fun act(name: String, f: () -> Unit): Pair<String, () -> Unit> = Pair(name, f)

    private fun setBar(vararg items: Pair<String, () -> Unit>) {
        bar.removeAllViews()
        items.forEachIndexed { i, (name, action) ->
            val p = pill(name, filled = i == 0, onClick = action)
            bar.addView(p, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { marginEnd = dp(8) })
        }
    }

    private fun showDefaultBar() {
        hint.text = "Circle anything · tap or hold text"
        setBar(
            act("Select all text") { selectAll() },
            act("Scan QR") { scanQr(shot) }
        )
    }

    private fun showAreaBar() {
        hint.text = "Search it, or copy the text inside"
        setBar(
            act("Search") { cropOrNull()?.let { if (Share.lens(this, it)) finish() else toast("Google Lens not found") } },
            act("Copy text") {
                when {
                    !cv.ocrReady -> toast("Still reading text…")
                    !cv.selectTextInArea() -> toast("No text found in that area")
                    else -> {}
                }
            },
            act("Scan QR") { cropOrNull()?.let { scanQr(it) } },
            act("Pin") { pinArea() },
            act("Share") { cropOrNull()?.let { Share.shareImage(this, it) } },
            act("Save") {
                cropOrNull()?.let { toast(if (Share.saveToGallery(this, it)) "Saved to Pictures/NB" else "Couldn't save") }
            }
        )
    }

    private fun showTextBar() {
        hint.text = "Drag the handles to adjust"
        setBar(
            act("Copy") { copySelection() },
            act("Translate") {
                val t = cv.selectedText()
                if (t.isNotBlank()) NBTranslate.translate(this, t) { out -> Clip.copy(this, out) }
            },
            act("Search") { cv.selectedText().takeIf { it.isNotBlank() }?.let { Share.searchText(this, it); finish() } },
            act("Share") { cv.selectedText().takeIf { it.isNotBlank() }?.let { Share.shareText(this, it) } },
            act("Select all") { selectAll() }
        )
    }

    // ---------- actions ----------

    private fun selectAll() {
        when {
            !cv.ocrReady -> toast("Still reading text…")
            !cv.selectAll() -> toast("No text found on this screen")
        }
    }

    private fun copySelection() {
        val t = cv.selectedText()
        if (t.isBlank()) return
        Clip.copy(this, t)
        finish()
    }

    private fun cropOrNull(): Bitmap? {
        val r = areaRect ?: return null
        return try {
            Bitmap.createBitmap(shot, r.left, r.top, r.width(), r.height())
        } catch (e: Exception) {
            null
        }
    }

    private fun pinArea() {
        val crop = cropOrNull() ?: return
        val svc = NBAccessibilityService.instance
        if (svc == null) {
            toast("Turn on NB in Accessibility to pin")
            return
        }
        svc.pin(crop)
        finish()
    }

    private fun scanQr(bmp: Bitmap) {
        BarcodeScanning.getClient().process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { codes ->
                val values = codes.mapNotNull { it.rawValue }.filter { it.isNotBlank() }.distinct()
                if (isFinishing) return@addOnSuccessListener
                when (values.size) {
                    0 -> toast("No QR code or barcode found")
                    1 -> showCode(values[0])
                    else -> AlertDialog.Builder(this)
                        .setTitle("Codes found")
                        .setItems(values.map { it.take(80) }.toTypedArray()) { _, which -> showCode(values[which]) }
                        .show()
                }
            }
            .addOnFailureListener { toast("Couldn't scan") }
    }

    private fun showCode(value: String) {
        AlertDialog.Builder(this)
            .setTitle("Scanned")
            .setMessage(value)
            .setPositiveButton("Open") { _, _ -> if (Share.openLink(this, value)) finish() else toast("Can't open this, copy it instead") }
            .setNeutralButton("Copy") { _, _ -> Clip.copy(this, value) }
            .setNegativeButton("Close", null)
            .show()
    }

    // ---------- CaptureView.Listener ----------

    override fun onArea(bitmapRect: Rect) {
        areaRect = bitmapRect
        showAreaBar()
    }

    override fun onSelection(text: String) {
        areaRect = null
        if (text.isNotBlank()) showTextBar() else showDefaultBar()
    }

    override fun onCleared() {
        areaRect = null
        showDefaultBar()
    }

    override fun onTextNotReady() {
        toast("Still reading text…")
    }

    override fun onDestroy() {
        super.onDestroy()
        try { recognizer.close() } catch (e: Exception) {}
    }

    @Suppress("unused")
    private fun View.gone() { visibility = View.GONE }
}
