package app.nb

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    const val HANDLE = "handle"
    const val HANDLE_LEFT = "handle_left"
    const val LOCK_DOUBLE_TAP = "lock_double_tap"
    const val SHAKE_TORCH = "shake_torch"
    const val OTP = "otp"
    const val BATTERY = "battery"
    const val BATTERY_85 = "battery_85"
    const val LANG = "lang"
    const val BACK_TAP = "back_tap"
    const val TAP_SENS = "tap_sens"
    const val TAP_COUNT = "tap_count"
    const val HANDLE_POS = "handle_pos"
    const val HANDLE_TRIPLE_SHOT = "handle_triple_shot"
    const val AUTO_SEARCH = "auto_search"
    const val AI_KEY = "ai_key"
    const val AI_MODEL = "ai_model"
    const val AI_NO_THINK_LEVEL = "ai_no_think_level"
    const val AI_THINK_STEP = "ai_think_step"
    const val AI_THINK = "ai_think"
    const val VOICE_LANG = "voice_lang"
    const val SPEAK = "speak_replies"
    const val ASSIST_ACTION = "assist_action"
    const val REMINDERS = "reminders"
    const val REAR_NIGHT = "rear_night"
    const val NIGHT_START = "night_start"
    const val NIGHT_END = "night_end"
    const val REAR_STATUS = "rear_status"
    const val REAR_APPLIED = "rear_applied"
    const val REAR_COMPONENT = "rear_component"
    const val REAR_OVERRIDE_UNTIL = "rear_override_until"

    fun sp(c: Context): SharedPreferences = c.getSharedPreferences("nb", Context.MODE_PRIVATE)

    private fun default(key: String): Boolean = when (key) {
        HANDLE, OTP, BATTERY, BATTERY_85, BACK_TAP, HANDLE_TRIPLE_SHOT, AUTO_SEARCH, SPEAK -> true
        else -> false
    }

    fun on(c: Context, key: String): Boolean = sp(c).getBoolean(key, default(key))
    fun set(c: Context, key: String, value: Boolean) = sp(c).edit().putBoolean(key, value).apply()

    /** "low", "medium" or "high" */
    fun tapSens(c: Context): String = sp(c).getString(TAP_SENS, "medium") ?: "medium"
    fun setTapSens(c: Context, v: String) = sp(c).edit().putString(TAP_SENS, v).apply()

    /** How hard the back tap must be (m/s²). Higher sensitivity = lighter taps count. */
    fun tapThreshold(c: Context): Float = when (tapSens(c)) {
        "low" -> 5.5f
        "high" -> 2.8f
        else -> 4.0f
    }

    /** 2 = double tap, 3 = triple tap. */
    fun tapCount(c: Context): Int = int(c, TAP_COUNT, 2)

    /** Edge handle position: 0 = top, 1 = middle, 2 = bottom. */
    fun handlePos(c: Context): Int = int(c, HANDLE_POS, 1)

    fun voiceLang(c: Context): String = sp(c).getString(VOICE_LANG, "en-IN") ?: "en-IN"

    /** What holding the gesture bar opens: 0 = voice assistant, 1 = circle to search. */
    fun assistAction(c: Context): Int = int(c, ASSIST_ACTION, 0)

    fun int(c: Context, key: String, def: Int): Int = sp(c).getInt(key, def)
    fun setInt(c: Context, key: String, v: Int) = sp(c).edit().putInt(key, v).apply()

    fun lang(c: Context): String = sp(c).getString(LANG, "en") ?: "en"
    fun setLang(c: Context, tag: String) = sp(c).edit().putString(LANG, tag).apply()
}
