package app.nb

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    const val HANDLE = "handle"
    const val HANDLE_LEFT = "handle_left"
    const val LOCK_DOUBLE_TAP = "lock_double_tap"
    const val SHAKE_TORCH = "shake_torch"
    const val OTP = "otp"
    const val BATTERY = "battery"
    const val BATTERY_85 = "battery_85"
    const val LANG = "lang"

    fun sp(c: Context): SharedPreferences = c.getSharedPreferences("nb", Context.MODE_PRIVATE)

    private fun default(key: String): Boolean = when (key) {
        HANDLE, LOCK_DOUBLE_TAP, OTP, BATTERY, BATTERY_85 -> true
        else -> false
    }

    fun on(c: Context, key: String): Boolean = sp(c).getBoolean(key, default(key))
    fun set(c: Context, key: String, value: Boolean) = sp(c).edit().putBoolean(key, value).apply()

    fun lang(c: Context): String = sp(c).getString(LANG, "en") ?: "en"
    fun setLang(c: Context, tag: String) = sp(c).edit().putString(LANG, tag).apply()
}
