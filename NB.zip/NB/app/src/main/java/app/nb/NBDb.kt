package app.nb

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/** Local storage for notification history and clipboard history. Nothing leaves the phone. */
class NBDb private constructor(ctx: Context) : SQLiteOpenHelper(ctx.applicationContext, "nb.db", null, 1) {

    data class Notif(val id: Long, val pkg: String, val app: String, val title: String, val body: String, val time: Long)
    data class ClipItem(val id: Long, val body: String, val time: Long, val pinned: Boolean)

    companion object {
        private const val DAY = 24L * 60 * 60 * 1000
        private const val KEEP_DAYS = 30L
        private const val MAX_CLIPS = 300

        @Volatile private var inst: NBDb? = null
        fun get(c: Context): NBDb = inst ?: synchronized(this) { inst ?: NBDb(c).also { inst = it } }
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE notif (_id INTEGER PRIMARY KEY AUTOINCREMENT, pkg TEXT, app TEXT, title TEXT, body TEXT, time INTEGER)")
        db.execSQL("CREATE INDEX notif_time ON notif(time)")
        db.execSQL("CREATE TABLE clip (_id INTEGER PRIMARY KEY AUTOINCREMENT, body TEXT, time INTEGER, pinned INTEGER DEFAULT 0)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    // ---------- notifications ----------

    fun addNotif(pkg: String, app: String, title: String, body: String, time: Long) {
        val db = writableDatabase
        db.rawQuery(
            "SELECT 1 FROM notif WHERE pkg=? AND title=? AND body=? AND time>? LIMIT 1",
            arrayOf(pkg, title, body, (time - 6 * 60 * 60 * 1000L).toString())
        ).use { if (it.moveToFirst()) return }
        db.insert("notif", null, ContentValues().apply {
            put("pkg", pkg); put("app", app); put("title", title); put("body", body); put("time", time)
        })
        if (Math.random() < 0.03) {
            db.delete("notif", "time<?", arrayOf((System.currentTimeMillis() - KEEP_DAYS * DAY).toString()))
        }
    }

    fun notifs(query: String): List<Notif> {
        val out = ArrayList<Notif>()
        val like = "%${query.trim()}%"
        readableDatabase.rawQuery(
            "SELECT _id, pkg, app, title, body, time FROM notif WHERE title LIKE ? OR body LIKE ? OR app LIKE ? ORDER BY time DESC LIMIT 500",
            arrayOf(like, like, like)
        ).use { c ->
            while (c.moveToNext()) {
                out.add(Notif(c.getLong(0), c.getString(1) ?: "", c.getString(2) ?: "", c.getString(3) ?: "", c.getString(4) ?: "", c.getLong(5)))
            }
        }
        return out
    }

    fun deleteNotif(id: Long) { writableDatabase.delete("notif", "_id=?", arrayOf(id.toString())) }
    fun clearNotifs() { writableDatabase.delete("notif", null, null) }

    // ---------- clipboard ----------

    fun addClip(text: String) {
        val body = text.trim().take(20000)
        if (body.isEmpty()) return
        val db = writableDatabase
        val now = System.currentTimeMillis()
        val updated = db.update("clip", ContentValues().apply { put("time", now) }, "body=?", arrayOf(body))
        if (updated == 0) {
            db.insert("clip", null, ContentValues().apply { put("body", body); put("time", now); put("pinned", 0) })
            db.execSQL(
                "DELETE FROM clip WHERE pinned=0 AND _id NOT IN (SELECT _id FROM clip WHERE pinned=0 ORDER BY time DESC LIMIT $MAX_CLIPS)"
            )
        }
    }

    fun latestClip(): String? =
        readableDatabase.rawQuery("SELECT body FROM clip ORDER BY time DESC LIMIT 1", null).use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }

    fun clips(query: String): List<ClipItem> {
        val out = ArrayList<ClipItem>()
        readableDatabase.rawQuery(
            "SELECT _id, body, time, pinned FROM clip WHERE body LIKE ? ORDER BY pinned DESC, time DESC LIMIT 500",
            arrayOf("%${query.trim()}%")
        ).use { c ->
            while (c.moveToNext()) out.add(ClipItem(c.getLong(0), c.getString(1) ?: "", c.getLong(2), c.getInt(3) == 1))
        }
        return out
    }

    fun setPinned(id: Long, pinned: Boolean) {
        writableDatabase.update("clip", ContentValues().apply { put("pinned", if (pinned) 1 else 0) }, "_id=?", arrayOf(id.toString()))
    }

    fun deleteClip(id: Long) { writableDatabase.delete("clip", "_id=?", arrayOf(id.toString())) }
    fun clearClips() { writableDatabase.delete("clip", "pinned=0", null) }
}
